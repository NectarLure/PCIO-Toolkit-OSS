﻿# Scripts / 脚本

PCIO Toolkit 1.1 已实现：

- `build_pcio_survey_schema_v3.py`：确定性生成并校验305项双语问卷schema。
- `pcio_survey_core.py`：画像校验、匿名响应、Likert/NA/多选/排序校验、CSV追加和描述性聚合。
- `build_phase2_html.py`：从统一 schema 生成单文件双语 HTML。
- `build_phase2_excel.mjs`：从统一 schema 生成 Excel 问卷模板。
- `pcio_analysis.py`：清洗、量表计分、描述统计、Cronbach's α、KMO/Bartlett、Welch t-test/ANOVA、Pearson、五组 OLS、业务解读和 JSON/CSV/Excel 导出。
- `pcio_report.py`：可复用的确定性中英双语个性化案例报告生成器。
- `analyze_pcio_survey.py`：画像 JSON + 多份问卷 CSV 的命令行完整分析入口。
- `generate_phase3_example.py`：生成可重复的 chemical-process `n=60` 合成示例和分析包。
- `recalculate_legacy_pcio_evidence.py`：复算既有 `n=52` 研究数据并输出证据摘要。
- `pcio_decision_support.py`：动态风险、4×4 矩阵、KPI、ROI、Excel 和完整 ZIP 核心模块。
- `generate_pcio_decision_support.py`：画像 JSON + Phase 3 分析 JSON 的独立决策支持入口。
- `generate_phase4_example.py`：生成 chemical-process 风险/KPI/ROI 完整示例。
- `build_phase5_static_site.py`：生成 `site/index.html` 单文件静态独立站。
- `generate_final_examples.py`：生成化工与离散制造两套自包含最终示例。

Version 1.1 implements the 305-item shared survey core, deterministic builders, statistical and reporting engines, dynamic risk/KPI/ROI decision support, static-site generation, Excel/ZIP export, two reproducible complete examples, and legacy evidence recalculation.

快速运行 / Quick run:

```powershell
.\.venv\Scripts\python scripts/analyze_pcio_survey.py `
  --profile examples/phase2/chemical-process-company-profile.json `
  --responses examples/phase3/chemical-process/synthetic_technician_responses_n60.csv `
  --output-dir outputs/chemical-process-analysis
```

```powershell
.\.venv\Scripts\python scripts/generate_pcio_decision_support.py `
  --profile examples/phase2/chemical-process-company-profile.json `
  --analysis examples/phase3/chemical-process/analysis_package/pcio_analysis_results.json `
  --output-dir outputs/chemical-process-decision-support
```

最终构建 / Final build:

```powershell
.\.venv\Scripts\python scripts/build_pcio_survey_schema_v3.py
.\.venv\Scripts\python scripts/build_phase2_html.py
.\.venv\Scripts\python scripts/build_phase5_static_site.py
.\.venv\Scripts\python scripts/generate_final_examples.py
```

正式 DOCX/PDF、企业 SSO 和数据库审计属于 1.0 后扩展。Formal DOCX/PDF, enterprise SSO, and database audit are post-1.0 extensions.


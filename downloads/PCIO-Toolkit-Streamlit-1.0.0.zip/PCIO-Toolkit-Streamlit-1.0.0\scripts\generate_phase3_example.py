﻿"""Generate deterministic synthetic Phase 3 example responses and outputs."""

from __future__ import annotations

import csv
import subprocess
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.pcio_survey_core import (
    flatten_response,
    load_schema,
    response_columns,
    selected_questions,
)


PROFILE_PATH = ROOT / "examples" / "phase2" / "chemical-process-company-profile.json"
EXAMPLE_DIR = ROOT / "examples" / "phase3" / "chemical-process"
RESPONSE_PATH = EXAMPLE_DIR / "synthetic_technician_responses_n60.csv"
OUTPUT_DIR = EXAMPLE_DIR / "analysis_package"


def _likert(value: float) -> int:
    return int(np.clip(np.rint(value), 1, 5))


def generate_rows(n: int = 60, seed: int = 20260610) -> list[dict[str, object]]:
    import json

    schema = load_schema()
    profile = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    rng = np.random.default_rng(seed)
    covariance = np.array(
        [
            [1.00, 0.24, 0.20, 0.16, 0.12],
            [0.24, 1.00, 0.30, 0.22, 0.14],
            [0.20, 0.30, 1.00, 0.31, 0.18],
            [0.16, 0.22, 0.31, 1.00, 0.20],
            [0.12, 0.14, 0.18, 0.20, 1.00],
        ]
    )
    factors = rng.multivariate_normal(np.zeros(5), covariance, size=n)
    means = np.array([2.85, 3.20, 2.75, 2.65, 3.15])
    scales = np.array([0.55, 0.48, 0.50, 0.53, 0.46])
    latent = means + factors * scales
    layers = ["P", "C", "I", "O", "H"]
    rows = []
    active_questions = selected_questions(schema, profile)
    roles = ["operator", "technician", "process", "team_lead", "automation"]
    shifts = ["day", "night", "rotating", "regular"]
    for index in range(n):
        layer_value = dict(zip(layers, latent[index]))
        respondent = {
            "respondent_code": f"SYN-{index + 1:03d}",
            "role": roles[index % len(roles)],
            "department": f"生产{index % 3 + 1}组",
            "shift": shifts[index % len(shifts)],
            "years_experience": int(1 + index % 18),
            "tenure_current_position": int(1 + index % 10),
            "education_level": "college",
            "digital_exposure_years": int(1 + index % 8),
            "digital_tool_frequency": "daily",
            "participated_digital_project": "yes" if index % 3 == 0 else "no",
            "training_hours_12m": int(6 + index % 24),
            "decision_involvement": "approve_local" if index % 5 == 0 else "suggest",
        }
        answers: dict[str, object] = {}
        for question in active_questions:
            if question["type"] == "textarea":
                answers[question["id"]] = {
                    "OPEN_01": "参数波动、蒸汽消耗和异常追溯影响本班组稳定运行。",
                    "OPEN_02": "先统一关键测点和蒸汽分项计量，再减少重复抄表。",
                    "OPEN_03": "本记录为 Phase 3 模拟数据，仅用于工具演示。",
                }[question["id"]]
                continue
            if question["type"] == "multiselect":
                answers[question["id"]] = [
                    item["code"]
                    for item in schema["options"][question["options"]][
                        : min(3, question.get("max_items", 3))
                    ]
                ]
                continue
            if question["type"] == "ranking":
                answers[question["id"]] = [
                    item["code"]
                    for item in schema["options"][question["options"]][
                        : question["rank_count"]
                    ]
                ]
                continue
            if question.get("analysis_role") == "attention":
                answers[question["id"]] = 4
                continue
            if question["pcio_layer"] in layer_value:
                desired = layer_value[question["pcio_layer"]] + rng.normal(0, 0.48)
            elif question["pcio_layer"] == "R":
                p, c, i_score, o, h = (layer_value[layer] for layer in layers)
                weights = {
                    "PERF_QUALITY": (0.38, 0.08, 0.24, 0.18, 0.12),
                    "PERF_COST": (0.34, 0.12, 0.18, 0.26, 0.10),
                    "PERF_EFF": (0.42, 0.14, 0.14, 0.20, 0.10),
                    "PERF_FLEX": (0.40, 0.11, 0.20, 0.17, 0.12),
                }[question["id"]]
                desired = (
                    weights[0] * p
                    + weights[1] * c
                    + weights[2] * i_score
                    + weights[3] * o
                    + weights[4] * h
                    + 0.35
                    + rng.normal(0, 0.34)
                )
            else:
                desired = 3.0 + rng.normal(0, 0.5)
            scored = _likert(desired)
            answers[question["id"]] = 6 - scored if question.get("reverse") else scored
        rows.append(flatten_response(profile, respondent, answers, schema))
    return rows


def main() -> int:
    schema = load_schema()
    EXAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    rows = generate_rows()
    with RESPONSE_PATH.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=response_columns(schema))
        writer.writeheader()
        writer.writerows(rows)
    command = [
        sys.executable,
        str(ROOT / "scripts" / "analyze_pcio_survey.py"),
        "--profile",
        str(PROFILE_PATH),
        "--responses",
        str(RESPONSE_PATH),
        "--output-dir",
        str(OUTPUT_DIR),
    ]
    subprocess.run(command, cwd=ROOT, check=True)
    print(RESPONSE_PATH)
    print(OUTPUT_DIR)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


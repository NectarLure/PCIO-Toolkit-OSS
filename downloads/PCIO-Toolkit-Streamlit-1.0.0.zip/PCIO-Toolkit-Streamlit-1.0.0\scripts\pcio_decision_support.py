﻿"""Deterministic PCIO risk, KPI, and ROI decision-support engine."""

from __future__ import annotations

import json
import math
import zipfile
from collections import Counter
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from scripts.pcio_analysis import LAYER_LABELS, PCIO_LAYERS, json_safe
from scripts.pcio_survey_core import load_schema


IDEAL_TARGET = 4.2
RISK_COLORS = {
    "low": "C6E0B4",
    "moderate": "FFE699",
    "high": "F4B183",
    "critical": "E06666",
}
RISK_BANDS = {
    "low": {"zh": "低", "en": "Low"},
    "moderate": {"zh": "中", "en": "Moderate"},
    "high": {"zh": "高", "en": "High"},
    "critical": {"zh": "极高", "en": "Critical"},
}
CATEGORY_LABELS = {
    "technical": {"zh": "技术", "en": "Technical"},
    "organisational": {"zh": "组织", "en": "Organisational"},
    "workforce": {"zh": "人力", "en": "Workforce"},
    "external": {"zh": "外部", "en": "External"},
}


RISK_CATALOG = [
    {
        "id": "T01",
        "category": "technical",
        "layers": ["P"],
        "drivers": ["process_variation", "energy_cost", "quality_defects"],
        "title_zh": "关键测点覆盖、校准或数据完整性不足",
        "title_en": "Insufficient critical-tag coverage, calibration, or completeness",
        "mitigation_zh": "冻结关键测点清单，记录量程、单位、校准、缺失和责任人；先补瓶颈设备。",
        "mitigation_en": "Freeze the critical-tag list and record range, unit, calibration, missingness, and ownership; start with bottleneck assets.",
        "pdca": "Plan/Do",
    },
    {
        "id": "T02",
        "category": "technical",
        "layers": ["C"],
        "drivers": ["equipment_downtime", "manual_records", "slow_exception"],
        "title_zh": "采集链路中断、延迟或网络隔离不足",
        "title_en": "Collection interruption, latency, or inadequate network segregation",
        "mitigation_zh": "建立断点续传、链路健康监控和网络分区；保留人工回退与本地缓存。",
        "mitigation_en": "Use store-and-forward, link-health monitoring, and network segmentation with manual fallback and local buffering.",
        "pdca": "Do/Check",
    },
    {
        "id": "T03",
        "category": "technical",
        "layers": ["I"],
        "drivers": ["manual_records", "collaboration", "slow_exception"],
        "title_zh": "设备、批次、工单和异常语义不一致",
        "title_en": "Inconsistent asset, batch, work-order, and exception semantics",
        "mitigation_zh": "建立轻量数据字典、唯一编码和 KPI 公式；每次接口变更执行对账。",
        "mitigation_en": "Create a lightweight data dictionary, unique identifiers, and KPI formulas; reconcile every interface change.",
        "pdca": "Plan/Check",
    },
    {
        "id": "T04",
        "category": "technical",
        "layers": ["O", "P", "C", "I"],
        "drivers": ["process_variation", "equipment_downtime"],
        "title_zh": "基础数据未达门槛即上线高级优化",
        "title_en": "Advanced optimisation deployed before foundation gates are met",
        "mitigation_zh": "把数据完整率、连接稳定性、语义一致性和人工回退设为模型上线门槛。",
        "mitigation_en": "Make completeness, connectivity, semantics, and human rollback mandatory model-deployment gates.",
        "pdca": "Plan/Act",
    },
    {
        "id": "O01",
        "category": "organisational",
        "layers": ["I", "H"],
        "drivers": ["collaboration", "slow_exception"],
        "title_zh": "试点边界、责任人和异常关闭权责不清",
        "title_en": "Unclear pilot boundary, ownership, and exception closure authority",
        "mitigation_zh": "定义单一试点边界、RACI、异常升级路径和联合签字门槛。",
        "mitigation_en": "Define one pilot boundary, RACI, escalation path, and joint approval gates.",
        "pdca": "Plan",
    },
    {
        "id": "O02",
        "category": "organisational",
        "layers": ["I", "O"],
        "drivers": ["energy_cost", "quality_defects", "equipment_downtime"],
        "title_zh": "KPI 口径或收益基线不可复算",
        "title_en": "Non-reproducible KPI definitions or benefit baseline",
        "mitigation_zh": "冻结基线时间窗、产品组合、分母、异常剔除和财务确认规则。",
        "mitigation_en": "Freeze the baseline window, product mix, denominator, exclusions, and finance sign-off rules.",
        "pdca": "Plan/Check",
    },
    {
        "id": "O03",
        "category": "organisational",
        "layers": ["H", "I"],
        "drivers": ["collaboration", "schedule_changeover", "manual_records"],
        "title_zh": "跨班组或跨部门流程未同步调整",
        "title_en": "Cross-shift or cross-department process not changed with the tool",
        "mitigation_zh": "同步修订交接班、纸质记录、异常会议和标准作业，避免数字化与旧流程并行重复。",
        "mitigation_en": "Update handover, paper records, exception meetings, and standard work to avoid duplicate old and digital processes.",
        "pdca": "Do/Act",
    },
    {
        "id": "H01",
        "category": "workforce",
        "layers": ["H"],
        "drivers": ["manual_records", "collaboration"],
        "title_zh": "一线人员培训、使用能力或参与度不足",
        "title_en": "Insufficient frontline training, capability, or participation",
        "mitigation_zh": "采用岗位化微培训、现场辅导和超级用户机制，培训后用真实任务验证。",
        "mitigation_en": "Use role-based micro-training, floor coaching, and super-users; verify learning with real tasks.",
        "pdca": "Do/Check",
    },
    {
        "id": "H02",
        "category": "workforce",
        "layers": ["O", "H"],
        "drivers": ["slow_exception", "equipment_downtime"],
        "title_zh": "报警过多、误报或新增记录负担导致弃用",
        "title_en": "Alert overload, false positives, or added recording burden causes abandonment",
        "mitigation_zh": "按风险分级报警，跟踪误报率和处置时间；取消等量重复记录。",
        "mitigation_en": "Tier alerts by risk, track false positives and response time, and remove equivalent duplicate recording.",
        "pdca": "Check/Act",
    },
    {
        "id": "H03",
        "category": "workforce",
        "layers": ["O", "H"],
        "drivers": ["process_variation", "quality_defects"],
        "title_zh": "自动建议的授权、确认和安全责任边界不清",
        "title_en": "Unclear authority, confirmation, and safety accountability for automated recommendations",
        "mitigation_zh": "明确建议、批准、执行、回退和审计责任；安全相关动作必须由合格人员确认。",
        "mitigation_en": "Define recommendation, approval, execution, rollback, and audit ownership; qualified personnel confirm safety actions.",
        "pdca": "Plan/Act",
    },
    {
        "id": "E01",
        "category": "external",
        "layers": ["C", "I"],
        "drivers": ["manual_records"],
        "title_zh": "供应商锁定、封闭协议或数据不可迁移",
        "title_en": "Vendor lock-in, closed protocols, or non-portable data",
        "mitigation_zh": "优先开放协议、可导出数据和接口验收条款；保留替代供应商清单。",
        "mitigation_en": "Prefer open protocols, exportable data, and interface acceptance clauses; retain alternative suppliers.",
        "pdca": "Plan",
    },
    {
        "id": "E02",
        "category": "external",
        "layers": ["P", "C"],
        "drivers": ["equipment_downtime", "energy_cost"],
        "title_zh": "本地备件、校准或运维支持响应不足",
        "title_en": "Insufficient local spare-parts, calibration, or maintenance response",
        "mitigation_zh": "确定关键备件、校准周期、服务等级和本地替代方案，并纳入总拥有成本。",
        "mitigation_en": "Define critical spares, calibration cycles, service levels, and local alternatives in total cost of ownership.",
        "pdca": "Plan/Do",
    },
    {
        "id": "E03",
        "category": "external",
        "layers": ["C", "O"],
        "drivers": [],
        "title_zh": "网络安全、合规或区域基础设施约束",
        "title_en": "Cybersecurity, compliance, or regional infrastructure constraints",
        "mitigation_zh": "由企业 IT/EHS 审核网络、账号、日志、数据保存和远程访问；必要时采用本地离线部署。",
        "mitigation_en": "Have corporate IT/EHS review networks, accounts, logs, retention, and remote access; use local offline deployment where needed.",
        "pdca": "Plan/Check",
    },
]


def _score_map(analysis: dict[str, Any]) -> dict[str, float]:
    return {
        row["variable"]: float(row["mean"])
        for row in analysis["tables"]["scale_descriptives"]
        if row.get("mean") is not None
    }


def _risk_band(score: int) -> str:
    if score >= 12:
        return "critical"
    if score >= 8:
        return "high"
    if score >= 4:
        return "moderate"
    return "low"


def _likelihood(score: float) -> int:
    if score < 2.5:
        return 4
    if score < 3.2:
        return 3
    if score < 3.8:
        return 2
    return 1


def generate_risk_matrix(
    profile: dict[str, Any],
    analysis: dict[str, Any],
) -> dict[str, Any]:
    scores = _score_map(analysis)
    pain = set(profile.get("pain_points", []))
    systems = set(profile.get("current_systems", []))
    hazardous = profile.get("industry") in {"chemical", "pharma", "food", "new_materials"}
    large = profile.get("company_size") in {"large", "enterprise"}
    lowest_layer = min(PCIO_LAYERS, key=lambda layer: scores.get(layer, 5.0))
    candidates: list[dict[str, Any]] = []
    for item in RISK_CATALOG:
        layer_scores = [scores.get(layer, 3.0) for layer in item["layers"]]
        relevant_score = min(layer_scores) if layer_scores else 3.0
        driver_matches = sorted(pain.intersection(item["drivers"]))
        likelihood = _likelihood(relevant_score)
        if driver_matches:
            likelihood = min(4, likelihood + 1)
        if item["id"] == "T02" and {"paper", "excel"}.intersection(systems):
            likelihood = min(4, likelihood + 1)
        if item["id"] == "T04":
            foundation = min(scores.get(layer, 3.0) for layer in ("P", "C", "I"))
            likelihood = max(likelihood, _likelihood(foundation))
        impact = 2
        if driver_matches:
            impact += 1
        if hazardous and item["category"] == "technical":
            impact += 1
        if hazardous and item["id"] in {"H03", "E03"}:
            impact += 1
        if large and item["category"] in {"organisational", "external"}:
            impact += 1
        impact = min(4, impact)
        score = likelihood * impact
        relevance = (
            score
            + 2 * len(driver_matches)
            + (2 if lowest_layer in item["layers"] else 0)
            + (1 if relevant_score < 3.2 else 0)
        )
        band = _risk_band(score)
        candidates.append(
            {
                "risk_id": item["id"],
                "category": item["category"],
                "category_zh": CATEGORY_LABELS[item["category"]]["zh"],
                "category_en": CATEGORY_LABELS[item["category"]]["en"],
                "title_zh": item["title_zh"],
                "title_en": item["title_en"],
                "pcio_layers": item["layers"],
                "driver_matches": driver_matches,
                "likelihood": likelihood,
                "impact": impact,
                "score": score,
                "band": band,
                "band_zh": RISK_BANDS[band]["zh"],
                "band_en": RISK_BANDS[band]["en"],
                "color": f"#{RISK_COLORS[band]}",
                "pdca_stage": item["pdca"],
                "mitigation_zh": item["mitigation_zh"],
                "mitigation_en": item["mitigation_en"],
                "relevance_score": relevance,
            }
        )
    selected_ids: set[str] = set()
    for category in CATEGORY_LABELS:
        category_rows = sorted(
            (row for row in candidates if row["category"] == category),
            key=lambda row: (-row["relevance_score"], row["risk_id"]),
        )
        selected_ids.update(row["risk_id"] for row in category_rows[:2])
    remaining = sorted(
        (row for row in candidates if row["risk_id"] not in selected_ids),
        key=lambda row: (-row["relevance_score"], row["risk_id"]),
    )
    selected_ids.update(row["risk_id"] for row in remaining[:2])
    selected = sorted(
        (row for row in candidates if row["risk_id"] in selected_ids),
        key=lambda row: (-row["score"], -row["relevance_score"], row["risk_id"]),
    )
    highlighted_ids = {row["risk_id"] for row in selected[:4]}
    for rank, row in enumerate(selected, start=1):
        row["priority_rank"] = rank
        row["highlighted"] = row["risk_id"] in highlighted_ids
    matrix = []
    for likelihood in range(4, 0, -1):
        cells = []
        for impact in range(1, 5):
            cell_risks = [
                row["risk_id"]
                for row in selected
                if row["likelihood"] == likelihood and row["impact"] == impact
            ]
            band = _risk_band(likelihood * impact)
            cells.append(
                {
                    "likelihood": likelihood,
                    "impact": impact,
                    "score": likelihood * impact,
                    "band": band,
                    "color": f"#{RISK_COLORS[band]}",
                    "risk_ids": cell_risks,
                }
            )
        matrix.append({"likelihood": likelihood, "cells": cells})
    return {
        "method": {
            "likelihood": "1-4 from the weakest relevant PCIO/H score, adjusted by profile drivers",
            "impact": "1-4 from pain-point relevance, process criticality, and company scale",
            "score": "likelihood × impact",
            "selection": "top two risks per category plus two highest remaining risks",
            "bands": "1-3 low; 4-7 moderate; 8-11 high; 12-16 critical",
        },
        "lowest_pcio_layer": lowest_layer,
        "risks": selected,
        "matrix": matrix,
        "category_counts": dict(Counter(row["category"] for row in selected)),
        "band_counts": dict(Counter(row["band"] for row in selected)),
    }


def _scenario_factor(scores: dict[str, float], n: int) -> tuple[float, float]:
    foundation = sum(scores.get(layer, 2.5) for layer in ("P", "C", "I")) / 15
    lowest = min(scores.get(layer, 2.5) for layer in PCIO_LAYERS)
    headroom = max(0.0, min(1.0, (IDEAL_TARGET - lowest) / 3.2))
    confidence = min(1.0, n / 50)
    base = max(
        0.4,
        min(0.82, 0.30 + 0.30 * foundation + 0.15 * headroom + 0.07 * confidence),
    )
    return max(0.3, base - 0.12), min(0.95, base + 0.12)


def generate_kpi_recommendations(
    profile: dict[str, Any],
    analysis: dict[str, Any],
) -> list[dict[str, Any]]:
    scores = _score_map(analysis)
    pain = set(profile.get("pain_points", []))
    n = analysis["data_quality"]["retained_rows"]
    low_factor, high_factor = _scenario_factor(scores, n)
    significant = {
        row["predictor"]
        for row in analysis["interpretation"].get("significant_overall_predictors", [])
    }
    rows: list[dict[str, Any]] = []

    def add(
        kpi_id: str,
        layer: str,
        name_zh: str,
        name_en: str,
        unit: str,
        target_low: float,
        target_high: float,
        direction: str,
        rationale_zh: str,
        rationale_en: str,
        evidence: str,
        pain_weight: int = 0,
        outcome_zh: str = "",
        outcome_en: str = "",
    ) -> None:
        current = scores.get(layer, 3.0)
        priority_score = (
            max(0.0, IDEAL_TARGET - current) * 2
            + pain_weight
            + (1.0 if layer in significant else 0.0)
        )
        rows.append(
            {
                "kpi_id": kpi_id,
                "pcio_layer": layer,
                "name_zh": name_zh,
                "name_en": name_en,
                "unit": unit,
                "current_maturity_score": current,
                "operational_baseline": "现场数据待确认 / Operational baseline required",
                "target_low": round(target_low, 2),
                "target_high": round(target_high, 2),
                "direction": direction,
                "horizon": "12 weeks / 12周试点",
                "rationale_zh": rationale_zh,
                "rationale_en": rationale_en,
                "expected_outcome_zh": outcome_zh,
                "expected_outcome_en": outcome_en,
                "evidence": evidence,
                "priority_score": priority_score,
            }
        )

    add(
        "KPI-P-01",
        "P",
        "关键测点有效覆盖率",
        "Valid coverage of critical tags",
        "%",
        90 if scores.get("P", 3) < 3.2 else 95,
        95 if scores.get("P", 3) < 3.2 else 98,
        "higher",
        "感知层是后续连接、集成和优化的输入门槛。",
        "Perception is the input gate for connectivity, integration, and optimisation.",
        "External n=52 Sensor_Inf=4.5077 reference + project score",
    )
    add(
        "KPI-C-01",
        "C",
        "试点数据采集可用率",
        "Pilot data-acquisition availability",
        "%",
        97,
        99,
        "higher",
        "用链路可用率代替“已联网”这一不可审计描述。",
        "Use measurable link availability rather than a binary 'connected' claim.",
        "Toolkit operating target (P)",
    )
    add(
        "KPI-I-01",
        "I",
        "关键测点与设备/批次/工单映射完整率",
        "Completeness of tag-to-asset/batch/work-order mapping",
        "%",
        90,
        95,
        "higher",
        "当前集成能力决定统计结果能否回到具体业务情境。",
        "Integration determines whether analysis can be traced back to business context.",
        "Toolkit operating target (P)",
    )
    add(
        "KPI-O-01",
        "O",
        "异常闭环按期完成率",
        "On-time exception closure rate",
        "%",
        80,
        90,
        "higher",
        "优化层先验证规则和行动闭环，再进入高级模型。",
        "Optimisation should validate rules and action closure before advanced models.",
        "Toolkit operating target (P)",
    )
    add(
        "KPI-H-01",
        "H",
        "目标岗位任务验证通过率",
        "Task-based competence pass rate for target roles",
        "%",
        90,
        95,
        "higher",
        "培训完成不等于会用，以真实任务验证人机协同能力。",
        "Training completion is not competence; verify with real tasks.",
        "Toolkit operating target (P)",
    )

    if "process_variation" in pain:
        add(
            "KPI-B-01",
            "P",
            "关键工艺参数波动幅度",
            "Critical process-parameter variation",
            "% reduction",
            10,
            20,
            "lower",
            "先验证测点和回路，再评估更严格的控制目标。",
            "Validate tags and loops before evaluating tighter control targets.",
            "PCIO-E008 (E2) adjusted as planning scenario (P)",
            pain_weight=3,
            outcome_zh="±0.5℃仅作为基础门槛通过后的挑战参考。",
            outcome_en="±0.5°C is a stretch reference only after foundation gates pass.",
        )
    if "energy_cost" in pain:
        add(
            "KPI-B-02",
            "P",
            "单位产品蒸汽/能源消耗",
            "Steam or energy consumption per unit",
            "% reduction",
            15.3 * low_factor,
            15.3 * high_factor,
            "lower",
            "以分项计量和同产品基线验证能源改善。",
            "Validate energy improvement with sub-metering and comparable product baselines.",
            "PCIO-E009 (E2) adjusted as planning scenario (P)",
            pain_weight=3,
        )
    if "equipment_downtime" in pain:
        add(
            "KPI-B-03",
            "O",
            "非计划停机时间",
            "Unplanned downtime",
            "% reduction",
            5,
            12,
            "lower",
            "以统一停机原因和连续基线验证规则报警价值。",
            "Use standard downtime reasons and a continuous baseline to validate alert value.",
            "Toolkit planning scenario (P)",
            pain_weight=3,
        )
    if "quality_defects" in pain:
        add(
            "KPI-B-04",
            "O",
            "返工/缺陷率",
            "Rework or defect rate",
            "% reduction",
            5,
            10,
            "lower",
            "保持产品组合和检验口径一致。",
            "Hold product mix and inspection definitions constant.",
            "Toolkit planning scenario (P)",
            pain_weight=3,
        )
    if "manual_records" in pain:
        add(
            "KPI-B-05",
            "I",
            "人工重复记录时间",
            "Duplicate manual recording time",
            "% reduction",
            15,
            30,
            "lower",
            "数字化上线时同步取消等量重复纸质步骤。",
            "Retire equivalent duplicate paper steps when digital capture goes live.",
            "Toolkit planning scenario (P)",
            pain_weight=3,
        )
    flexibility = scores.get("PERF_FLEX")
    if "schedule_changeover" in pain or (flexibility is not None and flexibility < 3.2):
        add(
            "KPI-B-06",
            "P",
            "瓶颈设备状态感知覆盖率",
            "State-sensing coverage for bottleneck assets",
            "%",
            90,
            95,
            "higher",
            "柔性较低时先补齐设备状态、节拍、等待和停机原因，而不是直接上排产 AI。",
            "When flexibility is low, capture state, cycle, waiting, and downtime reasons before scheduling AI.",
            "External n=52 sensor-priority reference + toolkit scenario (P)",
            pain_weight=3,
            outcome_zh="柔性绩效问卷分数试点提升 0.2-0.5/5，须与换产/等待时间交叉验证。",
            outcome_en="Pilot flexibility-score improvement of 0.2-0.5/5, triangulated with changeover or waiting time.",
        )
    if profile.get("production_type") == "tank_loading":
        add(
            "KPI-B-07",
            "O",
            "装卸作业周期",
            "Loading and unloading cycle time",
            "% reduction",
            29 * low_factor,
            29 * high_factor,
            "lower",
            "统一开始/结束时间戳和异常剔除规则。",
            "Standardise start/end timestamps and exception exclusions.",
            "PCIO-E010 (E2) adjusted as planning scenario (P)",
            pain_weight=3,
        )

    rows.sort(key=lambda row: (-row["priority_score"], row["kpi_id"]))
    for rank, row in enumerate(rows[:10], start=1):
        row["priority_rank"] = rank
        row["priority"] = "urgent" if rank <= 3 else "high" if rank <= 6 else "medium"
    return json_safe(rows[:10])


def recommended_roi_assumptions(
    profile: dict[str, Any],
    analysis: dict[str, Any],
    kpis: list[dict[str, Any]],
) -> dict[str, Any]:
    defaults = profile_roi_input_defaults(profile)
    investment = defaults["investment"]
    addressable = defaults["annual_addressable_value"]
    operating = defaults["annual_operating_cost"]
    improvement_low = defaults["improvement_low_pct"]
    improvement_high = defaults["improvement_high_pct"]
    source = defaults["source"]
    business_kpis = [
        row
        for row in kpis
        if row["kpi_id"].startswith("KPI-B")
        and ("% reduction" in row["unit"] or row["unit"] == "%")
    ]
    if business_kpis:
        improvement_low = float(business_kpis[0]["target_low"])
        improvement_high = float(business_kpis[0]["target_high"])
        source = business_kpis[0]["kpi_id"]
    return {
        **defaults,
        "investment": investment,
        "annual_addressable_value": addressable,
        "annual_operating_cost": operating,
        "improvement_low_pct": round(improvement_low, 2),
        "improvement_high_pct": round(improvement_high, 2),
        "source": source,
    }


def profile_roi_input_defaults(profile: dict[str, Any]) -> dict[str, Any]:
    size_defaults = {
        "micro": (80000, 600000, 12000),
        "small": (150000, 1000000, 20000),
        "medium": (300000, 2400000, 45000),
        "large": (800000, 6000000, 120000),
        "enterprise": (1200000, 10000000, 180000),
    }
    investment, addressable, operating = size_defaults.get(
        profile.get("company_size"), size_defaults["small"]
    )
    pain = set(profile.get("pain_points", []))
    if "energy_cost" in pain or "equipment_downtime" in pain:
        improvement_low, improvement_high, source = 5.0, 12.0, "profile_pain_point"
    elif "quality_defects" in pain:
        improvement_low, improvement_high, source = 5.0, 10.0, "profile_pain_point"
    elif "manual_records" in pain:
        improvement_low, improvement_high, source = 15.0, 30.0, "profile_pain_point"
    elif "schedule_changeover" in pain:
        improvement_low, improvement_high, source = 8.0, 15.0, "profile_pain_point"
    else:
        improvement_low, improvement_high, source = 5.0, 10.0, "generic"
    return {
        "currency": "CNY",
        "investment": investment,
        "annual_addressable_value": addressable,
        "annual_operating_cost": operating,
        "improvement_low_pct": round(improvement_low, 2),
        "improvement_high_pct": round(improvement_high, 2),
        "horizon_years": 3,
        "source": source,
        "assumption_note_zh": "金额为按公司规模生成的可编辑规划占位值，不是行业报价或收益承诺。",
        "assumption_note_en": "Amounts are editable planning placeholders based on company size, not market quotes or benefit guarantees.",
    }


def calculate_roi(inputs: dict[str, Any]) -> dict[str, Any]:
    investment = max(0.0, float(inputs.get("investment", 0)))
    addressable = max(0.0, float(inputs.get("annual_addressable_value", 0)))
    operating = max(0.0, float(inputs.get("annual_operating_cost", 0)))
    low = max(0.0, float(inputs.get("improvement_low_pct", 0)))
    high = max(low, float(inputs.get("improvement_high_pct", low)))
    horizon = max(1, int(inputs.get("horizon_years", 3)))
    scenarios = []
    for name, improvement in (
        ("conservative", low),
        ("base", (low + high) / 2),
        ("optimistic", high),
    ):
        gross = addressable * improvement / 100
        net = gross - operating
        payback = investment / net * 12 if investment > 0 and net > 0 else None
        roi = ((net * horizon - investment) / investment * 100) if investment > 0 else None
        scenarios.append(
            {
                "scenario": name,
                "improvement_pct": improvement,
                "annual_gross_benefit": gross,
                "annual_net_benefit": net,
                "payback_months": payback,
                f"roi_{horizon}y_pct": roi,
            }
        )
    paybacks = [
        row["payback_months"] for row in scenarios if row["payback_months"] is not None
    ]
    break_even = (
        (operating + investment / horizon) / addressable * 100
        if addressable > 0
        else None
    )
    return json_safe(
        {
            "inputs": inputs,
            "scenarios": scenarios,
            "payback_range_months": {
                "optimistic": min(paybacks) if paybacks else None,
                "conservative": max(paybacks) if paybacks else None,
            },
            "break_even_improvement_pct": break_even,
            "interpretation_zh": "回收期为简单静态估算，未计税、折旧、资金成本、停产损失或爬坡曲线。",
            "interpretation_en": "Payback is a simple static estimate excluding tax, depreciation, cost of capital, downtime, and ramp-up.",
        }
    )


def generate_decision_support(
    profile: dict[str, Any],
    analysis: dict[str, Any],
    roi_inputs: dict[str, Any] | None = None,
    schema: dict[str, Any] | None = None,
) -> dict[str, Any]:
    schema = schema or load_schema()
    risk = generate_risk_matrix(profile, analysis)
    kpis = generate_kpi_recommendations(profile, analysis)
    assumptions = roi_inputs or recommended_roi_assumptions(profile, analysis, kpis)
    roi = calculate_roi(assumptions)
    return {
        "decision_support_version": "4.0.0",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "profile": profile,
        "risk": risk,
        "kpis": kpis,
        "roi": roi,
        "evidence_boundary": {
            "zh": "风险分数和 KPI/ROI 区间用于筛选与立项，不构成安全结论、预算报价或收益承诺。",
            "en": "Risk scores and KPI/ROI ranges support screening and approval; they are not safety conclusions, price quotes, or benefit guarantees.",
        },
    }


def decision_support_markdown(decision: dict[str, Any]) -> str:
    profile = decision["profile"]
    risks = decision["risk"]["risks"]
    kpis = decision["kpis"]
    roi = decision["roi"]
    lines = [
        f"# {profile.get('company_name', profile.get('project_code', 'Company'))} PCIO 风险、KPI 与 ROI 摘要",
        "# PCIO Risk, KPI, and ROI Summary",
        "",
        f"**项目代码 / Project code:** {profile.get('project_code', '-')}",
        f"**证据边界 / Evidence boundary:** {decision['evidence_boundary']['zh']} / {decision['evidence_boundary']['en']}",
        "",
        "## 1. 优先风险 / Priority Risks",
        "",
        "| 排名 | ID | 类别 | 风险 / Risk | 概率 | 影响 | 得分 | PDCA |",
        "|---:|---|---|---|---:|---:|---:|---|",
    ]
    for row in risks:
        lines.append(
            f"| {row['priority_rank']} | {row['risk_id']} | {row['category_zh']} / {row['category_en']} | "
            f"{row['title_zh']} / {row['title_en']} | {row['likelihood']} | {row['impact']} | "
            f"{row['score']} | {row['pdca_stage']} |"
        )
    lines.extend(
        [
            "",
            "## 2. KPI 建议 / KPI Recommendations",
            "",
            "| 排名 | KPI | PCIO | 目标 / Target | 情景说明 / Scenario |",
            "|---:|---|---|---|---|",
        ]
    )
    for row in kpis:
        target = f"{row['target_low']}-{row['target_high']} {row['unit']}"
        outcome = row["expected_outcome_zh"] or row["rationale_zh"]
        lines.append(
            f"| {row['priority_rank']} | {row['name_zh']} / {row['name_en']} | "
            f"{row['pcio_layer']} | {target} | {outcome} |"
        )
    payback = roi["payback_range_months"]
    lines.extend(
        [
            "",
            "## 3. ROI 快速估算 / Rapid ROI Estimate",
            "",
            f"- 投资 / Investment: {roi['inputs'].get('currency', 'CNY')} {roi['inputs']['investment']:,.0f}",
            f"- 年度可改善价值池 / Annual addressable value: {roi['inputs'].get('currency', 'CNY')} {roi['inputs']['annual_addressable_value']:,.0f}",
            f"- 改善假设 / Improvement assumption: {roi['inputs']['improvement_low_pct']:.1f}%-{roi['inputs']['improvement_high_pct']:.1f}%",
            f"- 静态回收期 / Simple payback: {_format_range(payback['optimistic'], payback['conservative'], 'months')}",
            f"- 说明 / Note: {roi['interpretation_zh']} / {roi['interpretation_en']}",
        ]
    )
    risk_snapshot = "、".join(
        f"{row['risk_id']}={row['score']}" for row in risks
    )
    kpi_snapshot = "；".join(
        f"{row['name_zh']}：成熟度 {row['current_maturity_score']:.4f} → "
        f"{row['target_low']}-{row['target_high']} {row['unit']}"
        for row in kpis
    )
    scenario_rows = [
        (
            "保守 / Conservative"
            if row["scenario"] == "conservative"
            else "基准 / Base"
            if row["scenario"] == "base"
            else "乐观 / Optimistic",
            row,
        )
        for row in roi["scenarios"]
    ]
    lines.extend(
        [
            "",
            "## 4. 企业改善操作流程 / Enterprise Improvement Workflow",
            "",
            f"**当前风险 / Current risks:** {risk_snapshot}",
            "",
            f"**当前 KPI 与目标 / Current KPIs and targets:** {kpi_snapshot}",
            "",
            "| 情景 / Scenario | 改善率 | 年度毛收益 | 年度净收益 | 静态回收期 | 三年 ROI |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for name, row in scenario_rows:
        payback_text = (
            f"{row['payback_months']:.1f} months"
            if row["payback_months"] is not None
            else "N/A"
        )
        roi_text = (
            f"{row['roi_3y_pct']:.1f}%"
            if row["roi_3y_pct"] is not None
            else "N/A"
        )
        lines.append(
            f"| {name} | {row['improvement_pct']:.1f}% | "
            f"{row['annual_gross_benefit']:,.0f} | "
            f"{row['annual_net_benefit']:,.0f} | {payback_text} | {roi_text} |"
        )
    top_risks = risks[:5]
    top_risk_text = ", ".join(
        f"{row['risk_id']}={row['score']}" for row in top_risks
    )
    lines.extend(
        [
            "",
            "### Plan（计划） / Plan",
            "",
            f"1. 按 4×4 得分优先处理 {top_risk_text}；"
            "12-16 分立即处置，8-11 分进入第二波，7 分及以下持续监控。",
            "2. 将试点限定在公司画像的 `pilot_scope`，建议 8-12 周、一条线、一个班组和 3-5 台关键设备。",
            "3. 第一轮建议按 P 40%、C 25%、I 20%、O 15% 配置实施资源，并另行安排培训、校准、安全审查和停机窗口。",
            "4. 为每个 KPI 明确数据源、公式、责任人、基线、3 个月门槛和 6 个月目标。",
            "5. 以保守 ROI 情景作为扩线门槛；未形成可审计的实际净收益前不扩大投资。",
            "",
            "Prioritise 12-16 risks immediately, restrict the pilot to one line or cell for 8-12 weeks, define auditable KPI sources and owners, and use the conservative ROI case as the scale gate.",
            "",
            "### Do（执行） / Do",
            "",
            "- **P - Perception:** 建立关键测点台账；完成校准与现场比对；复用现有 PLC/仪表接口；补齐缺失状态；设置缺失、冻结、漂移和时间戳规则。",
            "- **C - Connectivity:** 绘制网络与数据去向；监测可用率、延迟和丢包；配置边缘缓存与断点续传；实施分区和最小权限；开展断线恢复演练。",
            "- **I - Integration:** 统一设备、工单、批次、单位和 KPI 编码；建立映射表；先做最小接口；按角色共享看板；把异常纳入电子闭环和交接班。",
            "- **O - Optimisation:** 对主要损失做 Pareto；为参数试验设置审批和回退；先规则/趋势后模型；采用小范围对照验证；把有效规则固化为 SOP。",
            "",
            "Execute foundation-first actions across P/C/I/O, retain calibration, configuration, training, exception, and financial evidence, and preserve human confirmation and safe rollback.",
            "",
            "### Check（检查） / Check",
            "",
            "1. 前 12 周每周检查数据缺失、断线、告警、异常关闭、培训参与和试验偏差。",
            "2. **建议在实施后 3 个月进行第一次完整复测**：使用相同问卷版本、计分规则和尽可能相同的岗位结构；12-16 分风险应至少下降 4 分或一个等级，重点成熟度分数建议提高至少 0.20/5。",
            "3. **建议在实施后 6 个月进行第二次复盘测试**：检查风险是否稳定在 7 分及以下、成熟度累计改善是否达到约 0.35/5、KPI 是否持续以及真实收益是否支持基准情景。",
            "",
            "Conduct the first full retest at month 3 and the second review at month 6, using consistent instruments and auditable operational and financial evidence.",
            "",
            "### Act（改进） / Act",
            "",
            "- 达到门槛：固化为 SOP，并仅向一条相邻产线复制。",
            "- 部分达到：复盘人、机、料、法、环和测量系统，调整后再试。",
            "- 未达到或风险上升：停止扩线，执行安全回退并重算 ROI。",
            "- 证据不足：补充基线、日志、校准和样本代表性，不把感知变化直接当作财务收益。",
            "- 将 6 个月结果转为下一轮 Plan，更新风险、KPI、资源和试点边界。",
            "",
            "Standardise only verified gains, correct partial results, roll back unsafe or ineffective changes, and feed month-6 evidence into the next PDCA cycle.",
            "",
            "## 5. 前五项行动摘要 / Top-Five Action Summary",
            "",
            "| 优先级 | 风险 | PCIO | 行动 / Action | 预期效果 / Expected effect | 复测 / Retest |",
            "|---:|---|---|---|---|---|",
        ]
    )
    for index, risk in enumerate(top_risks, start=1):
        layer = risk["pcio_layers"][0] if risk["pcio_layers"] else "-"
        lines.append(
            f"| {index} | {risk['risk_id']}={risk['score']} | {layer} | "
            f"{risk['mitigation_zh']} / {risk['mitigation_en']} | "
            f"风险降至 7 分及以下或至少下降 4 分 / Reduce to 7 or below or by at least 4 points | "
            "3 个月首次完整复测；6 个月第二次复盘 / Months 3 and 6 |"
        )
    lines.extend(
        [
            "",
            "> 简要结论：先处理最高风险并夯实 P/C 基础，再完成 I 的统一口径和 O 的闭环验证；3 个月决定纠偏，6 个月决定标准化和扩线。所有数值仅供参考。",
            "",
            "> Summary: address the highest risks and stabilise P/C first, then complete I definitions and O closed-loop validation. Month 3 determines correction; month 6 determines standardisation and scaling. All values are for reference only.",
        ]
    )
    return "\n".join(lines) + "\n"


def _format_range(low: float | None, high: float | None, unit: str) -> str:
    if low is None or high is None:
        return "N/A"
    return f"{low:.1f}-{high:.1f} {unit}"


def decision_support_excel_bytes(decision: dict[str, Any]) -> bytes:
    workbook = Workbook()
    dashboard = workbook.active
    dashboard.title = "Dashboard"
    dashboard.sheet_view.showGridLines = False
    dashboard.merge_cells("A1:H2")
    dashboard["A1"] = "PCIO Risk, KPI & ROI Dashboard / 风险、KPI与ROI总览"
    dashboard["A1"].font = Font(size=18, bold=True, color="FFFFFF")
    dashboard["A1"].fill = PatternFill("solid", fgColor="16324F")
    dashboard["A1"].alignment = Alignment(horizontal="left", vertical="center")
    risks = decision["risk"]["risks"]
    kpis = decision["kpis"]
    roi = decision["roi"]
    high_count = sum(row["band"] in {"high", "critical"} for row in risks)
    payback = roi["payback_range_months"]
    cards = [
        ("A4", "Selected risks / 已筛选风险", len(risks)),
        ("C4", "High & critical / 高及极高", high_count),
        ("E4", "Recommended KPIs / KPI建议", len(kpis)),
        (
            "G4",
            "Payback months / 回收期",
            _format_range(payback["optimistic"], payback["conservative"], ""),
        ),
    ]
    thin = Side(style="thin", color="D9E1E8")
    for cell, label, value in cards:
        column = dashboard[cell].column
        dashboard.cell(4, column, label)
        dashboard.cell(5, column, value)
        dashboard.merge_cells(start_row=4, start_column=column, end_row=4, end_column=column + 1)
        dashboard.merge_cells(start_row=5, start_column=column, end_row=5, end_column=column + 1)
        dashboard.cell(4, column).fill = PatternFill("solid", fgColor="DDEBF7")
        dashboard.cell(4, column).font = Font(bold=True, color="16324F")
        dashboard.cell(5, column).font = Font(size=15, bold=True, color="0F766E")
        for row_index in (4, 5):
            dashboard.cell(row_index, column).alignment = Alignment(
                horizontal="center", vertical="center", wrap_text=True
            )
            dashboard.cell(row_index, column).border = Border(
                top=thin, bottom=thin, left=thin, right=thin
            )

    dashboard["A8"] = "Likelihood / 概率"
    for impact in range(1, 5):
        dashboard.cell(8, impact + 1, f"Impact {impact} / 影响{impact}")
    matrix_lookup = {
        (cell["likelihood"], cell["impact"]): cell
        for row in decision["risk"]["matrix"]
        for cell in row["cells"]
    }
    for row_index, likelihood in enumerate(range(4, 0, -1), start=9):
        dashboard.cell(row_index, 1, f"{likelihood}")
        for impact in range(1, 5):
            cell = matrix_lookup[(likelihood, impact)]
            target = dashboard.cell(row_index, impact + 1)
            target.value = "\n".join(cell["risk_ids"]) or "-"
            target.fill = PatternFill("solid", fgColor=RISK_COLORS[cell["band"]])
            target.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            target.border = Border(top=thin, bottom=thin, left=thin, right=thin)
    for cell in dashboard["8:8"]:
        if cell.column <= 5:
            cell.fill = PatternFill("solid", fgColor="0F766E")
            cell.font = Font(bold=True, color="FFFFFF")
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    dashboard["A14"] = "4×4 score = likelihood × impact. IDs map to Risk_Register."
    dashboard.merge_cells("A14:E14")
    dashboard["A14"].font = Font(italic=True, color="666666")

    dashboard["A17"] = "Risk category / 风险类别"
    dashboard["B17"] = "Count / 数量"
    for index, category in enumerate(CATEGORY_LABELS, start=18):
        dashboard.cell(index, 1, f"{CATEGORY_LABELS[category]['en']} / {CATEGORY_LABELS[category]['zh']}")
        dashboard.cell(index, 2, decision["risk"]["category_counts"].get(category, 0))
    chart = BarChart()
    chart.type = "col"
    chart.title = "Selected risks by category / 分类风险数"
    chart.add_data(Reference(dashboard, min_col=2, min_row=17, max_row=21), titles_from_data=True)
    chart.set_categories(Reference(dashboard, min_col=1, min_row=18, max_row=21))
    chart.height = 7
    chart.width = 12
    chart.legend = None
    dashboard.add_chart(chart, "D16")
    for column, width in {"A": 28, "B": 18, "C": 18, "D": 20, "E": 20, "F": 16, "G": 18, "H": 18}.items():
        dashboard.column_dimensions[column].width = width
    for row_index in range(9, 13):
        dashboard.row_dimensions[row_index].height = 50
    dashboard.freeze_panes = "A8"

    risk_sheet = workbook.create_sheet("Risk_Register")
    risk_headers = [
        "Rank",
        "ID",
        "Category",
        "Risk ZH",
        "Risk EN",
        "PCIO layers",
        "Likelihood",
        "Impact",
        "Score",
        "Band",
        "PDCA",
        "Mitigation ZH",
        "Mitigation EN",
        "Profile drivers",
        "Highlighted",
    ]
    risk_sheet.append(risk_headers)
    for row in risks:
        risk_sheet.append(
            [
                row["priority_rank"],
                row["risk_id"],
                f"{row['category_en']} / {row['category_zh']}",
                row["title_zh"],
                row["title_en"],
                ",".join(row["pcio_layers"]),
                row["likelihood"],
                row["impact"],
                row["score"],
                f"{row['band_en']} / {row['band_zh']}",
                row["pdca_stage"],
                row["mitigation_zh"],
                row["mitigation_en"],
                ",".join(row["driver_matches"]),
                row["highlighted"],
            ]
        )
        fill = PatternFill("solid", fgColor=RISK_COLORS[row["band"]])
        for column in range(1, len(risk_headers) + 1):
            risk_sheet.cell(risk_sheet.max_row, column).fill = fill

    matrix_sheet = workbook.create_sheet("Risk_Matrix_4x4")
    matrix_sheet.append(["Likelihood \\ Impact", 1, 2, 3, 4])
    for matrix_row in decision["risk"]["matrix"]:
        matrix_sheet.append(
            [
                matrix_row["likelihood"],
                *["\n".join(cell["risk_ids"]) or "-" for cell in matrix_row["cells"]],
            ]
        )
        for column, cell in enumerate(matrix_row["cells"], start=2):
            matrix_sheet.cell(matrix_sheet.max_row, column).fill = PatternFill(
                "solid", fgColor=RISK_COLORS[cell["band"]]
            )
            matrix_sheet.cell(matrix_sheet.max_row, column).alignment = Alignment(
                horizontal="center", vertical="center", wrap_text=True
            )

    kpi_sheet = workbook.create_sheet("KPI_Recommendations")
    kpi_headers = [
        "Rank",
        "Priority",
        "KPI ID",
        "PCIO",
        "KPI ZH",
        "KPI EN",
        "Current maturity",
        "Operational baseline",
        "Target low",
        "Target high",
        "Unit",
        "Direction",
        "Horizon",
        "Rationale ZH",
        "Rationale EN",
        "Expected outcome ZH",
        "Expected outcome EN",
        "Evidence",
    ]
    kpi_sheet.append(kpi_headers)
    for row in kpis:
        kpi_sheet.append(
            [
                row["priority_rank"],
                row["priority"],
                row["kpi_id"],
                row["pcio_layer"],
                row["name_zh"],
                row["name_en"],
                row["current_maturity_score"],
                row["operational_baseline"],
                row["target_low"],
                row["target_high"],
                row["unit"],
                row["direction"],
                row["horizon"],
                row["rationale_zh"],
                row["rationale_en"],
                row["expected_outcome_zh"],
                row["expected_outcome_en"],
                row["evidence"],
            ]
        )

    roi_sheet = workbook.create_sheet("ROI_Calculator")
    roi_sheet["A1"] = "Editable ROI Calculator / 可编辑 ROI 快速估算"
    roi_sheet.merge_cells("A1:F1")
    roi_sheet["A1"].font = Font(size=16, bold=True, color="FFFFFF")
    roi_sheet["A1"].fill = PatternFill("solid", fgColor="16324F")
    inputs = roi["inputs"]
    input_rows = [
        ("Investment / 投资", inputs["investment"]),
        ("Annual addressable value / 年度可改善价值池", inputs["annual_addressable_value"]),
        ("Annual operating cost / 年度运维成本", inputs["annual_operating_cost"]),
        ("Improvement low % / 改善下限", inputs["improvement_low_pct"] / 100),
        ("Improvement high % / 改善上限", inputs["improvement_high_pct"] / 100),
        ("Horizon years / 评估年数", inputs["horizon_years"]),
    ]
    for index, (label, value) in enumerate(input_rows, start=3):
        roi_sheet.cell(index, 1, label)
        roi_sheet.cell(index, 2, value)
        roi_sheet.cell(index, 2).fill = PatternFill("solid", fgColor="FFF2CC")
    roi_sheet["B6"].number_format = "0.0%"
    roi_sheet["B7"].number_format = "0.0%"
    roi_sheet.append([])
    roi_sheet.append(["Scenario", "Improvement", "Gross benefit/year", "Net benefit/year", "Payback months", "ROI over horizon"])
    scenario_row = roi_sheet.max_row + 1
    for offset, (name, formula) in enumerate(
        [("Conservative", "=$B$6"), ("Base", "=AVERAGE($B$6,$B$7)"), ("Optimistic", "=$B$7")]
    ):
        row_index = scenario_row + offset
        roi_sheet.cell(row_index, 1, name)
        roi_sheet.cell(row_index, 2, formula)
        roi_sheet.cell(row_index, 3, f"=$B$4*B{row_index}")
        roi_sheet.cell(row_index, 4, f"=C{row_index}-$B$5")
        roi_sheet.cell(row_index, 5, f'=IF(D{row_index}>0,$B$3/D{row_index}*12,"N/A")')
        roi_sheet.cell(row_index, 6, f'=IF($B$3>0,(D{row_index}*$B$8-$B$3)/$B$3,"N/A")')
        roi_sheet.cell(row_index, 2).number_format = "0.0%"
        roi_sheet.cell(row_index, 6).number_format = "0.0%"
    roi_sheet.cell(scenario_row + 4, 1, "Break-even improvement / 盈亏平衡改善率")
    roi_sheet.cell(scenario_row + 4, 2, "=IF(B4>0,(B5+B3/B8)/B4,0)")
    roi_sheet.cell(scenario_row + 4, 2).number_format = "0.0%"
    roi_sheet.cell(scenario_row + 6, 1, "Boundary / 边界")
    roi_sheet.cell(scenario_row + 6, 2, roi["interpretation_zh"] + " / " + roi["interpretation_en"])
    roi_sheet.merge_cells(
        start_row=scenario_row + 6,
        start_column=2,
        end_row=scenario_row + 7,
        end_column=6,
    )
    roi_sheet.cell(scenario_row + 6, 2).alignment = Alignment(wrap_text=True, vertical="top")

    for sheet in workbook.worksheets:
        sheet.sheet_view.showGridLines = False
        if sheet.title != "Dashboard":
            sheet.freeze_panes = "A2"
            sheet.auto_filter.ref = sheet.dimensions
        if sheet.max_row >= 1:
            for cell in sheet[1]:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="16324F")
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for column_index, column_cells in enumerate(sheet.columns, start=1):
            letter = get_column_letter(column_index)
            longest = max(
                (len(str(cell.value)) if cell.value is not None else 0 for cell in column_cells),
                default=0,
            )
            sheet.column_dimensions[letter].width = min(42, max(11, longest + 2))
        for row in sheet.iter_rows():
            for cell in row:
                cell.alignment = Alignment(
                    vertical=cell.alignment.vertical or "top",
                    horizontal=cell.alignment.horizontal,
                    wrap_text=True,
                )
    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def complete_package_zip_bytes(
    profile: dict[str, Any],
    analysis: dict[str, Any],
    report_markdown: str,
    decision: dict[str, Any],
    analysis_excel: bytes,
) -> bytes:
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(
            "company_profile.json",
            json.dumps(profile, ensure_ascii=False, indent=2),
        )
        archive.writestr(
            "README-bilingual.txt",
            "本分析包由 PCIO Toolkit 自动生成。示例数据和改善区间仅供参考，"
            "不构成安全结论、预算报价或收益承诺；正式实施前须由业务、技术、"
            "数据、安全和财务负责人复核。\n\n"
            "This package was generated by PCIO Toolkit. Case data and improvement "
            "ranges are references only, not safety conclusions, price quotes, or "
            "benefit guarantees. Business, technical, data, safety, and finance "
            "owners must review the outputs before implementation.",
        )
        archive.writestr(
            "pcio_analysis_results.json",
            json.dumps(analysis, ensure_ascii=False, indent=2),
        )
        archive.writestr("pcio_spss_style_tables.xlsx", analysis_excel)
        archive.writestr("PCIO-Implementation-Case-Report-bilingual.md", report_markdown)
        archive.writestr(
            "pcio_decision_support.json",
            json.dumps(decision, ensure_ascii=False, indent=2),
        )
        archive.writestr(
            "PCIO-Risk-KPI-ROI-Summary-bilingual.md",
            decision_support_markdown(decision),
        )
        archive.writestr(
            "pcio_risk_kpi_roi.xlsx",
            decision_support_excel_bytes(decision),
        )
        archive.writestr(
            "manifest.json",
            json.dumps(
                {
                    "project_code": profile.get("project_code"),
                    "package_version": "1.0.0",
                    "files": [
                        "company_profile.json",
                        "README-bilingual.txt",
                        "pcio_analysis_results.json",
                        "pcio_spss_style_tables.xlsx",
                        "PCIO-Implementation-Case-Report-bilingual.md",
                        "pcio_decision_support.json",
                        "PCIO-Risk-KPI-ROI-Summary-bilingual.md",
                        "pcio_risk_kpi_roi.xlsx",
                    ],
                },
                ensure_ascii=False,
                indent=2,
            ),
        )
    return buffer.getvalue()


def write_decision_support_package(
    decision: dict[str, Any],
    output_dir: str | Path,
) -> dict[str, Path]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    json_path = output / "pcio_decision_support.json"
    markdown_path = output / "PCIO-Risk-KPI-ROI-Summary-bilingual.md"
    excel_path = output / "pcio_risk_kpi_roi.xlsx"
    json_path.write_text(
        json.dumps(decision, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    markdown_path.write_text(decision_support_markdown(decision), encoding="utf-8")
    excel_path.write_bytes(decision_support_excel_bytes(decision))
    return {"json": json_path, "markdown": markdown_path, "excel": excel_path}


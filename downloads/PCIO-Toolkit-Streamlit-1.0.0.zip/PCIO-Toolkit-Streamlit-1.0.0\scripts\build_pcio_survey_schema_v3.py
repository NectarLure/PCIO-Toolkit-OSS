﻿"""Build the extended bilingual PCIO production-technician instrument.

The builder is intentionally deterministic. It validates the planned module
counts before replacing the shared JSON schema used by Excel, HTML, Streamlit,
CSV exports, and the statistical engine.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "templates" / "pcio_survey_schema.json"


def option(code: str, zh: str, en: str) -> dict[str, str]:
    return {"code": code, "zh": zh, "en": en}


OPTIONS = {
    "company_size": [
        option("micro", "微型（少于20人）", "Micro (fewer than 20 employees)"),
        option("small", "小型（20-99人）", "Small (20-99 employees)"),
        option("medium", "中型（100-499人）", "Medium (100-499 employees)"),
        option("large", "大型（500人及以上）", "Large (500+ employees)"),
    ],
    "industry": [
        option("chemical", "化工", "Chemical"),
        option("new_materials", "新材料", "New materials"),
        option("machinery", "机械加工/装备", "Machinery / equipment"),
        option("automotive", "汽车及零部件", "Automotive and components"),
        option("electronics", "电子/电气", "Electronics / electrical"),
        option("food", "食品饮料", "Food and beverage"),
        option("pharma", "制药/生命科学", "Pharmaceutical / life sciences"),
        option("textile", "纺织/轻工", "Textile / light industry"),
        option("tank_logistics", "罐区/仓储/装卸", "Tank farm / storage / loading"),
        option("other", "其他制造业", "Other manufacturing"),
    ],
    "production_type": [
        option("continuous_process", "连续流程生产", "Continuous process"),
        option("batch_process", "批次/间歇生产", "Batch / semi-batch process"),
        option("discrete_line", "离散装配线", "Discrete assembly line"),
        option("job_shop", "机加工/多品种小批量", "Job shop / high-mix low-volume"),
        option("tank_loading", "罐区储运与装卸", "Tank storage and loading"),
        option("mixed", "混合型生产", "Mixed production"),
    ],
    "pain_points": [
        option("equipment_downtime", "设备故障或非计划停机", "Equipment failure or unplanned downtime"),
        option("process_variation", "工艺参数波动", "Process parameter variation"),
        option("quality_defects", "质量缺陷、返工或批次波动", "Defects, rework, or batch variation"),
        option("energy_cost", "能源消耗高或缺少分项计量", "High energy use or insufficient sub-metering"),
        option("manual_records", "人工抄表、纸质记录或重复录入", "Manual readings, paper records, or duplicate entry"),
        option("data_silos", "设备/部门数据不互通", "Data silos across assets or departments"),
        option("slow_exception", "异常发现或处理慢", "Slow exception detection or response"),
        option("collaboration", "跨班组/部门协作不顺", "Weak cross-shift or cross-department collaboration"),
        option("traceability", "产品、批次或工单追溯困难", "Weak product, batch, or work-order traceability"),
        option("safety", "报警、联锁或现场安全风险", "Alarm, interlock, or shop-floor safety risk"),
        option("schedule_changeover", "排产、换线或装卸等待时间长", "Scheduling, changeover, or loading delays"),
    ],
    "current_systems": [
        option("paper", "纸质记录", "Paper records"),
        option("excel", "Excel/电子表格", "Excel / spreadsheets"),
        option("plc", "PLC", "PLC"),
        option("dcs", "DCS", "DCS"),
        option("scada_hmi", "SCADA/HMI", "SCADA / HMI"),
        option("mes", "MES/电子工单", "MES / electronic work orders"),
        option("erp", "ERP", "ERP"),
        option("cmms", "CMMS/EAM维修系统", "CMMS / EAM"),
        option("qms_lims", "QMS/LIMS质量系统", "QMS / LIMS"),
        option("iot_platform", "工业物联网/数据平台", "IIoT / data platform"),
        option("aps", "APS/高级排程", "APS / advanced planning and scheduling"),
        option("none", "暂无数字化系统", "No digital system"),
    ],
    "automation_level": [
        option("manual", "以人工记录和人工控制为主", "Mainly manual recording and control"),
        option("local", "单机/局部自动化", "Standalone or local automation"),
        option("connected", "主要设备已联网采集", "Most critical assets are connected"),
        option("integrated", "生产系统已有较完整集成", "Production systems are substantially integrated"),
        option("optimised", "已使用高级分析或闭环优化", "Advanced analytics or closed-loop optimisation is in use"),
    ],
    "role": [
        option("operator", "生产操作人员", "Production operator"),
        option("technician", "设备/维修技术人员", "Maintenance technician"),
        option("process", "工艺技术人员", "Process technician"),
        option("quality", "质量/检验技术人员", "Quality / inspection technician"),
        option("team_lead", "班组长/现场主管", "Team leader / floor supervisor"),
        option("automation", "自动化/IT/数据人员", "Automation / IT / data"),
        option("energy_safety", "能源/安全/环保人员", "Energy / safety / environmental staff"),
        option("other", "其他生产相关岗位", "Other production role"),
    ],
    "shift": [
        option("day", "白班", "Day shift"),
        option("night", "夜班", "Night shift"),
        option("rotating", "轮班", "Rotating shift"),
        option("regular", "常白班/不轮班", "Regular hours / no shift"),
        option("other", "其他", "Other"),
    ],
    "education_level": [
        option("secondary_or_below", "高中/中专及以下", "Upper secondary / vocational or below"),
        option("college", "大专", "Associate degree / college diploma"),
        option("bachelor", "本科", "Bachelor's degree"),
        option("postgraduate", "研究生及以上", "Postgraduate"),
        option("prefer_not", "不愿回答", "Prefer not to answer"),
    ],
    "digital_tool_frequency": [
        option("never", "几乎不用", "Almost never"),
        option("monthly", "每月少量使用", "A few times per month"),
        option("weekly", "每周使用", "Weekly"),
        option("daily", "每天使用", "Daily"),
        option("continuous", "贯穿班次持续使用", "Used throughout the shift"),
    ],
    "decision_involvement": [
        option("execute", "主要执行既定操作", "Mainly execute defined work"),
        option("suggest", "能提出建议但不审批", "Can suggest but not approve"),
        option("approve_local", "可批准班组/局部调整", "Can approve team or local adjustments"),
        option("design", "参与方案设计与验收", "Participate in solution design and acceptance"),
    ],
    "yes_no": [
        option("yes", "是", "Yes"),
        option("no", "否", "No"),
        option("unsure", "不确定", "Unsure"),
    ],
    "barrier_options": [
        option("budget", "预算与现金流约束", "Budget and cash-flow constraints"),
        option("sensor_gap", "关键测点或传感器不足", "Insufficient critical tags or sensors"),
        option("legacy_assets", "老旧设备接口困难", "Legacy equipment interface constraints"),
        option("network", "现场网络覆盖或稳定性不足", "Insufficient network coverage or stability"),
        option("data_quality", "数据质量、校准或缺失问题", "Data quality, calibration, or missing-data issues"),
        option("data_silos", "系统与部门数据孤岛", "System and departmental data silos"),
        option("cybersecurity", "网络安全或合规限制", "Cybersecurity or compliance constraints"),
        option("skills", "缺少数字化技能和培训时间", "Insufficient digital skills or training time"),
        option("workload", "一线人员工作负担过重", "Excessive frontline workload"),
        option("resistance", "对变革缺乏信任或存在抵触", "Low trust in or resistance to change"),
        option("ownership", "责任人、流程和数据归属不清", "Unclear ownership, workflow, or data accountability"),
        option("supplier", "供应商响应、备件或本地服务不足", "Insufficient supplier response, spares, or local service"),
        option("benefits", "收益难量化或缺少基线", "Benefits are hard to quantify or baselines are missing"),
        option("other", "其他", "Other"),
    ],
    "workflow_options": [
        option("monitoring", "设备/工艺监控", "Asset / process monitoring"),
        option("maintenance", "点检与维修", "Inspection and maintenance"),
        option("quality", "质量检验与追溯", "Quality inspection and traceability"),
        option("energy", "能源管理", "Energy management"),
        option("planning", "排产、换线或装卸", "Scheduling, changeover, or loading"),
        option("handover", "交接班与异常闭环", "Shift handover and exception closure"),
        option("reporting", "报表与绩效复盘", "Reporting and performance review"),
        option("safety", "安全、环保与合规", "Safety, environment, and compliance"),
    ],
    "support_options": [
        option("training", "岗位化培训与现场辅导", "Role-based training and floor coaching"),
        option("time", "预留改善与学习时间", "Protected improvement and learning time"),
        option("expert", "工艺/自动化/数据专家支持", "Process, automation, or data expert support"),
        option("vendor", "设备与软件供应商支持", "Equipment and software vendor support"),
        option("management", "管理层资源与跨部门协调", "Management resources and cross-functional coordination"),
        option("standards", "数据标准、SOP与责任矩阵", "Data standards, SOPs, and responsibility matrix"),
        option("incentive", "认可与激励机制", "Recognition and incentives"),
        option("infrastructure", "传感器、网络与终端投入", "Sensor, network, and terminal investment"),
    ],
    "pcio_priority_options": [
        option("P_sensor", "P：关键传感与测点补齐", "P: close critical sensing gaps"),
        option("P_quality", "P：校准与数据质量治理", "P: calibration and data-quality governance"),
        option("C_network", "C：网络与采集链路稳定", "C: stabilise network and collection"),
        option("C_edge", "C：边缘缓存与协议转换", "C: edge buffering and protocol conversion"),
        option("I_mapping", "I：设备/工单/批次映射", "I: asset, work-order, and batch mapping"),
        option("I_visual", "I：统一看板与异常工作流", "I: shared dashboards and exception workflows"),
        option("O_control", "O：工艺控制与报警优化", "O: process-control and alarm optimisation"),
        option("O_maintenance", "O：状态/预测性维护", "O: condition-based / predictive maintenance"),
        option("O_ai", "O：分析与AI辅助决策", "O: analytics and AI-assisted decisions"),
        option("H_capability", "组织：培训、治理与人机协同", "Organisation: capability, governance, and human-machine collaboration"),
    ],
    "kpi_priority_options": [
        option("availability", "设备可用率/非计划停机", "Availability / unplanned downtime"),
        option("quality", "一次合格率/缺陷率", "First-pass yield / defect rate"),
        option("energy", "单位产品能源消耗", "Energy consumption per unit"),
        option("throughput", "产量/节拍/周期时间", "Throughput / cycle time"),
        option("flexibility", "换线/换型/装卸时间", "Changeover / loading time"),
        option("response", "异常发现与关闭时间", "Exception detection and closure time"),
        option("data_quality", "关键数据完整率与准确率", "Critical-data completeness and accuracy"),
        option("adoption", "数字工具使用率与任务通过率", "Digital-tool adoption and task competence"),
    ],
    "success_options": [
        option("pilot_scope", "试点范围小而清晰", "A small and clear pilot scope"),
        option("baseline", "改善前基线可信", "A credible pre-improvement baseline"),
        option("owner", "业务、技术和数据责任人明确", "Clear business, technical, and data owners"),
        option("frontline", "一线人员参与设计与验收", "Frontline participation in design and acceptance"),
        option("reuse", "优先复用现有设备与系统", "Reuse existing assets and systems first"),
        option("training", "岗位培训与现场支持到位", "Role-based training and floor support"),
        option("security", "安全、网络与回退方案明确", "Clear safety, cybersecurity, and rollback plans"),
        option("pdca", "按PDCA持续复盘并标准化", "Continuous PDCA review and standardisation"),
    ],
}


PROFILE_FIELDS = [
    {"id": "project_code", "type": "text", "required": True, "zh": "项目代码（用于多人进入同一项目）", "en": "Project code (shared by participants)", "help_zh": "使用不含公司全称的3-40位短代码。", "help_en": "Use a 3-40 character code that does not reveal the full legal name."},
    {"id": "company_name", "type": "text", "required": True, "zh": "公司名称或匿名名称", "en": "Company or anonymised name"},
    {"id": "company_size", "type": "select", "options": "company_size", "required": True, "zh": "公司规模", "en": "Company size"},
    {"id": "employee_count", "type": "integer", "required": False, "min": 1, "max": 1000000, "zh": "员工人数（可选）", "en": "Employee count (optional)"},
    {"id": "industry", "type": "select", "options": "industry", "required": True, "zh": "主要行业", "en": "Primary industry"},
    {"id": "production_type", "type": "select", "options": "production_type", "required": True, "zh": "主要生产/产线类型", "en": "Primary production or line type"},
    {"id": "line_name", "type": "text", "required": True, "zh": "本次诊断的产线/工序/区域", "en": "Line, process, or area in scope"},
    {"id": "region", "type": "text", "required": False, "zh": "所在地区（省/市或国家/地区）", "en": "Region (province/city or country/region)"},
    {"id": "pain_points", "type": "multiselect", "options": "pain_points", "required": True, "min_items": 1, "max_items": 5, "zh": "当前核心痛点（最多5项）", "en": "Current core pain points (up to 5)"},
    {"id": "current_systems", "type": "multiselect", "options": "current_systems", "required": True, "min_items": 1, "zh": "当前使用的记录或数字化系统", "en": "Current recording or digital systems"},
    {"id": "automation_level", "type": "select", "options": "automation_level", "required": True, "zh": "当前自动化/数字化总体水平", "en": "Current overall automation / digitalisation level"},
    {"id": "pilot_scope", "type": "textarea", "required": False, "zh": "拟试点范围与希望改善的指标", "en": "Proposed pilot scope and desired KPI improvement"},
    {"id": "profile_owner", "type": "text", "required": False, "zh": "项目负责人岗位（不要填写私人联系方式）", "en": "Project owner role (do not enter private contact details)"},
]


RESPONDENT_FIELDS = [
    {"id": "respondent_code", "type": "text", "required": False, "zh": "匿名人员代码（可留空自动生成）", "en": "Anonymous respondent code (auto-generated if blank)"},
    {"id": "role", "type": "select", "options": "role", "required": True, "zh": "岗位", "en": "Role"},
    {"id": "department", "type": "text", "required": True, "zh": "部门/工序", "en": "Department / process"},
    {"id": "shift", "type": "select", "options": "shift", "required": True, "zh": "班次", "en": "Shift"},
    {"id": "years_experience", "type": "integer", "required": True, "min": 0, "max": 60, "zh": "相关工作年限", "en": "Years of relevant experience"},
    {"id": "tenure_current_position", "type": "integer", "required": True, "min": 0, "max": 60, "zh": "当前岗位年限", "en": "Years in current position"},
    {"id": "education_level", "type": "select", "options": "education_level", "required": True, "zh": "最高学历", "en": "Highest education level"},
    {"id": "digital_exposure_years", "type": "integer", "required": True, "min": 0, "max": 40, "zh": "接触数字化生产工具的年限", "en": "Years using digital production tools"},
    {"id": "digital_tool_frequency", "type": "select", "options": "digital_tool_frequency", "required": True, "zh": "数字化工具使用频率", "en": "Frequency of digital-tool use"},
    {"id": "participated_digital_project", "type": "select", "options": "yes_no", "required": True, "zh": "是否参与过数字化/自动化改造", "en": "Participated in a digital or automation project"},
    {"id": "training_hours_12m", "type": "integer", "required": True, "min": 0, "max": 500, "zh": "过去12个月相关培训时数", "en": "Relevant training hours in the past 12 months"},
    {"id": "decision_involvement", "type": "select", "options": "decision_involvement", "required": True, "zh": "在现场改善决策中的参与程度", "en": "Involvement in shop-floor improvement decisions"},
]


# topic, evidence, failure, scenario
DIMENSIONS: dict[str, list[tuple[str, str, str, str, str, str, str, str, str, str]]] = {
    "P": [
        ("equipment_state", "设备运行状态感知", "equipment-state sensing", "运行、待机、停机、故障及原因代码", "run, idle, stop, fault, and reason-code data", "状态跳变、误报或未记录停机", "state changes, false indications, or unrecorded stops", "关键设备突然停机或频繁短停", "a critical asset stops unexpectedly or repeatedly micro-stops", "EQS"),
        ("process_parameters", "关键工艺参数采集", "critical process-parameter capture", "温度、压力、流量、液位、配比、速度或节拍", "temperature, pressure, flow, level, ratio, speed, or cycle data", "参数漂移、超限或波动", "parameter drift, limit violation, or oscillation", "产品指标波动并怀疑工艺参数偏移", "product performance varies and process drift is suspected", "PRM"),
        ("sensor_coverage", "传感器与测点覆盖", "sensor and tag coverage", "关键设备、工序、能源与质量测点清单", "critical asset, process, utility, and quality tag inventory", "关键变量没有测点或只能人工估计", "a critical variable has no tag and must be estimated manually", "试点前需要判断哪些测点必须先补齐", "the pilot team must decide which missing tags to add first", "SEN"),
        ("calibration", "校准与计量溯源", "calibration and metrological traceability", "量程、单位、校准日期、偏差与证书", "range, unit, calibration date, bias, and certificate data", "仪表超期、量程不匹配或零点漂移", "an instrument is overdue, incorrectly ranged, or drifting at zero", "两个仪表对同一工况给出明显不同读数", "two instruments show materially different readings for the same condition", "CAL"),
        ("data_accuracy", "现场数据准确性", "shop-floor data accuracy", "传感器值、人工复核值与产品结果", "sensor values, manual checks, and product outcomes", "异常值、卡死值或与工况不一致", "outliers, frozen values, or readings inconsistent with conditions", "系统显示正常但现场明显异常", "the system appears normal while the physical process is visibly abnormal", "ACC"),
        ("data_completeness", "数据完整性与连续性", "data completeness and continuity", "缺失率、断点、补录记录与停采时段", "missingness, gaps, backfilled records, and collection outages", "班次、批次或关键阶段数据缺失", "shift, batch, or critical-stage data are missing", "复盘事故时发现关键时间段没有数据", "a review finds no data for the critical incident window", "CMP"),
        ("sampling_sync", "采样频率与时间同步", "sampling frequency and time synchronisation", "采样周期、时间戳、设备时钟与事件顺序", "sampling intervals, timestamps, device clocks, and event sequence", "采样过慢、时间错位或事件顺序不清", "sampling is too slow, clocks are misaligned, or event order is unclear", "需要比较报警前后数秒内多个设备的变化", "multiple assets must be compared within seconds around an alarm", "TIM"),
        ("energy_environment", "能源、环境与安全感知", "utility, environmental, and safety sensing", "电、蒸汽、水、气、排放、温湿度与安全测点", "electricity, steam, water, gas, emissions, ambient, and safety tags", "分项计量不足、泄漏或安全测点失真", "sub-metering is absent, leakage occurs, or a safety tag is unreliable", "单位能耗突然升高或现场出现泄漏迹象", "unit energy use rises suddenly or leakage is suspected", "ENE"),
        ("quality_capture", "质量与缺陷数据采集", "quality and defect-data capture", "检验结果、缺陷类型、位置、批次与返工记录", "inspection results, defect type, location, batch, and rework records", "缺陷描述不统一、记录滞后或样本不足", "defect descriptions are inconsistent, delayed, or undersampled", "同类缺陷在不同班组使用不同名称记录", "different shifts record the same defect under different names", "QLT"),
        ("source_access", "源头数据可获得性", "source-data availability", "现场终端、趋势、历史记录与原始数据导出", "shop-floor terminals, trends, histories, and raw-data export", "数据只能由少数人查询或需要反复申请", "only a few people can retrieve data or repeated requests are required", "夜班需要立即查看历史趋势但支持人员不在场", "night shift urgently needs historical trends while support staff are absent", "ACS"),
    ],
    "C": [
        ("network_coverage", "工业网络覆盖", "industrial network coverage", "有线、工业无线与移动终端覆盖记录", "wired, industrial wireless, and mobile-terminal coverage records", "盲区、弱信号或移动作业中断", "dead zones, weak signals, or mobile-work interruption", "人员移动到边远工位后无法稳定查看数据", "data becomes unavailable at a remote workstation", "NET"),
        ("transmission_reliability", "数据传输可靠性", "data-transmission reliability", "链路可用率、断线日志与重连记录", "link availability, disconnection logs, and reconnection records", "频繁断线、重连失败或数据重复", "frequent disconnections, failed reconnects, or duplicate data", "采集链路间歇中断但设备仍在生产", "collection intermittently fails while the asset keeps running", "REL"),
        ("latency", "数据时延与实时性", "data latency and timeliness", "端到端延迟、刷新周期与报警到达时间", "end-to-end latency, refresh interval, and alarm arrival time", "显示滞后导致判断落后于现场", "display lag causes decisions to trail actual conditions", "快速工艺变化发生后看板数分钟才更新", "a dashboard updates minutes after a rapid process change", "LAT"),
        ("packet_loss", "数据丢失与重传", "data loss and retransmission", "丢包率、补传状态与序列完整性", "packet loss, backfill status, and sequence completeness", "短时数据段永久丢失或顺序错乱", "short data segments are permanently lost or reordered", "网络恢复后需要确认停线期间数据是否补齐", "the team must verify whether outage data were backfilled", "LOS"),
        ("protocol_gateway", "协议兼容与网关", "protocol compatibility and gateways", "PLC/DCS/仪表协议、点表与网关映射", "PLC/DCS/instrument protocols, tag lists, and gateway mappings", "协议不兼容、点位映射错误或厂商锁定", "protocol incompatibility, mapping errors, or vendor lock-in", "新增旧设备需要以低成本接入现有平台", "a legacy asset must connect to the platform at low cost", "PRT"),
        ("edge_computing", "边缘采集与计算", "edge collection and computing", "边缘缓存、清洗、规则与本地计算日志", "edge buffering, cleansing, rules, and local-compute logs", "云端/中心不可用时现场功能全部中断", "all local functions stop when cloud or central services fail", "中心网络中断但关键报警仍需在本地运行", "central connectivity fails while critical local alarms must continue", "EDG"),
        ("access_control", "岗位访问与权限", "role-based access and permissions", "账号、角色、最小权限与访问审计", "accounts, roles, least privilege, and access audits", "该看的人看不到、不该看的人权限过大", "authorised users lack access while others have excessive rights", "临时承包商需要有限时、可审计的访问", "a contractor needs time-limited and auditable access", "IAM"),
        ("offline_buffer", "离线缓存与恢复", "offline buffering and recovery", "本地缓存容量、断点续传与恢复验证", "local buffer capacity, resume transfer, and recovery verification", "断网期间数据无法保存或恢复后形成重复", "outage data are not retained or are duplicated after recovery", "计划停网后要验证生产数据完整恢复", "production data must recover completely after planned network work", "BUF"),
        ("time_sync", "网络时间同步", "network time synchronisation", "NTP/PTP状态、时钟偏差与同步告警", "NTP/PTP status, clock offset, and synchronisation alarms", "不同系统时间相差过大", "system clocks differ materially", "需要按秒还原报警、操作与设备动作先后顺序", "alarm, operator action, and equipment response must be reconstructed by second", "CLK"),
        ("cybersecurity", "连接层网络安全", "connectivity-layer cybersecurity", "分区分域、白名单、补丁、备份与异常流量记录", "segmentation, allowlists, patches, backups, and anomalous-traffic records", "远程接入失控、弱口令或网络边界不清", "uncontrolled remote access, weak credentials, or unclear boundaries", "供应商远程维护时需保障生产连续与访问可追溯", "vendor remote maintenance must be traceable without disrupting production", "SEC"),
    ],
    "I": [
        ("interoperability", "系统接口与互操作", "system interfaces and interoperability", "PLC/DCS、SCADA、MES、ERP、QMS和CMMS接口记录", "PLC/DCS, SCADA, MES, ERP, QMS, and CMMS interface records", "接口中断、重复录入或字段含义不一致", "interface failure, duplicate entry, or inconsistent field meaning", "一个系统升级后上下游数据交换异常", "an upstream or downstream exchange fails after a system upgrade", "INT"),
        ("master_data", "主数据与编码标准", "master data and coding standards", "设备、产品、物料、工单、批次与缺陷代码", "asset, product, material, work-order, batch, and defect codes", "同一对象多套名称或编码重复", "one object has multiple names or duplicate codes", "跨部门合并数据时发现同一设备名称不同", "cross-functional data cannot merge because an asset has different names", "MDM"),
        ("traceability", "批次/工单/产品追溯", "batch, work-order, and product traceability", "人员、设备、物料、参数、检验与结果链路", "links among people, assets, materials, parameters, inspections, and results", "异常无法追到具体时间、批次或设备", "an exception cannot be traced to a specific time, batch, or asset", "客户投诉后需要在限定时间内完成正反向追溯", "forward and backward traceability must be completed within a deadline", "TRC"),
        ("data_sharing", "数据共享与可用性", "data sharing and usability", "共享数据集、授权目录、刷新频率与责任人", "shared datasets, authorised catalogues, refresh frequency, and owners", "部门各自维护副本且更新不同步", "departments maintain unsynchronised copies", "生产与质量会议使用的数字不一致", "production and quality meetings use different figures", "SHR"),
        ("visualisation", "看板与可视化", "dashboards and visualisation", "岗位看板、趋势、分层指标与异常钻取", "role-based dashboards, trends, tiered KPIs, and exception drill-down", "看板信息过多、口径不明或无法定位原因", "dashboards overload users, obscure definitions, or prevent root-cause drill-down", "班组长需在五分钟内判断当班首要损失", "a team leader must identify the shift's largest loss within five minutes", "VIS"),
        ("hmi_scada", "HMI/SCADA使用体验", "HMI/SCADA usability", "画面层级、报警、操作步骤与响应时间", "screen hierarchy, alarms, operating steps, and response time", "画面难找、操作易错或报警泛滥", "screens are hard to find, actions are error-prone, or alarms flood users", "新员工在异常时需要快速找到正确画面和SOP", "a new worker must quickly find the correct screen and SOP during an exception", "HMI"),
        ("exception_workflow", "异常闭环工作流", "exception-closure workflow", "发现、分级、指派、措施、验证与关闭记录", "detection, classification, assignment, action, verification, and closure records", "异常无人接单、重复发生或关闭无证据", "exceptions lack owners, recur, or close without evidence", "同类停机在一周内重复发生，需要确认措施是否有效", "the same stop recurs within a week and action effectiveness must be checked", "EXC"),
        ("handover", "交接班与知识传递", "shift handover and knowledge transfer", "未结异常、临时措施、风险与后续责任人", "open exceptions, temporary controls, risks, and next owners", "口头交接遗漏关键风险或历史信息", "verbal handover omits critical risks or history", "夜班遗留问题需由白班继续处理", "an unresolved night-shift issue must transfer to day shift", "HDO"),
        ("cross_department", "跨部门协同", "cross-functional collaboration", "生产、设备、工艺、质量、能源与IT协同记录", "production, maintenance, process, quality, energy, and IT collaboration records", "信息来回确认、责任边界模糊或响应慢", "repeated confirmation, unclear accountability, or slow response", "质量异常同时涉及设备、工艺和原料", "a quality exception simultaneously involves equipment, process, and material", "COL"),
        ("data_silo", "数据孤岛与统一语义", "data silos and common semantics", "数据目录、血缘、接口、指标定义与版本", "data catalogue, lineage, interfaces, KPI definitions, and versions", "局部系统无法合并、来源不明或版本冲突", "local systems cannot merge, sources are unclear, or versions conflict", "管理层要求汇总多个系统的同一KPI", "management requests one KPI consolidated from several systems", "SIL"),
    ],
    "O": [
        ("advanced_control", "先进控制与参数优化", "advanced control and parameter optimisation", "控制回路绩效、设定值、约束与调整记录", "control-loop performance, setpoints, constraints, and adjustment records", "超调、振荡、频繁手动干预或参数漂移", "overshoot, oscillation, frequent manual intervention, or parameter drift", "关键温度波动扩大并影响质量稳定性", "critical temperature variation increases and affects quality stability", "APC"),
        ("predictive_maintenance", "状态与预测性维护", "condition-based and predictive maintenance", "健康指标、故障模式、预警、工单与维修结果", "health indicators, failure modes, alerts, work orders, and maintenance outcomes", "误报过多、预警无行动或故障后才维修", "excessive false alerts, alerts without action, or repair only after failure", "振动趋势持续上升但设备尚未故障", "vibration rises steadily before functional failure", "PDM"),
        ("quality_analytics", "质量分析与过程能力", "quality analytics and process capability", "SPC、Pareto、能力指数、缺陷关联与验证记录", "SPC, Pareto, capability indices, defect associations, and validation records", "只看最终检验、不能定位过程原因", "only final inspection is reviewed and process causes remain unknown", "缺陷率上升但不同参数可能共同影响结果", "defect rate rises while several parameters may jointly affect the outcome", "QAN"),
        ("energy_optimisation", "能源优化", "energy optimisation", "单位能耗、峰谷、基线、泄漏与节能验证", "unit energy, peaks, baselines, leakage, and savings verification", "只看总表、缺少分项基线或节能后未验证", "only total meters are used, sub-baselines are missing, or savings are unverified", "蒸汽消耗上升但产量和产品结构也发生变化", "steam use rises while output and product mix also change", "EOP"),
        ("scheduling", "排产、换线与物流优化", "scheduling, changeover, and logistics optimisation", "订单、能力、切换时间、等待、在制品与装卸记录", "orders, capacity, changeover time, waiting, WIP, and loading records", "频繁插单、等待或局部最优造成整体延误", "rush jobs, waiting, or local optimisation cause system-wide delay", "订单优先级突变且多个工序能力受限", "order priority changes abruptly while several processes are capacity constrained", "SCH"),
        ("ai_decision", "分析与AI辅助决策", "analytics and AI-assisted decisions", "模型输入、版本、置信度、解释、人工确认与反馈", "model inputs, versions, confidence, explanations, human confirmation, and feedback", "建议不可解释、数据漂移或人员盲目接受", "recommendations are opaque, data drift occurs, or users accept them blindly", "模型建议调整参数但与资深人员经验冲突", "a model recommends a parameter change that conflicts with expert judgement", "AID"),
        ("closed_loop_pdca", "PDCA闭环改善", "closed-loop PDCA improvement", "问题、基线、措施、检查、标准化与复盘记录", "problem, baseline, action, check, standardisation, and review records", "措施实施后不复测、无负责人或未标准化", "actions are not remeasured, lack owners, or are not standardised", "试点指标短期改善，但一个月后效果回落", "a pilot improves briefly but performance declines after one month", "PDC"),
        ("alarm_management", "报警与异常优先级优化", "alarm and exception prioritisation", "报警频率、持续时间、洪泛、搁置与响应效果", "alarm frequency, duration, floods, shelving, and response effectiveness", "报警过多、优先级失真或关键报警被淹没", "alarm overload, distorted priorities, or critical alarms being buried", "同一时间出现大量报警且人员必须先处理最关键项", "many alarms occur simultaneously and staff must identify the critical first action", "ALM"),
        ("simulation", "仿真、数字模型与试验设计", "simulation, digital models, and designed experiments", "模型假设、参数、试验方案、预测误差与验证记录", "model assumptions, parameters, experiment plans, prediction error, and validation", "未经验证即按模型结果改现场", "shop-floor changes are made from an unvalidated model", "高风险参数调整需要先评估对质量和安全的影响", "a high-risk parameter change must be assessed for quality and safety effects first", "SIM"),
        ("benefit_tracking", "效益跟踪与规模化复制", "benefit tracking and scale-up", "成本、收益、KPI基线、归因、维护成本与复制条件", "cost, benefit, KPI baseline, attribution, upkeep cost, and replication criteria", "收益口径不清、只报好结果或忽略持续成本", "benefit definitions are unclear, only positive results are reported, or recurring cost is ignored", "试点准备推广到第二条产线，需要判断效果是否可复制", "a pilot is considered for a second line and replicability must be assessed", "BEN"),
    ],
    "H": [
        ("training", "岗位培训与持续学习", "role-based training and continuous learning", "岗位能力矩阵、培训、练习、考核与现场辅导", "role competence matrix, training, practice, assessment, and floor coaching", "培训只讲功能、不结合岗位任务或无练习", "training covers features but not job tasks or practice", "新工具上线后夜班人员遇到问题但现场无人支持", "night-shift staff face problems after go-live without on-site support", "TRN"),
        ("skills", "数字化与数据技能", "digital and data skills", "读图、识别异常、数据记录、基础分析与问题解决能力", "trend reading, anomaly recognition, data recording, basic analysis, and problem-solving skills", "只会录入但不会解释或行动", "staff can enter data but cannot interpret or act on it", "人员需要根据趋势和现场现象判断数据是否可信", "staff must judge data credibility from trends and physical conditions", "SKL"),
        ("management_support", "管理支持与资源保障", "management support and resources", "负责人、预算、时间、跨部门协调与障碍清单", "owners, budget, time, cross-functional coordination, and barrier log", "项目口头支持但没有时间、人员或决策权限", "projects receive verbal support but no time, staff, or decision authority", "试点遇到跨部门资源冲突，需要快速升级决策", "a pilot encounters a cross-functional resource conflict requiring rapid escalation", "MGT"),
        ("incentives", "认可、激励与绩效一致性", "recognition, incentives, and performance alignment", "改善建议、采用行为、团队贡献与公平反馈记录", "improvement ideas, adoption behaviours, team contribution, and fair feedback records", "只考核产量导致人员回避学习和规范记录", "output-only targets discourage learning and disciplined recording", "短期产量压力与完成培训、校准或数据治理发生冲突", "short-term output pressure conflicts with training, calibration, or data-governance work", "INC"),
        ("change_resistance", "变革参与与阻力管理", "change participation and resistance management", "一线反馈、试用、问题清单、沟通与调整记录", "frontline feedback, trials, issue logs, communication, and adjustment records", "工具由上而下推行、问题无人回应或增加负担", "tools are imposed top-down, issues go unanswered, or workload increases", "员工认为新系统只用于监控个人而不愿真实记录", "staff believe a new system is for personal surveillance and avoid honest recording", "CHG"),
        ("human_machine_trust", "人机协同、信任与责任边界", "human-machine collaboration, trust, and accountability", "建议依据、置信度、人工确认、回退、越权与责任记录", "recommendation evidence, confidence, human confirmation, rollback, override, and accountability records", "人员盲从系统或完全忽视系统建议", "staff either over-rely on or completely ignore system advice", "系统建议与安全操作规程冲突，需要明确谁有权停止或回退", "a system recommendation conflicts with a safety procedure and stop/rollback authority must be clear", "HMT"),
    ],
}


SECTION_LABELS = {
    "P": {"zh": "感知层（Perception）", "en": "Perception"},
    "C": {"zh": "连接层（Connectivity）", "en": "Connectivity"},
    "I": {"zh": "集成层（Integration）", "en": "Integration"},
    "O": {"zh": "优化层（Optimisation）", "en": "Optimisation"},
    "H": {"zh": "组织与人力支持", "en": "Organisational and workforce support"},
    "B": {"zh": "障碍、优先级与开放题", "en": "Barriers, priorities, and open questions"},
}


def stems(layer: str, values: tuple[str, ...]) -> list[tuple[str, str, bool, bool]]:
    _, topic_zh, topic_en, evidence_zh, evidence_en, failure_zh, failure_en, scenario_zh, scenario_en, _ = values
    common = {
        "P": [
            (f"在最近6个月，本区域对{topic_zh}的关键对象和测点有清晰清单。", f"During the past six months, this area has maintained a clear inventory of critical objects and tags for {topic_en}.", False, False),
            (f"{evidence_zh}能够按规定频率形成连续记录，并可按班次、批次或工单调取。", f"{evidence_en.capitalize()} are recorded at the required frequency and can be retrieved by shift, batch, or work order.", False, False),
            (f"一线人员能够用{evidence_zh}判断真实工况，而不只依赖口头经验。", f"Frontline staff can use {evidence_en} to judge actual conditions rather than relying only on verbal experience.", False, False),
            (f"出现{failure_zh}时，现场能够区分测量问题与真实工况异常。", f"When {failure_en} occurs, the team can distinguish a measurement problem from a real operating exception.", False, False),
            (f"围绕{topic_zh}的记录经常缺失、滞后或需要事后补填。", f"Records for {topic_en} are often missing, delayed, or backfilled after the event.", True, False),
            (f"情景：{scenario_zh}时，我能在规定时间内找到足够数据并采取正确的第一步。", f"Scenario: when {scenario_en}, I can find sufficient data within the required time and take the correct first action.", False, True),
            (f"围绕{topic_zh}的数据可与另一独立来源交叉核对，并留下偏差处理记录。", f"Data for {topic_en} can be cross-checked against an independent source, with discrepancies documented and resolved.", False, False),
        ],
        "C": [
            (f"支撑{topic_zh}的链路在正常生产和高负荷时均保持可用。", f"Connections supporting {topic_en} remain available during normal production and peak load.", False, False),
            (f"团队能查看{evidence_zh}，并知道链路健康状态和责任人。", f"The team can review {evidence_en} and knows the connection health status and owner.", False, False),
            (f"出现{failure_zh}时，有明确的告警、临时措施、升级路径和恢复验证。", f"When {failure_en} occurs, alerts, temporary controls, escalation, and recovery verification are defined.", False, False),
            (f"{topic_zh}出现问题后，通常要等用户投诉或生产受影响才被发现。", f"Problems with {topic_en} are usually detected only after user complaints or production impact.", True, False),
            (f"情景：{scenario_zh}时，关键数据仍能安全传输、缓存或在恢复后补齐。", f"Scenario: when {scenario_en}, critical data remain securely transmitted, buffered, or backfilled after recovery.", False, True),
        ],
        "I": [
            (f"{topic_zh}所需的{evidence_zh}可以通过稳定接口或受控流程关联。", f"{evidence_en.capitalize()} required for {topic_en} can be linked through stable interfaces or controlled workflows.", False, False),
            (f"不同班组和部门对{topic_zh}使用一致的名称、单位、状态和版本。", f"Shifts and departments use consistent names, units, statuses, and versions for {topic_en}.", False, False),
            (f"一线人员能从{topic_zh}结果逐级查看来源数据，而不是只看到汇总数字。", f"Frontline staff can drill from {topic_en} results to source data rather than seeing only totals.", False, False),
            (f"出现{failure_zh}时，责任人、处理时限、验证证据和关闭条件清楚。", f"When {failure_en} occurs, owners, due times, verification evidence, and closure criteria are clear.", False, False),
            (f"围绕{topic_zh}仍经常依靠人工复制、微信群/邮件或个人表格传递。", f"{topic_en.capitalize()} still often depends on manual copying, messaging/email, or personal spreadsheets.", True, False),
            (f"情景：{scenario_zh}时，相关人员能在同一事实基础上协同处理。", f"Scenario: when {scenario_en}, relevant staff can collaborate from one shared set of facts.", False, True),
        ],
        "O": [
            (f"团队定期使用{evidence_zh}识别{topic_zh}的主要损失和机会。", f"The team routinely uses {evidence_en} to identify the main losses and opportunities in {topic_en}.", False, False),
            (f"针对{failure_zh}的建议会转化为责任人、措施、时限和可量化目标。", f"Recommendations addressing {failure_en} are converted into owners, actions, due dates, and measurable targets.", False, False),
            (f"{topic_zh}措施实施后，会用同口径基线检查效果并决定标准化、修正或停止。", f"After an action for {topic_en}, the team uses a like-for-like baseline to standardise, revise, or stop it.", False, False),
            (f"{topic_zh}主要依靠个人经验临时调整，较少保留前后对比和回退条件。", f"{topic_en.capitalize()} mainly relies on ad hoc personal judgement, with little before-after evidence or rollback criteria.", True, False),
            (f"情景：{scenario_zh}时，数据或模型建议会经过人员确认、安全边界检查和结果复核。", f"Scenario: when {scenario_en}, data or model advice is subject to human confirmation, safety-boundary checks, and outcome review.", False, True),
        ],
        "H": [
            (f"围绕{topic_zh}，岗位要求、责任人和可获得支持清楚。", f"For {topic_en}, role expectations, owners, and available support are clear.", False, False),
            (f"员工能通过{evidence_zh}证明自己具备完成岗位任务的能力。", f"Staff can demonstrate job-task competence through {evidence_en}.", False, False),
            (f"出现{failure_zh}时，一线反馈会被记录、响应并用于调整工具或流程。", f"When {failure_en} occurs, frontline feedback is recorded, answered, and used to adjust tools or workflows.", False, False),
            (f"{topic_zh}更多依赖少数热心人员，人员调动后往往难以持续。", f"{topic_en.capitalize()} depends mainly on a few enthusiastic individuals and often weakens after staff changes.", True, False),
            (f"情景：{scenario_zh}时，团队能在不牺牲安全、质量和人员尊严的前提下作出决定。", f"Scenario: when {scenario_en}, the team can decide without compromising safety, quality, or worker dignity.", False, True),
        ],
    }
    return common[layer]


def make_scale_questions(layer: str) -> list[dict[str, Any]]:
    questions: list[dict[str, Any]] = []
    expected_per_dimension = {"P": 7, "C": 5, "I": 6, "O": 5, "H": 5}[layer]
    for dimension_index, values in enumerate(DIMENSIONS[layer], start=1):
        dimension, *_, prefix = values
        for item_index, (zh, en, reverse, scenario) in enumerate(stems(layer, values), start=1):
            question = {
                "id": f"{layer}_{prefix}_{item_index:02d}",
                "section": layer,
                "pcio_layer": layer,
                "dimension": dimension,
                "kind": "scenario" if scenario else "core",
                "type": "likert",
                "required": True,
                "reverse": reverse,
                "allow_na": scenario,
                "analysis_role": "scale",
                "validity_anchor": dimension_index <= 4 and item_index == 1,
                "zh": zh,
                "en": en,
            }
            questions.append(question)
        assert len(stems(layer, values)) == expected_per_dimension

    # One explicit instructed-response item per scale. It is never scored.
    attention_index = len(questions) - 1
    questions[attention_index].update(
        {
            "id": f"ATTN_{layer}_01",
            "dimension": "response_quality",
            "kind": "attention",
            "reverse": False,
            "analysis_role": "attention",
            "validity_anchor": False,
            "attention_check": {"expected": 4},
            "zh": "为确认您正在认真阅读，请在本题选择“4（同意/大多做到）”。",
            "en": "To confirm attentive reading, select 4 (Agree / usually) for this item.",
        }
    )
    return questions


def q(
    question_id: str,
    qtype: str,
    zh: str,
    en: str,
    *,
    layer: str = "B",
    dimension: str,
    role: str,
    options: str | None = None,
    max_items: int | None = None,
    rank_count: int | None = None,
) -> dict[str, Any]:
    item: dict[str, Any] = {
        "id": question_id,
        "section": "B",
        "pcio_layer": layer,
        "dimension": dimension,
        "kind": "core",
        "type": qtype,
        "required": True,
        "reverse": False,
        "analysis_role": role,
        "zh": zh,
        "en": en,
    }
    if options:
        item["options"] = options
    if max_items:
        item["max_items"] = max_items
    if rank_count:
        item["rank_count"] = rank_count
    return item


def make_barrier_questions() -> list[dict[str, Any]]:
    performance = [
        q("PERF_QUALITY", "likert", "过去12个月，本区域的质量稳定性或一次合格率有所改善。", "During the past 12 months, quality stability or first-pass yield in this area has improved.", layer="R", dimension="performance", role="outcome"),
        q("PERF_COST", "likert", "过去12个月，本区域的返工、材料、能源或维修成本有所降低。", "During the past 12 months, rework, material, energy, or maintenance cost in this area has decreased.", layer="R", dimension="performance", role="outcome"),
        q("PERF_EFF", "likert", "过去12个月，本区域的产量、设备利用率或作业效率有所提高。", "During the past 12 months, output, asset utilisation, or work efficiency in this area has improved.", layer="R", dimension="performance", role="outcome"),
        q("PERF_FLEX", "likert", "过去12个月，本区域应对订单变化、换线、插单、装卸或异常的能力有所提高。", "During the past 12 months, this area has improved its ability to handle order changes, changeovers, urgent jobs, loading, or exceptions.", layer="R", dimension="performance", role="outcome"),
    ]
    barriers = [
        ("BARR_01", "可用于数字化改造的预算和持续运维资金不足。", "Budget and recurring operating funds for digital improvement are insufficient.", "financial"),
        ("BARR_02", "老旧设备、封闭协议或供应商限制显著增加了接入难度。", "Legacy assets, closed protocols, or supplier constraints materially increase integration difficulty.", "technical"),
        ("BARR_03", "网络安全、合规或数据权限要求使项目难以推进。", "Cybersecurity, compliance, or data-access requirements make projects difficult to advance.", "external"),
        ("BARR_04", "数据标准、责任归属和跨部门流程不清晰。", "Data standards, ownership, and cross-functional workflows are unclear.", "organisational"),
        ("BARR_05", "一线人员缺少培训时间、数字技能或现场支持。", "Frontline staff lack training time, digital skills, or shop-floor support.", "workforce"),
        ("BARR_06", "项目缺少可信基线，难以证明收益并持续获得支持。", "Projects lack credible baselines, making benefits difficult to demonstrate and sustain.", "benefit"),
    ]
    barrier_items = [
        q(item_id, "likert", zh, en, dimension=dimension, role="barrier")
        for item_id, zh, en, dimension in barriers
    ]
    structured = [
        q("BAR_MULTI_01", "multiselect", "请选择当前最明显的障碍（最多8项）。", "Select the most evident current barriers (up to 8).", dimension="barrier_selection", role="priority", options="barrier_options", max_items=8),
        q("BAR_MULTI_02", "multiselect", "请选择受数字化问题影响最大的工作流程（最多5项）。", "Select the workflows most affected by digitalisation problems (up to 5).", dimension="workflow_selection", role="priority", options="workflow_options", max_items=5),
        q("BAR_MULTI_03", "multiselect", "请选择一线人员最需要的支持（最多5项）。", "Select the support frontline staff need most (up to 5).", dimension="support_selection", role="priority", options="support_options", max_items=5),
        q("BAR_RANK_01", "ranking", "请按重要性排列最需要优先解决的5项障碍。", "Rank the five barriers that should be addressed first.", dimension="barrier_ranking", role="priority", options="barrier_options", rank_count=5),
        q("BAR_RANK_02", "ranking", "请按优先级排列未来12个月最值得投入的5项PCIO行动。", "Rank the five PCIO actions most worthy of investment in the next 12 months.", dimension="pcio_priority", role="priority", options="pcio_priority_options", rank_count=5),
        q("BAR_RANK_03", "ranking", "请按优先级排列最需要持续跟踪的5项KPI。", "Rank the five KPIs that most need sustained tracking.", dimension="kpi_priority", role="priority", options="kpi_priority_options", rank_count=5),
        q("BAR_RANK_04", "ranking", "请按优先级排列确保试点成功的5项条件。", "Rank the five conditions most important for pilot success.", dimension="success_conditions", role="priority", options="success_options", rank_count=5),
        q("OPEN_01", "textarea", "请描述一个最近发生、最能体现生产数据或数字工具问题的具体事件（不要填写商业秘密）。", "Describe one recent event that best illustrates a production-data or digital-tool problem (do not include trade secrets).", dimension="critical_incident", role="open"),
        q("OPEN_02", "textarea", "如果未来3个月只能做一项低成本改进，您建议先做什么？为什么？", "If only one low-cost improvement could be made in the next three months, what should it be and why?", dimension="low_cost_priority", role="open"),
        q("OPEN_03", "textarea", "您对培训、工具、流程或跨部门协作还有哪些具体建议？", "What other specific suggestions do you have for training, tools, workflows, or cross-functional collaboration?", dimension="suggestion", role="open"),
    ]
    return performance + barrier_items + structured


def build_schema() -> dict[str, Any]:
    questions = [
        *make_scale_questions("P"),
        *make_scale_questions("C"),
        *make_scale_questions("I"),
        *make_scale_questions("O"),
        *make_scale_questions("H"),
        *make_barrier_questions(),
    ]
    section_counts = {
        "basic_information": len(PROFILE_FIELDS) + len(RESPONDENT_FIELDS),
        **{layer: sum(question["section"] == layer for question in questions) for layer in "PCIOHB"},
    }
    expected = {
        "basic_information": 25,
        "P": 70,
        "C": 50,
        "I": 60,
        "O": 50,
        "H": 30,
        "B": 20,
    }
    assert section_counts == expected, (section_counts, expected)
    assert len(questions) == 280
    assert len(PROFILE_FIELDS) + len(RESPONDENT_FIELDS) + len(questions) == 305
    assert len({question["id"] for question in questions}) == len(questions)
    assert sum(question["reverse"] for question in questions) == 46
    assert sum(question["analysis_role"] == "attention" for question in questions) == 5
    assert sum(question["kind"] == "scenario" for question in questions) == 42
    return {
        "schema_version": "3.0.0",
        "toolkit_version": "1.1.0",
        "title": {
            "zh": "PCIO 生产技术人员成熟度与关键影响因素调查问卷",
            "en": "PCIO Production-Technician Maturity and Key-Influence Survey",
        },
        "estimated_minutes": 45,
        "recall_period": {
            "zh": "除题目另有说明外，请按最近6个月的日常实际情况作答。",
            "en": "Unless an item states otherwise, answer from routine experience during the past six months.",
        },
        "privacy_notice": {
            "zh": "本问卷用于企业生产数字化诊断。默认不收集姓名、手机号或身份证号。请勿填写商业秘密、配方、密码、精确客户信息或个人敏感信息。",
            "en": "This survey supports production digitalisation diagnosis. It does not require names, phone numbers, or government identifiers. Do not enter trade secrets, formulas, passwords, precise customer information, or sensitive personal data.",
        },
        "instrument_design": {
            "target_population_zh": "直接参与或支持生产的一线操作、设备维修、工艺、质量、班组管理、能源安全和自动化/IT人员",
            "target_population_en": "Frontline operators and staff directly supporting production, including maintenance, process, quality, supervision, energy/safety, and automation/IT roles",
            "total_instrument_items": 305,
            "company_profile_items": len(PROFILE_FIELDS),
            "respondent_information_items": len(RESPONDENT_FIELDS),
            "survey_questions": len(questions),
            "likert_questions": sum(question["type"] == "likert" for question in questions),
            "reverse_scored_questions": sum(question["reverse"] for question in questions),
            "attention_checks": sum(question["analysis_role"] == "attention" for question in questions),
            "scenario_questions": sum(question["kind"] == "scenario" for question in questions),
            "validity_anchor_questions": sum(question.get("validity_anchor", False) for question in questions),
            "analysis_roles": {
                role: sum(question["analysis_role"] == role for question in questions)
                for role in ["scale", "attention", "outcome", "barrier", "priority", "open"]
            },
            "section_counts": section_counts,
            "administration_note_zh": "公司画像由项目负责人预填；技术人员通常完成12项个人信息和280道问卷题。建议分模块作答并安排40-50分钟。",
            "administration_note_en": "The project owner pre-fills the company profile. Technicians normally complete 12 respondent fields and 280 survey questions. Allow 40-50 minutes and administer by module.",
        },
        "sections": [
            {"code": "BASIC", "count": 25, "zh": "公司与个人基本信息", "en": "Company and respondent information"},
            *[
                {"code": code, "count": section_counts[code], **SECTION_LABELS[code]}
                for code in ["P", "C", "I", "O", "H", "B"]
            ],
        ],
        "likert_scale": [
            {"value": 1, "zh": "非常不同意/几乎从不", "en": "Strongly disagree / almost never"},
            {"value": 2, "zh": "不同意/较少做到", "en": "Disagree / rarely"},
            {"value": 3, "zh": "一般/有时做到", "en": "Neither agree nor disagree / sometimes"},
            {"value": 4, "zh": "同意/大多做到", "en": "Agree / usually"},
            {"value": 5, "zh": "非常同意/稳定做到", "en": "Strongly agree / consistently"},
        ],
        "missing_value": {
            "code": "NA",
            "zh": "不适用/无法判断（仅在确实没有接触相关场景时使用）",
            "en": "Not applicable / unable to judge (use only when genuinely unexposed)",
        },
        "options": OPTIONS,
        "profile_fields": PROFILE_FIELDS,
        "respondent_fields": RESPONDENT_FIELDS,
        "questions": questions,
    }


def main() -> int:
    schema = build_schema()
    OUTPUT.write_text(
        json.dumps(schema, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "output": str(OUTPUT),
                "total_instrument_items": schema["instrument_design"]["total_instrument_items"],
                "survey_questions": len(schema["questions"]),
                "section_counts": schema["instrument_design"]["section_counts"],
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


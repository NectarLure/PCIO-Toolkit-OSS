﻿"""Deterministic bilingual PCIO implementation case-report generator."""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any

from scripts.pcio_analysis import LAYER_LABELS, PCIO_LAYERS
from scripts.pcio_survey_core import load_schema


IDEAL_TARGET = 4.2


def _option_label(schema: dict[str, Any], group: str, code: str, language: str) -> str:
    for item in schema["options"].get(group, []):
        if item["code"] == code:
            return item[language]
    return code or "-"


def _score_map(analysis: dict[str, Any]) -> dict[str, float]:
    return {
        row["variable"]: row["mean"]
        for row in analysis["tables"]["scale_descriptives"]
        if row["mean"] is not None
    }


def _fmt(value: Any, digits: int = 2) -> str:
    return "N/A" if value is None else f"{float(value):.{digits}f}"


def _p_fmt(value: Any) -> str:
    if value is None:
        return "N/A"
    numeric = float(value)
    return "<0.001" if numeric < 0.001 else f"{numeric:.3f}"


def _maturity(score: float) -> tuple[str, str]:
    if score < 2.5:
        return "基础缺口", "Foundational gap"
    if score < 3.2:
        return "局部分散", "Fragmented"
    if score < 3.8:
        return "发展中", "Developing"
    if score < 4.2:
        return "受控运行", "Managed"
    return "接近理想", "Near target"


def _profile_context(profile: dict[str, Any], schema: dict[str, Any]) -> dict[str, str]:
    pain_zh = [
        _option_label(schema, "pain_points", code, "zh")
        for code in profile.get("pain_points", [])
    ]
    pain_en = [
        _option_label(schema, "pain_points", code, "en")
        for code in profile.get("pain_points", [])
    ]
    return {
        "size_zh": _option_label(schema, "company_size", profile.get("company_size", ""), "zh"),
        "size_en": _option_label(schema, "company_size", profile.get("company_size", ""), "en"),
        "industry_zh": _option_label(schema, "industry", profile.get("industry", ""), "zh"),
        "industry_en": _option_label(schema, "industry", profile.get("industry", ""), "en"),
        "production_zh": _option_label(
            schema, "production_type", profile.get("production_type", ""), "zh"
        ),
        "production_en": _option_label(
            schema, "production_type", profile.get("production_type", ""), "en"
        ),
        "pain_zh": "、".join(pain_zh) or "未明确",
        "pain_en": ", ".join(pain_en) or "not specified",
    }


def _recommendations(profile: dict[str, Any], scores: dict[str, float]) -> list[dict[str, str]]:
    industry = profile.get("industry")
    production = profile.get("production_type")
    line = profile.get("line_name") or profile.get("pilot_scope") or "selected pilot area"
    if industry in {"chemical", "new_materials", "food", "pharma"}:
        p_action_zh = "校核关键温度、压力、流量、液位和蒸汽测点；建立量程、单位、校准和缺失记录。"
        p_action_en = "Audit critical temperature, pressure, flow, level, and steam tags; record range, unit, calibration, and missingness."
    elif production in {"discrete_line", "job_shop"}:
        p_action_zh = "复用 PLC 信号采集设备状态、节拍、停机原因和关键质量结果，先覆盖瓶颈设备。"
        p_action_en = "Reuse PLC signals for state, cycle, downtime reason, and critical quality results, starting with bottleneck assets."
    elif production == "tank_loading":
        p_action_zh = "核对液位、流量、温度、压力及阀泵状态测点，统一装卸开始/结束时间口径。"
        p_action_en = "Verify level, flow, temperature, pressure, valve, and pump tags and standardise loading start/end timestamps."
    else:
        p_action_zh = "建立关键设备与工艺测点清单，优先补齐高频异常所需的最小数据。"
        p_action_en = "Build a critical asset/tag inventory and close the minimum data gaps needed for frequent exceptions."

    actions = {
        "P": {
            "zh": p_action_zh,
            "en": p_action_en,
            "tech_zh": "复用现有 PLC/DCS；必要时增加低成本智能电表、振动或温度传感器。",
            "tech_en": "Reuse installed PLC/DCS; add low-cost smart meters, vibration, or temperature sensing only where justified.",
        },
        "C": {
            "zh": "对断线、采集延迟和重复录入建立清单；先打通一个设备到一个看板的数据链。",
            "en": "List disconnections, collection delays, and duplicate entry; connect one asset-to-dashboard data path first.",
            "tech_zh": "优先 Modbus TCP/RTU、OPC UA 或 MQTT 边缘网关，并采用断点续传。",
            "tech_en": "Prefer Modbus TCP/RTU, OPC UA, or an MQTT edge gateway with store-and-forward.",
        },
        "I": {
            "zh": "建立测点、设备、批次/工单、异常和 KPI 数据字典，统一交接班和关闭责任。",
            "en": "Create a tag, asset, batch/work-order, exception, and KPI dictionary with shared handover and closure ownership.",
            "tech_zh": "采用 CSV/API、轻量时序数据库和 Grafana/现有 BI；避免先采购重型 MES。",
            "tech_en": "Use CSV/API exchange, a lightweight time-series store, and Grafana/existing BI before considering a heavy MES.",
        },
        "O": {
            "zh": "先用趋势、SPC 和规则报警验证重复问题；数据门槛通过后再进入异常检测、预测维护或 MPC。",
            "en": "Validate recurring problems with trends, SPC, and rule alerts before anomaly detection, predictive maintenance, or MPC.",
            "tech_zh": "Python/SPC、规则引擎和现有控制器参数整定；模型必须保留人工确认和回退。",
            "tech_en": "Use Python/SPC, rule engines, and existing controller tuning with human confirmation and rollback.",
        },
    }
    ordered = sorted(
        PCIO_LAYERS,
        key=lambda layer: (scores.get(layer, 5.0), PCIO_LAYERS.index(layer)),
    )
    result = []
    for priority, layer in enumerate(ordered, start=1):
        result.append(
            {
                "priority": str(priority),
                "layer": layer,
                "score": _fmt(scores.get(layer)),
                "gap": _fmt(max(0.0, IDEAL_TARGET - scores.get(layer, IDEAL_TARGET))),
                "action_zh": actions[layer]["zh"],
                "action_en": actions[layer]["en"],
                "technology_zh": actions[layer]["tech_zh"],
                "technology_en": actions[layer]["tech_en"],
                "pilot_zh": f"仅在“{line}”内试点，保留原流程回退。",
                "pilot_en": f"Pilot only within '{line}', retaining rollback to the existing process.",
            }
        )
    return result


def _scenario_factor(scores: dict[str, float], n: int) -> tuple[float, float]:
    foundation = sum(scores.get(layer, 2.5) for layer in ("P", "C", "I")) / 15
    lowest = min(scores.get(layer, 2.5) for layer in PCIO_LAYERS)
    headroom = max(0.0, min(1.0, (IDEAL_TARGET - lowest) / 3.2))
    confidence = min(1.0, n / 50)
    base = max(0.4, min(0.82, 0.30 + 0.30 * foundation + 0.15 * headroom + 0.07 * confidence))
    return max(0.3, base - 0.12), min(0.95, base + 0.12)


def _expected_effects(
    profile: dict[str, Any],
    scores: dict[str, float],
    n: int,
) -> list[dict[str, str]]:
    pain = set(profile.get("pain_points", []))
    low, high = _scenario_factor(scores, n)
    rows: list[dict[str, str]] = []
    if profile.get("industry") in {"chemical", "new_materials", "food", "pharma"}:
        readiness = min(scores.get("P", 0), scores.get("C", 0), scores.get("I", 0))
        if readiness >= 3.8:
            target_zh = "在测点、执行器和回路验证通过后，将 ±0.5℃作为挑战性参考。"
            target_en = "After tag, actuator, and loop validation, use ±0.5°C as a stretch reference."
        else:
            target_zh = "先以关键温度波动幅度降低 10%-20% 为试点情景；±0.5℃仅作后续挑战参考。"
            target_en = "First use a 10%-20% reduction in critical temperature variation as a pilot scenario; ±0.5°C remains a later stretch reference."
        rows.append(
            {
                "kpi_zh": "工艺温度稳定性",
                "kpi_en": "Process temperature stability",
                "scenario_zh": target_zh,
                "scenario_en": target_en,
                "evidence": "PCIO-E008 (E2) + toolkit scenario (P)",
            }
        )
    if "energy_cost" in pain:
        rows.append(
            {
                "kpi_zh": "单位产品蒸汽消耗",
                "kpi_en": "Steam consumption per unit",
                "scenario_zh": f"筛选情景：降低 {15.3 * low:.1f}%-{15.3 * high:.1f}%；15.3% 为既有案例上限参考，不是承诺。",
                "scenario_en": f"Screening scenario: reduce by {15.3 * low:.1f}%-{15.3 * high:.1f}%; 15.3% is an existing case reference, not a commitment.",
                "evidence": "PCIO-E009 (E2) adjusted as P",
            }
        )
    if profile.get("production_type") == "tank_loading" or "schedule_changeover" in pain:
        rows.append(
            {
                "kpi_zh": "装卸/等待时间",
                "kpi_en": "Loading or waiting time",
                "scenario_zh": f"筛选情景：减少 {29 * low:.1f}%-{29 * high:.1f}%；29% 为罐区案例参考。",
                "scenario_en": f"Screening scenario: reduce by {29 * low:.1f}%-{29 * high:.1f}%; 29% is a tank-farm case reference.",
                "evidence": "PCIO-E010 (E2) adjusted as P",
            }
        )
    generic = [
        (
            "equipment_downtime",
            "非计划停机时间",
            "Unplanned downtime",
            "试点情景：降低 5%-12%，须以连续基线和停机原因口径验证。",
            "Pilot scenario: reduce by 5%-12%, subject to continuous baseline and downtime-reason validation.",
        ),
        (
            "quality_defects",
            "返工/缺陷率",
            "Rework or defect rate",
            "试点情景：降低 5%-10%，须保持产品组合和检验口径一致。",
            "Pilot scenario: reduce by 5%-10%, holding product mix and inspection definitions constant.",
        ),
        (
            "manual_records",
            "人工记录时间",
            "Manual recording time",
            "试点情景：降低 15%-30%，前提是同步取消重复纸质流程。",
            "Pilot scenario: reduce by 15%-30% if duplicate paper steps are retired at the same time.",
        ),
        (
            "slow_exception",
            "异常响应时间",
            "Exception response time",
            "试点情景：降低 10%-20%，以同类异常的发现到关闭时间计算。",
            "Pilot scenario: reduce by 10%-20%, measured from detection to closure for comparable exceptions.",
        ),
    ]
    for code, zh, en, scenario_zh, scenario_en in generic:
        if code in pain:
            rows.append(
                {
                    "kpi_zh": zh,
                    "kpi_en": en,
                    "scenario_zh": scenario_zh,
                    "scenario_en": scenario_en,
                    "evidence": "Toolkit planning scenario (P)",
                }
            )
    return rows[:5]


def generate_bilingual_report(
    profile: dict[str, Any],
    analysis: dict[str, Any],
    schema: dict[str, Any] | None = None,
) -> str:
    schema = schema or load_schema()
    context = _profile_context(profile, schema)
    scores = _score_map(analysis)
    n = analysis["data_quality"]["retained_rows"]
    company = profile.get("company_name") or profile.get("project_code") or "贵公司"
    recommendations = _recommendations(profile, scores)
    effects = _expected_effects(profile, scores, n)
    lowest = min(PCIO_LAYERS, key=lambda layer: scores.get(layer, 5.0))
    highest = max(PCIO_LAYERS, key=lambda layer: scores.get(layer, -1.0))
    lowest_zh, lowest_en = LAYER_LABELS[lowest]["zh"], LAYER_LABELS[lowest]["en"]
    overall = scores.get("PERF_OVERALL")
    maturity_zh, maturity_en = _maturity(
        sum(scores.get(layer, 0) for layer in PCIO_LAYERS) / 4
    )
    kmo = analysis["tables"]["kmo_bartlett"]
    reliability = analysis["tables"]["reliability"]
    alpha_text = "；".join(
        f"{row['scale']}={_fmt(row['alpha'], 3)}"
        for row in reliability
        if row["alpha"] is not None
    )
    warnings = analysis["data_quality"].get("warnings", [])
    warning_zh = (
        "；".join(warning["zh"] for warning in warnings)
        if warnings
        else "未发现需要排除的结构性数据问题。"
    )
    warning_en = (
        "; ".join(warning["en"] for warning in warnings)
        if warnings
        else "No structural data exclusion issue was detected."
    )

    lines = [
        f"# {company} PCIO 实施案例分析报告",
        f"# PCIO Implementation Case Analysis for {company}",
        "",
        f"**项目代码 / Project code:** {profile.get('project_code', '-')}",
        f"**样本量 / Valid responses:** n={n}",
        f"**分析版本 / Analysis version:** {analysis['analysis_version']}",
        f"**证据声明 / Evidence statement:** 企业问卷为当前项目数据；±0.5℃、15.3%、29% 和外部 n=52 结果仅供参考，不构成效果承诺。 / Company survey results are current-project data; ±0.5°C, 15.3%, 29%, and the external n=52 findings are references only, not guarantees.",
        "",
        "## 1. 执行摘要 / Executive Summary",
        "",
        "### 中文",
        f"{company} 是一家{context['size_zh']}{context['industry_zh']}企业，本次聚焦“{profile.get('line_name', '-')}”。"
        f"基于 {n} 份有效技术人员问卷，PCIO 四层平均成熟度处于“{maturity_zh}”区间；"
        f"{lowest_zh}为当前首要瓶颈（{_fmt(scores.get(lowest))}/5），"
        f"{LAYER_LABELS[highest]['zh']}相对较高（{_fmt(scores.get(highest))}/5）。"
        f"综合生产绩效感知为 {_fmt(overall)}/5。建议先在既定试点范围内补齐基础测量、连接和数据语义，再逐步进入优化模型。",
        "",
        "### English",
        f"{company} is a {context['size_en']} {context['industry_en']} company, with this diagnosis focused on '{profile.get('line_name', '-')}.' "
        f"Based on {n} valid technician responses, average four-layer PCIO maturity is '{maturity_en}'. "
        f"{lowest_en} is the primary bottleneck ({_fmt(scores.get(lowest))}/5), while "
        f"{LAYER_LABELS[highest]['en']} is relatively stronger ({_fmt(scores.get(highest))}/5). "
        f"Perceived overall production performance is {_fmt(overall)}/5. The recommended route is to close measurement, connectivity, and data-context gaps within the pilot before advancing to optimisation models.",
        "",
        "## 2. 当前状态描述 / Current State",
        "",
        "| 层级 / Layer | 当前均值 / Current mean | 理想参考 / Target reference | 差距 / Gap | 状态 / Band |",
        "|---|---:|---:|---:|---|",
    ]
    for layer in PCIO_LAYERS:
        score = scores.get(layer)
        band_zh, band_en = _maturity(score)
        lines.append(
            f"| {LAYER_LABELS[layer]['zh']} / {LAYER_LABELS[layer]['en']} | {_fmt(score)} | {IDEAL_TARGET:.1f} | {_fmt(max(0, IDEAL_TARGET-score))} | {band_zh} / {band_en} |"
        )
    lines.extend(
        [
            "",
            f"**画像 / Profile:** {context['production_zh']} / {context['production_en']}; "
            f"核心痛点 / Core pain points: {context['pain_zh']} / {context['pain_en']}.",
            "",
            f"**数据质量 / Data quality:** {warning_zh} / {warning_en}",
            "",
            f"**信效度摘要 / Reliability and validity:** Cronbach's α: {alpha_text or 'N/A'}; "
            f"KMO={_fmt(kmo.get('kmo_overall'), 3)}, Bartlett χ²={_fmt(kmo.get('bartlett_chi_square'), 3)}, "
            f"df={kmo.get('bartlett_df', 'N/A')}, p={_p_fmt(kmo.get('bartlett_p'))}. "
            "KMO/Bartlett 只评价当前量表相关结构，不证明业务因果。 / KMO and Bartlett evaluate correlation structure, not business causality.",
            "",
            "## 3. 主要瓶颈与 PCIO 层级映射 / Main Bottlenecks and PCIO Mapping",
            "",
            "| 优先级 | 层级 | 分数 | 至4.2差距 | 诊断与行动 / Diagnosis and action |",
            "|---:|---|---:|---:|---|",
        ]
    )
    for item in recommendations:
        lines.append(
            f"| {item['priority']} | {item['layer']} | {item['score']} | {item['gap']} | "
            f"{item['action_zh']} / {item['action_en']} |"
        )
    lines.extend(
        [
            "",
            "外部区域样本 `n=52` 中，`Sensor_Inf=4.5077` 为四项技术影响均值最高，仅略高于 IoT。"
            "因此本报告把可靠感知、校准和数据质量作为高级分析前置条件，不把“传感器最高”解释为安装更多传感器必然产生收益。",
            "",
            "In the external regional sample of `n=52`, `Sensor_Inf=4.5077` was the highest of four technology-influence means, only slightly above IoT. "
            "The report therefore treats reliable sensing, calibration, and data quality as prerequisites, not as proof that adding sensors automatically creates value.",
            "",
            "## 4. 与行业情境及理想 PCIO 水平的对比 / Comparison with Industry Context and Ideal PCIO",
            "",
            f"本工具包尚无经验证的“{context['industry_zh']}行业总体均值”数据库，因此不伪造行业百分位。"
            f"本报告采用 4.2/5 作为内部理想运行参考，并结合{context['production_zh']}的测点、批次/工单和异常闭环要求作定性行业对比。"
            f"当前最大差距位于 {lowest_zh}，说明行业适配应先解决该层基础，而不是直接复制 AI 或数字孪生方案。",
            "",
            f"The toolkit does not yet hold a validated population benchmark for the {context['industry_en']} sector, so no industry percentile is fabricated. "
            f"A 4.2/5 internal operating target is used together with qualitative requirements for {context['production_en']}. "
            f"The largest gap is in {lowest_en}; sector adaptation should close this foundation before copying AI or digital-twin solutions.",
            "",
            "## 5. 模块化实施路径 / Modular Implementation Route",
            "",
            "| 顺序 | PCIO 层 | 低成本行动 / Low-cost action | 技术选型 / Technology option | 试点边界 / Pilot boundary |",
            "|---:|---|---|---|---|",
        ]
    )
    for index, item in enumerate(sorted(recommendations, key=lambda row: PCIO_LAYERS.index(row["layer"])), start=1):
        lines.append(
            f"| {index} | {item['layer']} | {item['action_zh']} / {item['action_en']} | "
            f"{item['technology_zh']} / {item['technology_en']} | {item['pilot_zh']} / {item['pilot_en']} |"
        )
    lines.extend(
        [
            "",
            "实施顺序保持 P→C→I→O。可并行准备人员培训和数据字典，但 O 层模型上线必须通过测量质量、连接稳定性和业务语义三项门槛。",
            "",
            "The execution order remains P→C→I→O. Training and data dictionaries may be prepared in parallel, but O-layer deployment must pass measurement-quality, connectivity, and business-context gates.",
            "",
            "## 6. 预期量化改善效果 / Expected Quantitative Improvement",
            "",
            "| KPI | 个性化筛选情景 / Personalised screening scenario | 证据类型 / Evidence |",
            "|---|---|---|",
        ]
    )
    for effect in effects:
        lines.append(
            f"| {effect['kpi_zh']} / {effect['kpi_en']} | "
            f"{effect['scenario_zh']} / {effect['scenario_en']} | {effect['evidence']} |"
        )
    if not effects:
        lines.append(
            "| 试点 KPI / Pilot KPI | 在 2-4 周基线后设定；当前不生成无依据的改善百分比。 / Set after a 2-4 week baseline; no unsupported percentage is generated now. | P |"
        )
    lines.extend(
        [
            "",
            "所有情景值均需用同产品、同班次或经标准化处理的基线验证，并同时报告绝对值、百分比、时间窗和异常事件。"
            "案例值仅供参考。",
            "",
            "All scenario values require a comparable or standardised baseline and must report absolute values, percentages, time windows, and exceptions. Case values are references only.",
            "",
            "## 7. PDCA 实施计划与里程碑 / PDCA Plan and Milestones",
            "",
            "| 阶段 | 周期 | 主要工作 / Main work | 通过条件 / Gate |",
            "|---|---|---|---|",
            "| Plan | 第1-2周 / Weeks 1-2 | 冻结试点边界、KPI、测点、责任人和基线口径；完成安全评审。 / Freeze pilot, KPI, tags, owners, baseline, and safety review. | 基线可复算；缺失和校准状态已记录。 / Reproducible baseline with missingness and calibration recorded. |",
            "| Do | 第3-6周 / Weeks 3-6 | 复用现有系统接入最小数据链，建立看板、异常记录和培训。 / Connect the minimum data path using installed systems; deploy dashboard, exception log, and training. | 连续两周数据完整率达到项目门槛，人工回退可用。 / Two weeks above the project completeness threshold with rollback available. |",
            "| Check | 第7-10周 / Weeks 7-10 | 对比基线和试点，检查过程稳定性、收益、误报警和人员负担。 / Compare pilot with baseline; assess stability, benefit, false alerts, and workload. | KPI 计算复核；收益与副作用同时记录。 / KPI independently checked; benefits and side effects recorded. |",
            "| Act | 第11-12周 / Weeks 11-12 | 标准化有效措施，修正无效规则，决定扩展、继续或停止。 / Standardise effective actions, revise ineffective rules, and decide expand/continue/stop. | 业务、技术、数据和安全负责人联合签字。 / Joint approval by business, technical, data, and safety owners. |",
            "",
            "## 附录：统计解释边界 / Appendix: Statistical Interpretation Boundaries",
            "",
        ]
    )
    for text in analysis["interpretation"]["zh"]:
        lines.append(f"- {text}")
    for text in analysis["interpretation"]["en"]:
        lines.append(f"- {text}")
    lines.extend(
        [
            "- 问卷结果反映人员感知和当前工作实践，应与设备历史数据、质量、能耗和停机记录交叉验证。",
            "- Survey results reflect perceptions and current practice and must be triangulated with asset, quality, energy, and downtime records.",
        ]
    )
    return "\n".join(lines) + "\n"


def write_report(
    profile: dict[str, Any],
    analysis: dict[str, Any],
    output_path: str | Path,
    schema: dict[str, Any] | None = None,
) -> Path:
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        generate_bilingual_report(profile, analysis, schema),
        encoding="utf-8",
    )
    return target


"""Command-line entry point for PCIO Phase 3 analysis and case reporting."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.pcio_analysis import (
    analyze_pcio_survey,
    combine_response_csvs,
    read_profile,
    write_analysis_package,
)
from scripts.pcio_report import write_report
from scripts.pcio_survey_core import load_schema, validate_profile


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run SPSS-style PCIO survey analysis and generate a bilingual case report."
    )
    parser.add_argument("--profile", required=True, help="Company profile JSON path.")
    parser.add_argument(
        "--responses",
        required=True,
        nargs="+",
        help="One or more technician response CSV paths.",
    )
    parser.add_argument(
        "--output-dir",
        required=True,
        help="Directory for JSON, Excel, CSV tables, and the bilingual report.",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    schema = load_schema()
    profile = read_profile(args.profile)
    errors = validate_profile(profile, schema)
    if errors:
        raise ValueError("Invalid company profile: " + "; ".join(errors))
    responses = combine_response_csvs(args.responses)
    analysis = analyze_pcio_survey(profile, responses, schema)
    output_dir = Path(args.output_dir)
    paths = write_analysis_package(analysis, output_dir)
    report_path = write_report(
        profile,
        analysis,
        output_dir / "PCIO-Implementation-Case-Report-bilingual.md",
        schema,
    )
    manifest = {
        "analysis_json": str(paths["json"]),
        "analysis_excel": str(paths["excel"]),
        "tables": str(paths["tables"]),
        "report": str(report_path),
        "valid_responses": analysis["data_quality"]["retained_rows"],
    }
    manifest_path = output_dir / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

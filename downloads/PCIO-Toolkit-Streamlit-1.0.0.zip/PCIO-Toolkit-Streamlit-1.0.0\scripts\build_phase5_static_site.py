﻿"""Build the deployable single-file PCIO static site."""

from __future__ import annotations

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parents[1]
SOURCE_PATH = ROOT / "templates" / "pcio_survey_form.html"
OUTPUT_PATH = ROOT / "site" / "index.html"
STATISTICAL_ENGINE_PATH = ROOT / "scripts" / "static_statistical_engine.js"
DOWNLOAD_PATH = ROOT / "site" / "downloads" / "PCIO-Toolkit-Streamlit-1.0.0.zip"


WEBSITE_OPEN = """
<body>
  <a class="skip-link" href="#workspace" data-t="skipToToolkit"></a>
  <div id="loadingOverlay" class="loading-overlay" hidden aria-live="polite" aria-busy="true">
    <div class="loading-box"><span class="loading-spinner" aria-hidden="true"></span><b id="loadingText"></b></div>
  </div>
  <header class="top site-header">
    <div class="top-inner">
      <a class="brand" href="#home" aria-label="PCIO Toolkit">
        <span class="brand-mark">PCIO</span>
        <span class="brand-copy"><b>Toolkit</b><small>Production Intelligence</small></span>
      </a>
      <button id="menuToggle" class="icon-button menu-toggle" type="button" aria-expanded="false" aria-controls="siteNav" title="Menu">☰</button>
      <nav id="siteNav" class="site-nav" aria-label="Primary">
        <button type="button" class="nav-link" data-open-panel="profile" data-t="navStart"></button>
        <button type="button" class="nav-link" data-open-panel="analysis" data-t="navAnalysis"></button>
        <a class="nav-download" href="downloads/PCIO-Toolkit-Streamlit-1.0.0.zip" download data-t="downloadFullVersion"></a>
      </nav>
      <div class="seg" aria-label="Language"><button id="langZh" class="active">中文</button><button id="langEn">English</button></div>
    </div>
  </header>
  <main class="shell" id="mainContent">
    <section id="home" class="hero">
      <div class="hero-kicker">PCIO Toolkit · Version 1.0.0 Web Edition</div>
      <h1 data-t="title"></h1>
      <p class="hero-copy" data-t="heroDescription"></p>
      <div class="hero-actions">
        <button id="heroStart" class="btn hero-primary" type="button"><span data-t="startUsing"></span><span aria-hidden="true">→</span></button>
        <button id="heroDemo" class="btn hero-secondary" type="button" data-t="viewDemo"></button>
        <a class="btn hero-download" href="downloads/PCIO-Toolkit-Streamlit-1.0.0.zip" download><span aria-hidden="true">↓</span><span data-t="downloadFullVersion"></span></a>
      </div>
      <div class="hero-facts" aria-label="Product facts">
        <span><b>305</b><small data-t="factSurvey"></small></span>
        <span><b>40-50</b><small data-t="factMinutes"></small></span>
        <span><b>Local</b><small data-t="factPrivacy"></small></span>
        <span><b>中 / EN</b><small data-t="factBilingual"></small></span>
      </div>
      <div class="pcio-rail" aria-label="PCIO framework">
        <div class="pcio-p"><b>P</b><span data-t="layerPShort"></span></div>
        <div class="pcio-c"><b>C</b><span data-t="layerCShort"></span></div>
        <div class="pcio-i"><b>I</b><span data-t="layerIShort"></span></div>
        <div class="pcio-o"><b>O</b><span data-t="layerOShort"></span></div>
      </div>
    </section>
    <section class="trust-strip" aria-label="Capabilities">
      <div><b data-t="trustEvidence"></b><span data-t="trustEvidenceHelp"></span></div>
      <div><b data-t="trustWorkflow"></b><span data-t="trustWorkflowHelp"></span></div>
      <div><b data-t="trustDeploy"></b><span data-t="trustDeployHelp"></span></div>
    </section>
    <div class="notice privacy-notice" data-t="privacy"></div>
    <section id="workspace" class="workspace">
      <div class="workspace-heading">
        <div><span class="eyebrow" data-t="workspaceEyebrow"></span><h2 data-t="workspaceTitle"></h2><p data-t="workspaceHelp"></p></div>
        <span class="local-data-badge" data-t="localDataBadge"></span>
      </div>
"""


WEBSITE_FOOTER = """
    </section>
  </main>
  <footer class="site-footer">
    <div class="footer-inner">
      <div><b>PCIO Toolkit 1.0.0</b><p data-t="footerStatement"></p></div>
      <div class="footer-links">
        <button type="button" data-open-panel="profile" data-t="navStart"></button>
        <button type="button" data-open-panel="analysis" data-t="navAnalysis"></button>
        <a href="downloads/PCIO-Toolkit-Streamlit-1.0.0.zip" download data-t="downloadFullVersion"></a>
      </div>
      <small>MIT License · <span data-t="referenceOnly"></span></small>
    </div>
  </footer>
"""


ANALYSIS_TAB = """
      <button class="tab" data-step="04" data-panel="analysis" data-t="analysisTab"></button>
"""


ANALYSIS_PANEL = r"""
    <section id="analysis" class="panel">
      <h2 data-t="analysisTitle"></h2>
      <div class="notice" data-t="analysisBoundary"></div>
      <div class="project-strip">
        <div class="field"><label data-t="projectCode"></label><input id="analysisProjectCode"></div>
        <button id="runStaticAnalysis" class="btn neutral" data-t="runStaticAnalysis"></button>
        <button id="loadStaticDemo" class="btn secondary" data-t="loadStaticDemo"></button>
      </div>
      <div class="roi-grid">
        <div class="field"><label data-t="investment"></label><input id="staticInvestment" type="number" min="0" step="10000" value="300000"></div>
        <div class="field"><label data-t="annualValue"></label><input id="staticAnnualValue" type="number" min="0" step="50000" value="2400000"></div>
        <div class="field"><label data-t="annualCost"></label><input id="staticAnnualCost" type="number" min="0" step="5000" value="45000"></div>
        <div class="field"><label data-t="improvementRange"></label><div class="range-row"><input id="staticImprovementLow" type="number" min="0" max="100" step="0.5" value="7.5"><span>–</span><input id="staticImprovementHigh" type="number" min="0" max="100" step="0.5" value="11.0"><span>%</span></div></div>
      </div>
      <div id="analysisStatus" class="status"></div>
      <div id="analysisMetrics" class="metrics"></div>
      <div id="analysisStatistics"></div>
      <div class="analysis-section-title"><span>02</span><div><h3 data-t="decisionEvidence"></h3><p data-t="decisionEvidenceHelp"></p></div></div>
      <div id="analysisScores"></div>
      <div id="analysisRiskMatrix"></div>
      <div id="analysisRiskTable" class="scroll"></div>
      <div id="analysisKpiTable" class="scroll"></div>
      <div id="analysisRoiTable" class="scroll"></div>
      <div id="analysisImprovementWorkflow"></div>
      <div id="analysisExecutiveSummary"></div>
      <div class="actions">
        <button id="downloadStaticAnalysis" class="btn" data-t="downloadStaticAnalysis" disabled></button>
        <button id="downloadHandoff" class="btn secondary" data-t="downloadHandoff" disabled></button>
      </div>
    </section>
"""


EXTRA_STYLE = r"""
    :root{--ink:#14283b;--ink2:#203d57;--muted:#5c6d7c;--line:#d7e0e7;--soft:#f3f6f8;--white:#fff;--teal:#08766d;--teal2:#dff3ef;--blue:#2d638d;--blue2:#e5eff7;--gold:#a66f0b;--gold2:#fff2cc;--red:#a33b35;--shadow:0 14px 34px rgba(20,40,59,.09)}
    html{scroll-behavior:smooth;scroll-padding-top:88px}body{background:#edf2f5;color:var(--ink)}button,a,input,select,textarea{outline-offset:3px}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid rgba(8,118,109,.35)}
    .skip-link{position:fixed;left:12px;top:-60px;z-index:1000;background:#fff;color:var(--ink);padding:10px 14px;border:2px solid var(--teal);font-weight:700}.skip-link:focus{top:12px}
    .site-header{background:rgba(255,255,255,.97);box-shadow:0 1px 0 rgba(20,40,59,.06)}.top-inner{max-width:1240px;min-height:68px;padding:10px 28px}.brand{display:flex;align-items:center;gap:10px;color:var(--ink);text-decoration:none}.brand-mark{display:grid;place-items:center;width:48px;height:36px;background:var(--ink);color:#fff!important;border-radius:5px;font-size:15px;letter-spacing:0}.brand-copy{display:grid;line-height:1.05}.brand-copy b{font-size:17px}.brand-copy small{margin-top:4px;color:var(--muted);font-size:10px;text-transform:uppercase;letter-spacing:0}
    .site-nav{display:flex;align-items:center;gap:4px;margin-left:auto}.nav-link,.footer-links button{border:0;background:transparent;color:var(--ink);padding:9px 11px;cursor:pointer;font-weight:650}.nav-link:hover,.footer-links button:hover{color:var(--teal)}.nav-download{margin-left:6px;background:var(--teal);color:#fff;text-decoration:none;padding:9px 12px;border-radius:5px;font-weight:700}.nav-download:hover{background:#065e57}.menu-toggle{display:none}.icon-button{width:40px;height:40px;border:1px solid var(--line);background:#fff;border-radius:5px;cursor:pointer;font-size:20px}
    .seg{margin-left:10px}.seg button{min-height:38px}.seg button.active{background:var(--ink)}
    .shell{max-width:1240px;margin:20px auto 0;padding:0 28px 70px}.hero{position:relative;overflow:hidden;min-height:380px;padding:42px 44px 0;background:var(--ink);border:0;border-radius:6px;box-shadow:var(--shadow)}.hero:after{content:"";position:absolute;right:0;top:0;width:18%;height:100%;background:#1c4058;opacity:.85}.hero>*{position:relative;z-index:1}.hero-kicker{font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:0;color:#9ecbc5}.hero h1{max-width:820px;font-size:46px;line-height:1.12;margin:12px 0 13px;letter-spacing:0}.hero-copy{max-width:790px;margin:0;color:#dce7ed;font-size:17px;line-height:1.7}.hero-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:24px}.hero-actions .btn{min-height:46px;display:inline-flex;align-items:center;justify-content:center;gap:8px;text-decoration:none;padding:10px 16px}.hero-primary{background:#fff;color:var(--ink);border-color:#fff}.hero-primary:hover{background:#e8f4f2}.hero-secondary{background:transparent;color:#fff;border-color:#87a1b3}.hero-secondary:hover,.hero-download:hover{border-color:#fff;background:#203d57}.hero-download{background:transparent;color:#fff;border-color:#52738b}
    .hero-facts{display:flex;gap:0;margin-top:25px;padding-bottom:70px}.hero-facts>span{display:grid;min-width:128px;padding:0 20px;border-left:1px solid rgba(255,255,255,.2)}.hero-facts>span:first-child{padding-left:0;border-left:0}.hero-facts b{font-size:19px}.hero-facts small{color:#aebfca;margin-top:2px}.pcio-rail{position:absolute;left:0;right:0;bottom:0;display:grid;grid-template-columns:repeat(4,1fr);height:54px}.pcio-rail div{display:flex;align-items:center;gap:10px;padding:0 22px;color:#fff}.pcio-rail b{display:grid;place-items:center;width:28px;height:28px;border:1px solid rgba(255,255,255,.55);border-radius:50%}.pcio-p{background:#08766d}.pcio-c{background:#2d638d}.pcio-i{background:#9a711d}.pcio-o{background:#8b4541}
    .trust-strip{display:grid;grid-template-columns:repeat(3,1fr);background:#fff;border:1px solid var(--line);border-top:0}.trust-strip>div{padding:20px 24px;border-left:1px solid var(--line)}.trust-strip>div:first-child{border-left:0}.trust-strip b,.trust-strip span{display:block}.trust-strip b{font-size:15px}.trust-strip span{margin-top:4px;color:var(--muted);font-size:13px;line-height:1.55}
    .privacy-notice{margin-top:18px}.workspace{scroll-margin-top:84px;margin-top:22px}.workspace-heading{display:flex;align-items:end;justify-content:space-between;gap:24px;padding:4px 2px 16px}.workspace-heading h2{font-size:25px;margin:3px 0 4px}.workspace-heading p{margin:0;color:var(--muted)}.eyebrow{font-size:12px;font-weight:800;color:var(--teal);text-transform:uppercase;letter-spacing:0}.local-data-badge{flex:0 0 auto;padding:7px 10px;background:var(--teal2);border:1px solid #abd6cf;color:#07554f;border-radius:4px;font-size:12px;font-weight:750}
    .tabs{position:sticky;top:68px;z-index:8;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:0;margin:0;background:#fff;border:1px solid var(--line);border-bottom:0;border-radius:6px 6px 0 0}.tab{position:relative;min-height:58px;padding:10px 12px 10px 44px;text-align:left;border-right:1px solid var(--line);font-size:14px}.tab:last-child{border-right:0}.tab:before{content:attr(data-step);position:absolute;left:13px;top:50%;transform:translateY(-50%);display:grid;place-items:center;width:23px;height:23px;border:1px solid #aebbc5;border-radius:50%;font-size:11px}.tab.active{background:#eef7f5;border-bottom:3px solid var(--teal);color:var(--teal)}.tab.active:before{background:var(--teal);border-color:var(--teal);color:#fff}
    .panel{border:1px solid var(--line);border-top:0;padding:30px;border-radius:0 0 6px 6px;box-shadow:var(--shadow)}.panel>h2{font-size:23px}.panel h3{border-radius:0}.grid{gap:18px}.field label{color:#263c4d}.btn{min-height:42px;transition:background .15s ease,border-color .15s ease,color .15s ease,transform .15s ease}.btn:hover{transform:translateY(-1px)}input,select,textarea{min-height:42px;border-color:#aebbc5}.question{padding:16px 4px}.question:hover{background:#f8fafb}.scale label,.option-grid label{transition:background .12s ease,border-color .12s ease}.scale label:hover,.option-grid label:hover,.scale label:has(input:checked),.option-grid label:has(input:checked){border-color:var(--teal);background:#edf8f6}.metric{background:#fff;border-top:3px solid var(--teal);border-radius:5px}
    .survey-progress{position:sticky;top:126px;z-index:7;margin:16px 0;background:#fff;border:1px solid var(--line);padding:12px 14px;box-shadow:0 6px 18px rgba(20,40,59,.08)}.survey-progress-head{display:flex;justify-content:space-between;gap:14px;font-size:13px}.survey-progress-track{height:8px;margin-top:8px;background:#e2e9ed;border-radius:4px;overflow:hidden}.survey-progress-fill{height:100%;width:0;background:var(--teal);transition:width .2s ease}.survey-progress small{color:var(--muted)}
    .loading-overlay{position:fixed;inset:0;z-index:999;background:rgba(20,40,59,.7);display:grid;place-items:center;padding:20px}.loading-overlay[hidden]{display:none!important}.loading-box{display:flex;align-items:center;gap:14px;min-width:260px;padding:20px 22px;background:#fff;border-radius:6px;box-shadow:var(--shadow)}.loading-spinner{width:28px;height:28px;border:3px solid #c9d8df;border-top-color:var(--teal);border-radius:50%;animation:pcio-spin .75s linear infinite}@keyframes pcio-spin{to{transform:rotate(360deg)}}
    .site-footer{background:var(--ink);color:#fff}.footer-inner{max-width:1240px;margin:auto;padding:30px 28px;display:grid;grid-template-columns:1.5fr 1fr auto;gap:30px;align-items:start}.footer-inner p{margin:5px 0 0;max-width:580px;color:#b9c9d4;font-size:13px}.footer-links{display:flex;flex-wrap:wrap;gap:4px}.footer-links button,.footer-links a{color:#fff;text-decoration:none;padding:6px 8px;font-size:13px}.footer-links a:hover{color:#8fd0c7}.footer-inner small{color:#9eb1bf;text-align:right}
    .roi-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;padding:16px;background:#f4f7f9;border:1px solid var(--line);margin:16px 0}
    .range-row{display:grid;grid-template-columns:1fr auto 1fr auto;gap:7px;align-items:center}
    .score-bars{display:grid;gap:9px;margin:14px 0 24px}.score-row{display:grid;grid-template-columns:170px 1fr 54px;gap:10px;align-items:center}.bar-track{height:12px;background:#e4e9ed}.bar-fill{height:100%;background:var(--teal)}
    .risk-grid{display:grid;grid-template-columns:88px repeat(4,minmax(70px,1fr));gap:4px;margin:12px 0 22px}.risk-head,.risk-axis{background:#17324d;color:#fff;padding:9px 5px;text-align:center;font-weight:700}.risk-cell{min-height:58px;padding:8px 4px;text-align:center;font-weight:700;border:1px solid #d8dee7}
    .boundary{font-size:12px;color:var(--muted)}.priority{font-weight:700;color:#8c2f27}
    .analysis-section-title{display:flex;gap:14px;align-items:flex-start;margin:30px 0 16px;padding-top:20px;border-top:3px solid #17324d}.analysis-section-title>span{display:grid;place-items:center;width:42px;height:42px;background:#17324d;color:#fff;font-weight:800}.analysis-section-title h3{font-size:23px;margin:0 0 4px}.analysis-section-title p{margin:0;color:var(--muted)}.statistical-analysis h4{margin:24px 0 8px;font-size:17px}.stat-method-note{padding:14px 16px;background:#f4f7f9;border-left:4px solid #17324d;line-height:1.65}.statistical-analysis table{font-size:13px}.statistical-analysis th{white-space:nowrap}
    .improvement-flow{margin-top:30px;padding-top:6px;border-top:3px solid #17324d}.improvement-flow>h3{font-size:24px;margin:16px 0 10px}.improvement-intro{padding:14px 16px;border-left:4px solid var(--teal);background:#f4f7f9;line-height:1.7}.workflow-evidence{margin:18px 0 24px}.workflow-evidence h4,.pdca-stage h4{font-size:18px;margin:0 0 10px}.pdca-stage{padding:20px 0;border-top:1px solid var(--line)}.pdca-stage ol,.pdca-stage ul{margin:8px 0 0;padding-left:22px}.pdca-stage li{margin:7px 0;line-height:1.65}.pdca-label{display:inline-block;min-width:66px;padding:4px 8px;background:#17324d;color:#fff;font-weight:800;text-align:center}.pcio-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 24px}.pcio-action{padding:14px 0;border-top:2px solid #d8dee7}.pcio-action h5{font-size:16px;margin:0 0 8px}.workflow-summary{margin-top:22px;padding-top:18px;border-top:3px solid var(--teal)}.workflow-summary h4{font-size:19px;margin:0 0 10px}.workflow-note{font-size:13px;color:var(--muted);line-height:1.6}
    .executive-summary{margin:34px 0 8px;padding:22px;background:#eef6f4;border:2px solid #397b70}.executive-summary .analysis-section-title{margin:0 0 18px;padding:0;border:0}.summary-findings{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-bottom:18px}.summary-finding{padding:13px;background:#fff;border-top:3px solid #397b70}.summary-finding b{display:block;font-size:18px;margin-top:5px}.summary-finding span{font-size:12px;color:var(--muted)}.executive-summary table{background:#fff}.executive-summary .summary-close{margin:14px 0 0;font-weight:700;line-height:1.65}
    @media(max-width:940px){.site-nav{position:absolute;left:18px;right:18px;top:64px;display:none;align-items:stretch;padding:10px;background:#fff;border:1px solid var(--line);box-shadow:var(--shadow)}.site-nav.open{display:grid}.site-nav .nav-link{text-align:left}.nav-download{margin:4px 0 0;text-align:center}.menu-toggle{display:block;margin-left:auto}.top-inner{position:relative}.hero:after{width:10%}.trust-strip{grid-template-columns:1fr}.trust-strip>div{border-left:0;border-top:1px solid var(--line)}.trust-strip>div:first-child{border-top:0}.footer-inner{grid-template-columns:1fr 1fr}.footer-inner small{text-align:left}}
    @media(max-width:820px){.roi-grid{grid-template-columns:1fr 1fr}.score-row{grid-template-columns:110px 1fr 44px}.risk-grid{grid-template-columns:66px repeat(4,minmax(54px,1fr));font-size:12px}.pcio-actions{grid-template-columns:1fr}.improvement-flow>h3{font-size:21px}.summary-findings{grid-template-columns:1fr}.analysis-section-title h3{font-size:20px}.hero{min-height:0;padding:32px 26px 0}.hero h1{font-size:31px}.hero-facts{display:grid;grid-template-columns:1fr 1fr;padding-bottom:72px}.hero-facts>span{padding:8px 12px;border-left:0;border-top:1px solid rgba(255,255,255,.15)}.hero-facts>span:first-child{padding-left:12px}.pcio-rail div{justify-content:center;padding:0 8px}.pcio-rail span{display:none}.workspace-heading{align-items:flex-start;flex-direction:column}.tabs{overflow-x:auto;grid-template-columns:repeat(4,minmax(160px,1fr))}.panel{padding:22px 18px}.survey-progress{top:126px}}
    @media(max-width:620px){.top-inner,.shell{padding-left:14px;padding-right:14px}.brand-copy small{display:none}.seg{margin-left:0}.seg button{padding:7px 9px}.hero{margin-left:-14px;margin-right:-14px;border-radius:0;padding:28px 18px 0}.hero h1{font-size:28px}.hero-copy{font-size:15px}.hero-actions{display:grid;grid-template-columns:1fr}.hero-actions .btn{width:100%}.hero-facts{padding-bottom:64px}.pcio-rail{height:50px}.trust-strip{margin-left:-14px;margin-right:-14px}.privacy-notice{border-radius:0}.workspace{margin-left:-14px;margin-right:-14px}.workspace-heading{padding-left:16px;padding-right:16px}.tabs{top:68px;border-left:0;border-right:0;border-radius:0}.panel{border-left:0;border-right:0;border-radius:0;box-shadow:none}.grid{grid-template-columns:1fr}.project-strip{display:block}.project-strip .btn{width:100%;margin-top:8px}.metrics{grid-template-columns:1fr}.roi-grid{grid-template-columns:1fr}.risk-grid{overflow:auto}.score-row{grid-template-columns:92px 1fr 40px}.scale,.option-grid{grid-template-columns:1fr}.footer-inner{grid-template-columns:1fr;padding:26px 18px}.survey-progress{top:126px;margin-left:-18px;margin-right:-18px;border-left:0;border-right:0}}
    @media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}.btn,.survey-progress-fill{transition:none}.loading-spinner{animation-duration:1.5s}}
"""


EXTRA_SCRIPT = r"""
<script>
Object.assign(T.zh,{
 title:"PCIO Production Survey & Personalized Toolkit",subtitle:"305项严谨问卷、多人聚合、风险、KPI 与 ROI 的专业网站版",
 heroDescription:"面向制造业生产技术人员与改善团队的本地优先诊断工具。从公司画像和匿名问卷出发，在浏览器中完成统计分析、风险排序、KPI/ROI建议和PDCA改善计划。",
 skipToToolkit:"跳转到工具工作台",navStart:"开始使用",navAnalysis:"查看分析",downloadFullVersion:"下载完整 Streamlit 版本",startUsing:"开始使用",viewDemo:"查看演示分析",
 factSurvey:"项专业调查",factMinutes:"分钟预计用时",factPrivacy:"浏览器本地处理",factBilingual:"完整双语界面",
 layerPShort:"感知",layerCShort:"连接",layerIShort:"集成",layerOShort:"优化",
 trustEvidence:"完整分析证据",trustEvidenceHelp:"信效度、差异、相关、回归、FDR与效应量在浏览器内计算。",
 trustWorkflow:"从诊断到执行",trustWorkflowHelp:"风险、KPI、ROI与3/6个月PDCA复测形成同一条改善路径。",
 trustDeploy:"开源且便于部署",trustDeployHelp:"支持GitHub Pages、Vercel，也可下载Streamlit完整版本。",
 workspaceEyebrow:"诊断工作台",workspaceTitle:"按四个步骤完成企业PCIO诊断",workspaceHelp:"先建立画像，再收集问卷、聚合数据并生成完整分析。",localDataBadge:"数据保存在当前浏览器",
 footerStatement:"面向制造业中小企业的低成本、模块化PCIO成熟度诊断与改善工具。",referenceOnly:"案例与预测数据仅供参考",
 loadingAnalysis:"正在计算统计模型和决策建议…",loadingDemo:"正在准备演示项目…",surveyProgress:"问卷进度",draftSaved:"草稿已自动保存在本机",
 analysisTab:"快速分析",analysisTitle:"4. 快速分析与决策筛选",
 analysisBoundary:"静态站在浏览器内执行描述统计、Cronbach’s α、KMO/Bartlett、组间差异、Pearson 相关、标准化回归、BH-FDR、效应量以及风险/KPI/ROI 筛选。结果用于规划和排查；正式归档建议使用 Streamlit 生成可复算 Excel。所有案例指标仅供参考。",
 runStaticAnalysis:"一键快速分析",loadStaticDemo:"载入演示数据",investment:"一次性投资",annualValue:"年度可改善价值池",annualCost:"年度新增运维成本",improvementRange:"预期改善区间",
 downloadStaticAnalysis:"下载筛选结果 JSON",downloadHandoff:"下载 Streamlit 交接包",scores:"PCIO/H 得分",riskMatrix:"4×4 风险矩阵",riskRegister:"优先风险",kpiAdvice:"KPI 建议",roiEstimate:"ROI 快速估算",
 highRisks:"高及极高风险",payback:"静态回收期",months:"个月",noAnalysisData:"未找到该项目画像或响应。请先完成画像并导入/填写问卷。",
 screeningOnly:"筛选结果，不是安全结论、预算报价或收益承诺。",
 improvementWorkflow:"企业改善操作流程（基于本次分析结果）",currentEvidence:"本次分析关键数据",planStage:"Plan（计划阶段）",doStage:"Do（执行阶段）",checkStage:"Check（检查阶段）",actStage:"Act（改进阶段）",actionSummary:"优先级最高的前 5 项行动",
 decisionEvidence:"风险、KPI 与 ROI 决策证据",decisionEvidenceHelp:"完整列出当前风险得分、成熟度、运营目标和三种财务情景",executiveSummary:"核心诊断摘要与排查清单"
});
Object.assign(T.en,{
 title:"PCIO Production Survey & Personalized Toolkit",subtitle:"Professional Web edition for a rigorous 305-item survey, aggregation, risk, KPI, and ROI",
 heroDescription:"A local-first diagnostic tool for manufacturing technicians and improvement teams. Move from company profile and anonymous survey data to statistics, risk priorities, KPI/ROI recommendations, and a PDCA improvement plan directly in the browser.",
 skipToToolkit:"Skip to toolkit",navStart:"Start",navAnalysis:"Analysis",downloadFullVersion:"Download full Streamlit edition",startUsing:"Start using",viewDemo:"View demo analysis",
 factSurvey:"professional items",factMinutes:"estimated completion",factPrivacy:"browser-local processing",factBilingual:"complete bilingual UI",
 layerPShort:"Perception",layerCShort:"Connectivity",layerIShort:"Integration",layerOShort:"Optimisation",
 trustEvidence:"Complete analytical evidence",trustEvidenceHelp:"Reliability, validity, differences, correlations, regression, FDR, and effect sizes run in the browser.",
 trustWorkflow:"Diagnosis to action",trustWorkflowHelp:"Risk, KPI, ROI, and month-3/month-6 PDCA retests form one improvement path.",
 trustDeploy:"Open and deployable",trustDeployHelp:"Deploy on GitHub Pages or Vercel, or download the full Streamlit edition.",
 workspaceEyebrow:"Diagnostic workspace",workspaceTitle:"Complete the PCIO diagnosis in four steps",workspaceHelp:"Create the profile, collect surveys, aggregate data, and generate the full analysis.",localDataBadge:"Data stays in this browser",
 footerStatement:"A low-cost, modular PCIO maturity and improvement toolkit for manufacturing SMEs.",referenceOnly:"Case and forecast data are references only",
 loadingAnalysis:"Calculating statistical models and recommendations…",loadingDemo:"Preparing the demonstration project…",surveyProgress:"Survey progress",draftSaved:"Draft autosaved on this device",
 analysisTab:"Quick Analysis",analysisTitle:"4. Rapid Analysis and Decision Screening",
 analysisBoundary:"The static site runs browser-side descriptives, Cronbach's alpha, KMO/Bartlett, group differences, Pearson correlations, standardised regression, BH-FDR, effect sizes, and risk/KPI/ROI screening. Results support planning and troubleshooting; use Streamlit for formally archived, reproducible Excel outputs. All case metrics are references only.",
 runStaticAnalysis:"Run rapid analysis",loadStaticDemo:"Load demo data",investment:"One-time investment",annualValue:"Annual addressable value",annualCost:"Added annual operating cost",improvementRange:"Expected improvement range",
 downloadStaticAnalysis:"Download screening JSON",downloadHandoff:"Download Streamlit handoff",scores:"PCIO/H scores",riskMatrix:"4×4 Risk Matrix",riskRegister:"Priority risks",kpiAdvice:"KPI recommendations",roiEstimate:"Rapid ROI estimate",
 highRisks:"High and critical risks",payback:"Simple payback",months:"months",noAnalysisData:"No profile or responses were found for this project. Complete the profile and import or collect responses first.",
 screeningOnly:"Screening output, not a safety conclusion, price quote, or benefit guarantee.",
 improvementWorkflow:"Enterprise Improvement Workflow (Based on This Analysis)",currentEvidence:"Key evidence from this analysis",planStage:"Plan",doStage:"Do",checkStage:"Check",actStage:"Act",actionSummary:"Top five priority actions",
 decisionEvidence:"Risk, KPI, and ROI Decision Evidence",decisionEvidenceHelp:"Complete current risk scores, maturity evidence, operational targets, and three financial scenarios",executiveSummary:"Core Diagnostic Summary and Troubleshooting Checklist"
});

const STATIC_RISKS=[
 {id:"T01",cat:"technical",layer:"P",impact:4,pains:["process_variation","quality_defects","manual_records"],zh:"关键测点覆盖、校准或数据完整性不足",en:"Insufficient critical-tag coverage, calibration, or completeness",pdca:"Plan/Do"},
 {id:"T02",cat:"technical",layer:"C",impact:4,pains:["data_silos","slow_exception"],zh:"采集链路中断、延迟或网络隔离不足",en:"Collection interruption, latency, or inadequate network segregation",pdca:"Do/Check"},
 {id:"O01",cat:"organisational",layer:"I",impact:3,pains:["traceability","data_silos"],zh:"设备、工单、批次和 KPI 口径不统一",en:"Inconsistent asset, work-order, batch, and KPI definitions",pdca:"Plan/Check"},
 {id:"O02",cat:"organisational",layer:"O",impact:3,pains:["collaboration","slow_exception"],zh:"试点责任人和异常关闭权责不清",en:"Unclear pilot ownership and exception-closure accountability",pdca:"Plan/Act"},
 {id:"H01",cat:"workforce",layer:"H",impact:3,pains:["manual_records","collaboration"],zh:"培训不足或新增记录负担导致工具弃用",en:"Insufficient training or added recording burden causes abandonment",pdca:"Do/Act"},
 {id:"H02",cat:"workforce",layer:"O",impact:4,pains:["safety","slow_exception"],zh:"自动建议的确认、回退和责任边界不清",en:"Unclear confirmation, rollback, and accountability for automated advice",pdca:"Plan/Act"},
 {id:"E01",cat:"external",layer:"P",impact:3,pains:["equipment_downtime","process_variation"],zh:"本地校准、备件或供应商响应不足",en:"Insufficient local calibration, spares, or supplier response",pdca:"Plan/Do"},
 {id:"E02",cat:"external",layer:"C",impact:3,pains:["data_silos","safety"],zh:"网络安全、合规或区域基础设施约束",en:"Cybersecurity, compliance, or regional infrastructure constraints",pdca:"Plan/Check"}
];
const CAT={zh:{technical:"技术",organisational:"组织",workforce:"人力",external:"外部"},en:{technical:"Technical",organisational:"Organisational",workforce:"Workforce",external:"External"}};
let staticAnalysis=null;

function layerScores(summary){
 const out={P:0,C:0,I:0,O:0,H:0};
 for(const row of summary.layer_summary)if(row.pcio_layer in out)out[row.pcio_layer]=row.mean;
 return out;
}
function likelihood(mean){return mean<2.5?4:mean<3.2?3:mean<3.8?2:1}
function riskColour(score){return score>=12?"#e06666":score>=8?"#f4b183":score>=4?"#ffe699":"#c6e0b4"}
function riskBand(score){return score>=12?(lang==="zh"?"极高":"Critical"):score>=8?(lang==="zh"?"高":"High"):score>=4?(lang==="zh"?"中":"Moderate"):(lang==="zh"?"低":"Low")}
function staticRisks(profile,scores){
 const pains=new Set(profile.pain_points||[]);
 return STATIC_RISKS.map(r=>{
   const hit=r.pains.some(p=>pains.has(p)),prob=Math.min(4,likelihood(scores[r.layer]||3)+(hit?1:0)),impact=Math.min(4,r.impact+(hit&&r.impact<4?1:0)),score=prob*impact;
   return {...r,likelihood:prob,impact,score,band:riskBand(score),colour:riskColour(score),title:r[lang],category:CAT[lang][r.cat]};
 }).sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));
}
function staticKpis(profile,scores,summary){
 const names={zh:{P:"关键测点有效覆盖率",C:"试点数据采集可用率",I:"测点到设备/工单映射完整率",O:"异常闭环按期完成率",H:"目标岗位任务验证通过率"},en:{P:"Valid critical-tag coverage",C:"Pilot data-acquisition availability",I:"Tag-to-asset/work-order mapping completeness",O:"On-time exception closure rate",H:"Target-role task competence pass rate"}};
 const items=Object.entries(scores).map(([layer,value])=>({layer,name:names[lang][layer],current:value,target:value<3.2?"90-95%":"95%+",priority:value<3.2?(lang==="zh"?"高":"High"):(lang==="zh"?"中":"Moderate")}));
 const pains=new Set(profile.pain_points||[]);
 if(pains.has("process_variation"))items.push({layer:"P",name:lang==="zh"?"关键工艺参数波动幅度":"Critical process-parameter variation",current:"baseline",target:"10-20% reduction",priority:lang==="zh"?"紧急":"Urgent"});
 if(pains.has("energy_cost"))items.push({layer:"P",name:lang==="zh"?"单位产品蒸汽/能源消耗":"Steam or energy per unit",current:"baseline",target:"7.6-11.2% reduction",priority:lang==="zh"?"紧急":"Urgent"});
 if(pains.has("equipment_downtime"))items.push({layer:"O",name:lang==="zh"?"非计划停机时间":"Unplanned downtime",current:"baseline",target:"5-12% reduction",priority:lang==="zh"?"紧急":"Urgent"});
 if(pains.has("quality_defects"))items.push({layer:"O",name:lang==="zh"?"一次合格率/缺陷率":"First-pass yield / defect rate",current:"baseline",target:"5-10% improvement",priority:lang==="zh"?"紧急":"Urgent"});
 const flex=summary.question_summary.find(x=>x.question_id==="PERF_FLEX");
 if(flex&&flex.mean<3.2)items.push({layer:"P",name:lang==="zh"?"关键状态传感覆盖率与柔性感知":"Critical-state sensing coverage and perceived flexibility",current:flex.mean,target:"90-95%; +0.2 to +0.5/5",priority:lang==="zh"?"高":"High"});
 return items.sort((a,b)=>String(a.priority).localeCompare(String(b.priority))).slice(0,9);
}
function roiEstimate(){
 const investment=Number($("#staticInvestment").value||0),annual=Number($("#staticAnnualValue").value||0),cost=Number($("#staticAnnualCost").value||0),low=Number($("#staticImprovementLow").value||0),high=Math.max(low,Number($("#staticImprovementHigh").value||0));
 const calc=pct=>{const gross=annual*pct/100,net=gross-cost;return{improvement_pct:pct,annual_gross_benefit:gross,annual_net_benefit:net,payback_months:net>0?investment/net*12:null,roi_3y_pct:investment>0?(net*3-investment)/investment*100:null}};
 return {inputs:{investment,annual_addressable_value:annual,annual_operating_cost:cost,improvement_low_pct:low,improvement_high_pct:high},scenarios:[{name:lang==="zh"?"保守":"Conservative",...calc(low)},{name:lang==="zh"?"基准":"Base",...calc((low+high)/2)},{name:lang==="zh"?"乐观":"Optimistic",...calc(high)}]};
}
function money(v){return Number(v).toLocaleString(lang==="zh"?"zh-CN":"en-US",{maximumFractionDigits:0})}
function currentDisplay(v){return typeof v==="number"&&Number.isFinite(v)?v.toFixed(4):String(v)}
function riskById(risks,id){return risks.find(r=>r.id===id)}
function layerKpi(kpis,layer){return kpis.find(k=>k.layer===layer&&typeof k.current==="number")||kpis.find(k=>k.layer===layer)}
function buildImprovementWorkflow(profile,scores,risks,kpis,roi){
 const zh=lang==="zh",pilot=profile.pilot_scope||profile.line_name||(zh?"一条代表性产线或一个生产单元":"one representative line or production cell");
 const defs=[
  {layer:"P",riskIds:["T01","E01"],zh:"完成关键测点盘点、校准、缺失补点和数据质量规则",en:"Complete critical-tag inventory, calibration, gap filling, and data-quality rules"},
  {layer:"C",riskIds:["T02","E02"],zh:"建立采集链路可用率、断线告警、边缘缓存和恢复演练",en:"Establish collection availability, disconnect alerts, edge buffering, and recovery drills"},
  {layer:"I",riskIds:["O01"],zh:"统一设备、工单、批次、单位和 KPI 编码并完成映射",en:"Standardise and map asset, work-order, batch, unit, and KPI identifiers"},
  {layer:"O",riskIds:["O02","H02"],zh:"建立异常闭环、参数优化验证、人工确认和安全回退",en:"Establish exception closure, parameter-optimisation validation, human confirmation, and safe rollback"},
  {layer:"H",riskIds:["H01"],zh:"实施岗位培训、减负设计和跨班组责任矩阵",en:"Implement role-based training, workload reduction, and a cross-shift responsibility matrix"}
 ];
 const foundationBias={P:6,C:4,H:3,I:2,O:1};
 const actions=defs.map(d=>{
   const linked=d.riskIds.map(id=>riskById(risks,id)).filter(Boolean),kpi=layerKpi(kpis,d.layer);
   const riskText=linked.map(r=>`${r.id}=${r.score}`).join(zh?"、":", ");
   const expected=[
    riskText?(zh?`${riskText} 降至 7 分及以下，或至少下降 4 分`:`reduce ${riskText} to 7 or below, or by at least 4 points`):"",
    kpi?(zh?`${kpi.name}：诊断当前值 ${currentDisplay(kpi.current)}，运营目标 ${kpi.target}`:`${kpi.name}: diagnostic current ${currentDisplay(kpi.current)}; operational target ${kpi.target}`):""
   ].filter(Boolean).join(zh?"；":"; ");
   const rank=Math.max(0,...linked.map(r=>r.score))*10+(5-(scores[d.layer]||3))+(foundationBias[d.layer]||0);
   return {layer:d.layer,action:d[lang],risk_ids:d.riskIds,risk_scores:Object.fromEntries(linked.map(r=>[r.id,r.score])),expected,retest:zh?"实施后 3 个月首次完整复测；6 个月第二次复盘":"first full retest at month 3; second review at month 6",rank};
 }).sort((a,b)=>b.rank-a.rank);
 return {
   pilot_scope:pilot,
   top_risks:risks.slice(0,5).map(r=>({id:r.id,score:r.score,title:r.title,band:r.band})),
   risk_register:risks.map(r=>({id:r.id,score:r.score,likelihood:r.likelihood,impact:r.impact,layer:r.layer,pdca:r.pdca,title:r.title,band:r.band})),
   kpi_targets:kpis.map(k=>({layer:k.layer,name:k.name,current:currentDisplay(k.current),target:k.target,priority:k.priority})),
   roi_scenarios:roi.scenarios,
   top_actions:actions,
   retest_months:[3,6]
 };
}
function renderImprovementWorkflow(workflow,scores){
 const zh=lang==="zh",riskText=workflow.risk_register.map(r=>`${r.id}=${r.score}`).join(zh?"、":", ");
 const scoreText=Object.entries(scores).map(([layer,value])=>`${layer}=${value.toFixed(4)}`).join(zh?"、":", ");
 const riskRows=workflow.risk_register.map(r=>`<tr><td>${r.id}</td><td>${esc(r.title)}</td><td>${r.likelihood}</td><td>${r.impact}</td><td style="background:${riskColour(r.score)}">${r.score} / ${r.band}</td><td>${r.layer}</td><td>${r.pdca}</td></tr>`).join("");
 const kpiRows=workflow.kpi_targets.map(k=>`<tr><td>${k.layer}</td><td>${esc(k.name)}</td><td>${esc(k.current)}</td><td>${esc(k.target)}</td><td>${esc(k.priority)}</td></tr>`).join("");
 const roiRows=workflow.roi_scenarios.map(r=>`<tr><td>${esc(r.name)}</td><td>${r.improvement_pct.toFixed(1)}%</td><td>${money(r.annual_gross_benefit)}</td><td>${money(r.annual_net_benefit)}</td><td>${r.payback_months===null?"N/A":r.payback_months.toFixed(1)+" "+T[lang].months}</td><td>${r.roi_3y_pct===null?"N/A":r.roi_3y_pct.toFixed(1)+"%"}</td></tr>`).join("");
 const topRiskText=workflow.top_risks.map(r=>`${r.id}=${r.score}${zh?"（":" ("}${esc(r.title)}${zh?"）":")"}`).join(zh?"；":"; ");
 const pcioActions={
  P:zh?["建立关键设备、测点、量程、精度、校准周期和责任人的台账。","对温度、压力、流量、振动、电耗等关键测点做现场比对与校准，记录偏差和处置。","优先复用现有 PLC/仪表接口，仅对缺失的关键状态采用低成本传感器补点。","配置缺失、冻结、越界、漂移、时间戳不同步和重复值规则，并明确告警责任人。","连续保留不少于四周的基线数据，形成数据字典和测点验收清单。"]:["Create a register of critical assets, tags, ranges, accuracy, calibration intervals, and owners.","Field-check and calibrate critical temperature, pressure, flow, vibration, and energy tags; record deviations and disposition.","Reuse existing PLC and instrument interfaces first; add low-cost sensors only for missing critical states.","Configure missing, frozen, out-of-range, drift, timestamp, and duplicate-value rules with named alert owners.","Retain at least four weeks of baseline data and issue a data dictionary and tag acceptance checklist."],
  C:zh?["绘制试点网络、网关、PLC、无线覆盖和数据去向图，识别盲区与单点故障。","逐班记录链路可用率、延迟、丢包、断线次数和平均恢复时间。","在边缘网关配置本地缓存、断点续传、自动重连和时钟同步。","采用分区分域、最小权限、白名单和只读采集，变更前完成安全审批。","建立断线告警、升级路径和月度恢复演练，保留演练证据。"]:["Map the pilot network, gateways, PLCs, wireless coverage, and data destinations to identify dead zones and single points of failure.","Record availability, latency, packet loss, disconnects, and mean recovery time by shift.","Configure local buffering, store-and-forward, automatic reconnection, and clock synchronisation at the edge.","Use network segmentation, least privilege, allowlists, and read-only acquisition with approved change control.","Create disconnect alerts, escalation routes, and monthly recovery drills with retained evidence."],
  I:zh?["统一设备、测点、工单、批次、产品、班组、单位和状态码命名规则。","建立测点到设备、工单、批次和质量结果的映射表，并指定数据所有者。","先用现有 Excel/CSV/API/OPC UA 做最小接口，避免一次性替换全部系统。","为操作员、班组长、工艺和维护配置基于角色的共享看板和数据权限。","把异常发现、确认、派工、处理、验证和关闭写入同一电子闭环并纳入交接班。"]:["Standardise naming for assets, tags, work orders, batches, products, shifts, units, and status codes.","Create tag-to-asset, work-order, batch, and quality-result mappings with named data owners.","Use minimum viable Excel, CSV, API, or OPC UA interfaces before considering wholesale system replacement.","Provide role-based shared dashboards and permissions for operators, team leaders, process, and maintenance staff.","Record detection, confirmation, assignment, treatment, verification, and closure in one electronic exception loop linked to shift handover."],
  O:zh?["每周对停机、缺陷、能耗、等待和告警做 Pareto 分析，只选择一个主要损失开展试验。","为关键参数设定控制限、变更审批、试验窗口、人工确认和可验证的回退条件。","先使用阈值、趋势和状态维修规则，再在数据稳定后评估预测模型或 AI。","通过小批量或短周期 A/B 对照验证质量、能耗、节拍和柔性改善，保留原始记录。","将有效规则固化为 SOP、看板和培训；无效或不安全的规则立即停用并复盘。"]:["Run weekly Pareto analysis of downtime, defects, energy, waiting, and alarms, selecting one dominant loss for each experiment.","Define control limits, approvals, experiment windows, human confirmation, and verifiable rollback conditions for critical parameters.","Use thresholds, trends, and condition-based maintenance first; evaluate predictive models or AI only after data stabilises.","Validate quality, energy, cycle-time, and flexibility changes through small-batch or short-cycle controlled comparisons.","Standardise effective rules in SOPs, dashboards, and training; stop and review ineffective or unsafe rules immediately."]
 };
 const actionColumns=Object.entries(pcioActions).map(([layer,items])=>`<div class="pcio-action"><h5>${layer} · ${esc(LAYERS[lang][layer]||layer)}</h5><ol>${items.map(x=>`<li>${esc(x)}</li>`).join("")}</ol></div>`).join("");
 const summaryRows=workflow.top_actions.map((a,index)=>`<tr><td>${index+1}</td><td>${a.layer}</td><td>${esc(a.action)}</td><td>${esc(a.expected)}</td><td>${esc(a.retest)}</td></tr>`).join("");
 return `<section class="improvement-flow">
  <div class="analysis-section-title"><span>03</span><div><h3>${T[lang].improvementWorkflow}</h3><p>${zh?"把当前分析证据转化为可执行的六个月 PDCA 闭环":"Convert current evidence into an executable six-month PDCA loop"}</p></div></div>
  <p class="improvement-intro">${zh?`本流程把本次筛选结果转化为一个可执行的 6 个月 PDCA 周期。当前 PCIO/H 诊断分数为 ${scoreText}；风险登记册为 ${riskText}。风险、KPI 和 ROI 均来自当前页面输入与问卷聚合结果，属于规划筛选，不构成收益或安全承诺。`:`This workflow converts the current screening into an executable six-month PDCA cycle. Current PCIO/H diagnostic scores are ${scoreText}; the risk register is ${riskText}. Risks, KPIs, and ROI are derived from the current page inputs and aggregated survey responses and remain planning screens, not benefit or safety guarantees.`}</p>
  <div class="workflow-evidence">
   <h4>${T[lang].currentEvidence}</h4>
   <div class="scroll"><table><thead><tr><th>ID</th><th>${zh?"具体风险":"Risk"}</th><th>${zh?"概率":"Likelihood"}</th><th>${zh?"影响":"Impact"}</th><th>${zh?"得分/等级":"Score/Band"}</th><th>PCIO</th><th>PDCA</th></tr></thead><tbody>${riskRows}</tbody></table></div>
   <div class="scroll"><table><thead><tr><th>PCIO</th><th>KPI</th><th>${zh?"诊断当前值":"Diagnostic current"}</th><th>${zh?"运营目标":"Operational target"}</th><th>${zh?"优先级":"Priority"}</th></tr></thead><tbody>${kpiRows}</tbody></table></div>
   <div class="scroll"><table><thead><tr><th>${zh?"情景":"Scenario"}</th><th>${zh?"改善率":"Improvement"}</th><th>${zh?"年度毛收益":"Annual gross benefit"}</th><th>${zh?"年度净收益":"Annual net benefit"}</th><th>${T[lang].payback}</th><th>3-year ROI</th></tr></thead><tbody>${roiRows}</tbody></table></div>
   <p class="workflow-note">${zh?"说明：2.x/3.x 等当前值是问卷成熟度诊断分数（1-5分），90-95% 等目标是试点上线后需通过设备台账或系统日志测量的运营 KPI，两者不可直接当作同一单位相减。":"Note: current values such as 2.x or 3.x are survey maturity scores on a 1-5 scale. Targets such as 90-95% are operational KPIs to be measured from asset registers or system logs after launch; they must not be subtracted as if they shared a unit."}</p>
  </div>
  <div class="pdca-stage"><h4><span class="pdca-label">P</span> ${T[lang].planStage}</h4><ol>
   <li>${zh?`按 4×4 风险得分排序。当前前五项为：${topRiskText}。12-16 分列为立即处置，8-11 分列为第二波，7 分及以下进入监控清单。`:`Prioritise by 4x4 risk score. The current top five are: ${topRiskText}. Treat scores 12-16 immediately, 8-11 in the second wave, and 7 or below through monitoring.`}</li>
   <li>${zh?`把试点限定在“${esc(workflow.pilot_scope)}”，建议周期 8-12 周，覆盖一条线、一个班组和 3-5 台关键设备；冻结基线口径后再启动。`:`Limit the pilot to "${esc(workflow.pilot_scope)}" for 8-12 weeks, covering one line, one shift team, and three to five critical assets; freeze baseline definitions before launch.`}</li>
   <li>${zh?"第一轮资源建议按 P 40%、C 25%、I 20%、O 15% 配置，另预留岗位培训、校准、网络安全审查和现场停机窗口；这是基础优先的规划比例，须由企业确认工时与预算。":"For the first wave, plan approximately 40% of effort for P, 25% for C, 20% for I, and 15% for O, with separate allowances for training, calibration, cybersecurity review, and planned downtime. Confirm labour and budget locally."}</li>
   <li>${zh?`把每项 KPI 写成“数据源、公式、责任人、频率、基线、3个月门槛、6个月目标”。例如 ${workflow.kpi_targets.map(k=>`${k.name} ${k.current} → ${k.target}`).join("；")}。`:`Define each KPI with source, formula, owner, frequency, baseline, month-3 gate, and month-6 target. Current examples: ${workflow.kpi_targets.map(k=>`${k.name} ${k.current} to ${k.target}`).join("; ")}.`}</li>
   <li>${zh?`以保守情景作为扩线门槛：${workflow.roi_scenarios[0].improvement_pct.toFixed(1)}% 改善、${workflow.roi_scenarios[0].payback_months===null?"N/A":workflow.roi_scenarios[0].payback_months.toFixed(1)+"个月"}回收、三年 ROI ${workflow.roi_scenarios[0].roi_3y_pct===null?"N/A":workflow.roi_scenarios[0].roi_3y_pct.toFixed(1)+"%"}。未达到门槛前不扩大投资。`:`Use the conservative case as the scale gate: ${workflow.roi_scenarios[0].improvement_pct.toFixed(1)}% improvement, ${workflow.roi_scenarios[0].payback_months===null?"N/A":workflow.roi_scenarios[0].payback_months.toFixed(1)+" months"} payback, and ${workflow.roi_scenarios[0].roi_3y_pct===null?"N/A":workflow.roi_scenarios[0].roi_3y_pct.toFixed(1)+"%"} three-year ROI. Do not scale investment before the gate is evidenced.`}</li>
  </ol></div>
  <div class="pdca-stage"><h4><span class="pdca-label">D</span> ${T[lang].doStage}</h4><div class="pcio-actions">${actionColumns}</div></div>
  <div class="pdca-stage"><h4><span class="pdca-label">C</span> ${T[lang].checkStage}</h4>
   <p><strong>${zh?"建议在实施后 3 个月进行第一次完整复测。":"Conduct the first full retest three months after implementation."}</strong> ${zh?"使用相同题项、相同计分规则和尽可能相同的岗位/班组样本；同时导出设备台账、链路日志、异常闭环和财务凭证。":"Use the same items, scoring rules, and, where possible, the same role and shift sample; also export asset registers, connection logs, exception records, and financial evidence."}</p>
   <p><strong>${zh?"建议在实施后 6 个月进行第二次复盘测试。":"Conduct the second review test six months after implementation."}</strong> ${zh?"确认改善是否持续、是否跨班组复制，并复核基准 ROI 情景是否由真实净收益支持。":"Confirm whether gains persist and transfer across shifts, and whether actual net benefit supports the base ROI case."}</p>
   <div class="scroll"><table><thead><tr><th>${zh?"时间节点":"Time"}</th><th>${zh?"重点检查":"Primary checks"}</th><th>${zh?"建议判定门槛":"Suggested gate"}</th></tr></thead><tbody>
    <tr><td>${zh?"每周（前12周）":"Weekly (first 12 weeks)"}</td><td>${zh?"数据缺失/冻结、断线、告警、异常关闭、培训参与、试验偏差":"Missing/frozen data, disconnects, alarms, exception closure, training participation, experiment deviations"}</td><td>${zh?"重大安全或数据完整性问题立即停用并回退":"Stop and roll back immediately for material safety or data-integrity issues"}</td></tr>
    <tr><td>${zh?"实施后 3 个月":"Month 3"}</td><td>${zh?`全部风险得分（${riskText}）、全部 KPI、P/C/I/O/H 分数、实际净收益与问卷质量`:`All risk scores (${riskText}), all KPIs, P/C/I/O/H scores, actual net benefit, and survey quality`}</td><td>${zh?"12-16 分风险至少下降 4 分或下降一个等级；重点成熟度分数建议提高至少 0.20/5；运营 KPI 明确缩小与目标的差距":"Reduce 12-16 risks by at least 4 points or one band; improve priority maturity scores by at least 0.20/5; show a measurable closing of operational KPI gaps"}</td></tr>
    <tr><td>${zh?"实施后 6 个月":"Month 6"}</td><td>${zh?"风险是否稳定在 7 分及以下、KPI 改善是否持续、跨班组一致性、基准 9.3% 情景及回收期":"Whether risks remain at 7 or below, KPI gains persist, shifts are consistent, and the 9.3% base case/payback is supported"}</td><td>${zh?"重点成熟度分数累计提高至少 0.35/5；高风险无反弹；实际收益口径可审计后才批准扩线":"At least 0.35/5 cumulative improvement in priority maturity scores; no high-risk rebound; approve scaling only after benefit definitions are auditable"}</td></tr>
   </tbody></table></div>
  </div>
  <div class="pdca-stage"><h4><span class="pdca-label">A</span> ${T[lang].actStage}</h4><ol>
   <li>${zh?"达到门槛：固化测点、接口、告警、异常闭环和岗位责任为 SOP；只向一条相邻产线复制，并重新建立该线基线。":"If gates are met, standardise tags, interfaces, alerts, exception closure, and role responsibilities in SOPs; replicate to one adjacent line only and establish a new baseline."}</li>
   <li>${zh?"部分达到：对未改善 KPI 做人、机、料、法、环和测量系统复盘，调整传感器位置、采样周期、界面、培训或责任分工后再试。":"If partially met, review people, machine, material, method, environment, and measurement causes for stalled KPIs; adjust sensor placement, sampling, interfaces, training, or ownership and retest."}</li>
   <li>${zh?"未达到或风险上升：停止扩线，执行安全回退，删除无效动作，重新估算成本和 ROI；不得用乐观情景掩盖未实现收益。":"If unmet or risks rise, stop scaling, execute safe rollback, remove ineffective actions, and recalculate cost and ROI; do not use the optimistic case to conceal unrealised value."}</li>
   <li>${zh?"证据不足：补充基线、日志、校准和样本代表性后再判断，不把问卷感知变化直接当作财务收益。":"If evidence is insufficient, improve baselines, logs, calibration, and sample representativeness before deciding; do not treat survey-perception changes as financial gains."}</li>
   <li>${zh?"把 6 个月复盘结论转为下一轮 Plan：更新风险登记册、KPI 目标、资源比例和试点边界，形成持续改进闭环。":"Convert the month-6 review into the next Plan by updating the risk register, KPI targets, resource allocation, and pilot boundary, closing the continuous-improvement loop."}</li>
  </ol></div>
  <div class="workflow-summary"><h4>${T[lang].actionSummary}</h4><div class="scroll"><table><thead><tr><th>${zh?"优先级":"Priority"}</th><th>PCIO</th><th>${zh?"行动":"Action"}</th><th>${zh?"预期改善效果":"Expected effect"}</th><th>${zh?"复测时间":"Retest"}</th></tr></thead><tbody>${summaryRows}</tbody></table></div>
   <p class="workflow-note">${zh?"简要结论：先处理当前最高分风险并夯实 P/C 基础，再完成 I 的数据口径和 O 的闭环验证；3 个月决定是否纠偏，6 个月决定是否标准化和扩线。所有数值仅供规划参考。":"Summary: address the highest current risks and stabilise P/C first, then complete I definitions and O closed-loop validation. Month 3 determines correction; month 6 determines standardisation and scaling. All values are planning references only."}</p>
  </div>
 </section>`;
}
function renderExecutiveSummary(statistical,risks,kpis,roi,workflow,scores){
 const zh=lang==="zh",lowest=Object.entries(scores).sort((a,b)=>a[1]-b[1])[0],topRisk=risks[0],base=roi.scenarios[1]||roi.scenarios[0];
 const performancePairs=statistical.tables.correlations.long.filter(r=>r.r!==null&&(r.variable_1==="PERF_OVERALL"||r.variable_2==="PERF_OVERALL")).filter(r=>PCIO_STATIC_LAYERS.includes(r.variable_1)||PCIO_STATIC_LAYERS.includes(r.variable_2)).sort((a,b)=>Math.abs(b.r)-Math.abs(a.r));
 const strongest=performancePairs[0],overallModel=statistical.tables.regressions.find(m=>m.dependent==="PERF_OVERALL"),significantPredictors=(overallModel?.coefficients||[]).filter(r=>r.predictor!=="Intercept"&&r.p_fdr_bh!==null&&r.p_fdr_bh<0.05),significantGroups=statistical.tables.group_differences.filter(r=>r.p_fdr_bh!==null&&r.p_fdr_bh<0.05);
 const keyKpi=kpis.find(k=>k.layer===lowest[0]&&typeof k.current==="number")||kpis[0];
 const findings=[
  {label:zh?"最弱成熟度层":"Lowest maturity layer",value:`${lowest[0]} = ${lowest[1].toFixed(4)}`},
  {label:zh?"最高风险":"Highest risk",value:`${topRisk.id} = ${topRisk.score}`},
  {label:zh?"基准 ROI":"Base ROI",value:`${base.improvement_pct.toFixed(1)}% / ${base.payback_months===null?"N/A":base.payback_months.toFixed(1)+(zh?"个月":" months")}`}
 ];
 const rows=[
  {finding:zh?"成熟度短板":"Maturity bottleneck",evidence:`${lowest[0]}=${lowest[1].toFixed(4)}; ${keyKpi.name} ${currentDisplay(keyKpi.current)} → ${keyKpi.target}`,action:workflow.top_actions.find(a=>a.layer===lowest[0])?.action||workflow.top_actions[0].action,retest:zh?"3个月、6个月":"Months 3 and 6"},
  {finding:zh?"风险优先级":"Risk priority",evidence:risks.slice(0,5).map(r=>`${r.id}=${r.score}`).join(zh?"、":", "),action:workflow.top_actions.find(a=>a.risk_ids.includes(topRisk.id))?.action||workflow.top_actions[0].action,retest:zh?"每周监控；3个月复测":"Weekly; month 3"},
  {finding:zh?"绩效统计关联":"Performance association",evidence:strongest?`${strongest.variable_1} ↔ ${strongest.variable_2}: r=${pcioFmt(strongest.r)}, FDR=${pcioP(strongest.p_fdr_bh)}`:(zh?"当前样本不可估计":"Not estimable in the current sample"),action:zh?"作为诊断线索，不作因果解释":"Use as a diagnostic lead, not a causal claim",retest:zh?"3个月复测":"Month 3"},
  {finding:zh?"回归与组间差异":"Regression and group differences",evidence:zh?`FDR显著预测项 ${significantPredictors.length} 个；显著组间差异 ${significantGroups.length} 项`:`${significantPredictors.length} FDR-significant predictors; ${significantGroups.length} group differences`,action:zh?"显著项结合效应量和现场机制复核；不显著不等于完全无差异":"Review significant results with effect size and mechanism; non-significance is not proof of equality",retest:zh?"6个月复盘":"Month 6"},
  {finding:zh?"财务门槛":"Financial gate",evidence:`${base.name}: ${base.improvement_pct.toFixed(1)}%, ${money(base.annual_net_benefit)}, ${base.payback_months===null?"N/A":base.payback_months.toFixed(1)+(zh?"个月":" months")}, 3-year ROI ${base.roi_3y_pct===null?"N/A":base.roi_3y_pct.toFixed(1)+"%"}`,action:zh?"真实净收益达到保守门槛后再扩线":"Scale only after actual net benefit clears the conservative gate",retest:zh?"3个月初审、6个月批准":"Month 3 screen; month 6 approval"}
 ];
 return `<section class="executive-summary"><div class="analysis-section-title"><span>04</span><div><h3>${T[lang].executiveSummary}</h3><p>${zh?"用于管理层快速查看和后续问题排查；详细依据保留在前述统计与决策表中":"For management review and later troubleshooting; detailed evidence remains in the preceding tables"}</p></div></div>
  <div class="summary-findings">${findings.map(f=>`<div class="summary-finding"><span>${f.label}</span><b>${esc(f.value)}</b></div>`).join("")}</div>
  <div class="scroll"><table><thead><tr><th>${zh?"核心发现":"Core finding"}</th><th>${zh?"当前证据":"Current evidence"}</th><th>${zh?"优先动作":"Priority action"}</th><th>${zh?"复测节点":"Retest"}</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.finding)}</td><td>${esc(r.evidence)}</td><td>${esc(r.action)}</td><td>${esc(r.retest)}</td></tr>`).join("")}</tbody></table></div>
  <p class="summary-close">${zh?"排查顺序：先确认样本与注意力检测质量，再核对最高风险和最低成熟度层，随后检查 KPI 数据源与 ROI 假设，最后才解释显著性结果。":"Troubleshooting order: verify sample and attention-check quality first, then the highest risks and lowest maturity layer, then KPI sources and ROI assumptions, and only then interpret significance results."}</p>
 </section>`;
}
function renderScoreBars(scores){
 return `<h3>${T[lang].scores}</h3><div class="score-bars">${Object.entries(scores).map(([k,v])=>`<div class="score-row"><b>${esc(LAYERS[lang][k]||k)}</b><div class="bar-track"><div class="bar-fill" style="width:${Math.max(0,Math.min(100,v/5*100))}%"></div></div><span>${v.toFixed(2)}</span></div>`).join("")}</div>`;
}
function renderRiskMatrix(risks){
 let html=`<h3>${T[lang].riskMatrix}</h3><div class="risk-grid"><div class="risk-head">4×4</div>${[1,2,3,4].map(i=>`<div class="risk-head">${lang==="zh"?"影响":"Impact"} ${i}</div>`).join("")}`;
 for(let l=4;l>=1;l--){html+=`<div class="risk-axis">${lang==="zh"?"概率":"Likelihood"} ${l}</div>`;for(let i=1;i<=4;i++){const ids=risks.filter(r=>r.likelihood===l&&r.impact===i).map(r=>r.id).join("<br>")||"&nbsp;";html+=`<div class="risk-cell" style="background:${riskColour(l*i)}">${ids}</div>`}}
 return html+"</div>";
}
function renderStaticAnalysis(){
 const code=normaliseCode($("#analysisProjectCode").value||$("#aggregateProjectCode").value),profile=loadProfile(code),rows=getResponses(code);
 if(!profile||!rows.length){status("#analysisStatus",T[lang].noAnalysisData,false);return}
 const summary=aggregate(rows),statistical=pcioStaticStatistics(rows),scores=layerScores(summary),risks=staticRisks(profile,scores),kpis=staticKpis(profile,scores,summary),roi=roiEstimate(),workflow=buildImprovementWorkflow(profile,scores,risks,kpis,roi),high=risks.filter(r=>r.score>=8).length,paybacks=roi.scenarios.map(x=>x.payback_months).filter(x=>x!==null);
 staticAnalysis={toolkit_version:"1.0.0-web",generated_at_utc:new Date().toISOString(),project_code:code,evidence_boundary_zh:"浏览器端 SPSS 风格分析与决策筛选，仅供规划；不构成安全结论、预算报价或收益承诺。",evidence_boundary_en:"Browser-side SPSS-style analysis and decision screening for planning only; not a safety conclusion, price quote, or benefit guarantee.",profile,summary,statistical_analysis:statistical,scores,risks,kpis,roi,improvement_workflow:workflow};
 $("#analysisMetrics").innerHTML=`<div class="metric"><span>${T[lang].responses}</span><b>${rows.length}</b></div><div class="metric"><span>${T[lang].highRisks}</span><b>${high}</b></div><div class="metric"><span>${T[lang].payback}</span><b>${paybacks.length?`${Math.min(...paybacks).toFixed(1)}-${Math.max(...paybacks).toFixed(1)} ${T[lang].months}`:"N/A"}</b></div>`;
 $("#analysisStatistics").innerHTML=pcioRenderStatisticalAnalysis(statistical);
 $("#analysisScores").innerHTML=renderScoreBars(scores);
 $("#analysisRiskMatrix").innerHTML=renderRiskMatrix(risks);
 $("#analysisRiskTable").innerHTML=`<h3>${T[lang].riskRegister}</h3><table><thead><tr><th>ID</th><th>${lang==="zh"?"类别":"Category"}</th><th>${lang==="zh"?"风险":"Risk"}</th><th>${lang==="zh"?"得分":"Score"}</th><th>PDCA</th></tr></thead><tbody>${risks.map(r=>`<tr><td>${r.id}</td><td>${r.category}</td><td>${esc(r.title)}</td><td style="background:${r.colour}">${r.score} / ${r.band}</td><td>${r.pdca}</td></tr>`).join("")}</tbody></table><p class="boundary">${T[lang].screeningOnly}</p>`;
 $("#analysisKpiTable").innerHTML=`<h3>${T[lang].kpiAdvice}</h3><table><thead><tr><th>PCIO</th><th>KPI</th><th>${lang==="zh"?"当前":"Current"}</th><th>${lang==="zh"?"目标":"Target"}</th><th>${lang==="zh"?"优先级":"Priority"}</th></tr></thead><tbody>${kpis.map(k=>`<tr><td>${k.layer}</td><td>${esc(k.name)}</td><td>${currentDisplay(k.current)}</td><td>${k.target}</td><td class="priority">${k.priority}</td></tr>`).join("")}</tbody></table>`;
 $("#analysisRoiTable").innerHTML=`<h3>${T[lang].roiEstimate}</h3><table><thead><tr><th>${lang==="zh"?"情景":"Scenario"}</th><th>${lang==="zh"?"改善率":"Improvement"}</th><th>${lang==="zh"?"年度毛收益":"Annual gross benefit"}</th><th>${lang==="zh"?"年度净收益":"Annual net benefit"}</th><th>${T[lang].payback}</th><th>3-year ROI</th></tr></thead><tbody>${roi.scenarios.map(r=>`<tr><td>${r.name}</td><td>${r.improvement_pct.toFixed(1)}%</td><td>${money(r.annual_gross_benefit)}</td><td>${money(r.annual_net_benefit)}</td><td>${r.payback_months===null?"N/A":r.payback_months.toFixed(1)+" "+T[lang].months}</td><td>${r.roi_3y_pct===null?"N/A":r.roi_3y_pct.toFixed(1)+"%"}</td></tr>`).join("")}</tbody></table><p class="boundary">${T[lang].screeningOnly}</p>`;
 $("#analysisImprovementWorkflow").innerHTML=renderImprovementWorkflow(workflow,scores);
 $("#analysisExecutiveSummary").innerHTML=renderExecutiveSummary(statistical,risks,kpis,roi,workflow,scores);
 status("#analysisStatus",lang==="zh"?"快速分析完成。":"Rapid analysis complete.",true);
 $("#downloadStaticAnalysis").disabled=false;$("#downloadHandoff").disabled=false;
}
function loadStaticDemo(){
 const profile={project_code:"STATIC-DEMO-01",company_name:"匿名静态站演示企业",company_size:"small",employee_count:68,industry:"machinery",production_type:"job_shop",line_name:"机加工与装配单元",region:"Demo",pain_points:["quality_defects","schedule_changeover","manual_records","collaboration"],current_systems:["paper","excel","plc"],automation_level:"local",pilot_scope:"三台关键设备与一个装配班组",profile_owner:"生产主管"};
 saveProfile(profile);renderSurvey(profile);
 const rows=[],questionHash=id=>[...id].reduce((sum,char)=>sum+char.charCodeAt(0),0);
 for(let i=0;i<60;i++){
   const respondent={respondent_code:`DEMO-${String(i+1).padStart(3,"0")}`,role:["operator","technician","process","team_lead"][i%4],department:`演示${i%3+1}组`,shift:["day","night","rotating","regular"][i%4],years_experience:2+i%12,tenure_current_position:1+i%8,education_level:"college",digital_exposure_years:1+i%6,digital_tool_frequency:"daily",participated_digital_project:i%3===0?"yes":"no",training_hours_12m:8+i%16,decision_involvement:i%4===0?"approve_local":"suggest"},answers={};
   const common=0.32*Math.sin((i+1)*1.31)+0.18*Math.cos((i+1)*0.57);
   const latent={
    P:2.78+common+0.34*Math.sin((i+1)*0.83),
    C:2.88+common*0.72+0.31*Math.cos((i+1)*0.71),
    I:2.58+common*0.65+0.36*Math.sin((i+1)*1.07),
    O:2.43+common*0.60+0.38*Math.cos((i+1)*0.93),
    H:2.72+common*0.55+0.33*Math.sin((i+1)*0.49)
   };
   for(const q of activeQuestions){
     if(q.type==="textarea"){answers[q.id]=q.id==="OPEN_01"?"换型等待、质量记录和跨班组交接影响效率。":"本回答为静态站合成演示，仅供参考。";continue}
     if(q.type==="multiselect"){answers[q.id]=questionOptions(q).slice(0,Math.min(3,q.max_items||3)).map(x=>x.code);continue}
     if(q.type==="ranking"){answers[q.id]=questionOptions(q).slice(0,q.rank_count).map(x=>x.code);continue}
     if(q.analysis_role==="attention"){answers[q.id]=4;continue}
     const itemNoise=0.48*Math.sin((i+1)*(questionHash(q.id)%13+3)*0.173)+0.16*Math.cos((questionHash(q.id)%19+1)*0.41);
     let desired=3+itemNoise;
     if(q.pcio_layer in latent)desired=latent[q.pcio_layer]+itemNoise;
     if(q.pcio_layer==="R"){
      const weights={
       PERF_QUALITY:[0.38,0.08,0.24,0.18,0.12],
       PERF_COST:[0.34,0.12,0.18,0.26,0.10],
       PERF_EFF:[0.42,0.14,0.14,0.20,0.10],
       PERF_FLEX:[0.40,0.11,0.20,0.17,0.12]
      }[q.id]||[0.2,0.2,0.2,0.2,0.2];
      desired=0.35+weights[0]*latent.P+weights[1]*latent.C+weights[2]*latent.I+weights[3]*latent.O+weights[4]*latent.H+itemNoise*0.75;
     }
     const scored=Math.max(1,Math.min(5,Math.round(desired)));
     answers[q.id]=q.reverse?6-scored:scored;
   }
   rows.push(makeRow(profile,respondent,answers));
 }
 setResponses(profile.project_code,rows);$("#analysisProjectCode").value=profile.project_code;$("#aggregateProjectCode").value=profile.project_code;refreshAggregate();renderStaticAnalysis();
}
function activatePanel(name,shouldScroll=true){
 const tab=$(`.tab[data-panel="${name}"]`);
 if(tab)tab.click();
 if(shouldScroll)$("#workspace")?.scrollIntoView({behavior:"smooth",block:"start"});
 $("#siteNav")?.classList.remove("open");
 $("#menuToggle")?.setAttribute("aria-expanded","false");
}
function setLoading(show,key="loadingAnalysis"){
 const overlay=$("#loadingOverlay");
 $("#loadingText").textContent=T[lang][key]||key;
 overlay.hidden=!show;
 document.body.style.overflow=show?"hidden":"";
}
function withLoading(task,key){
 setLoading(true,key);
 window.setTimeout(()=>{try{task()}finally{setLoading(false,key)}},60);
}
function surveyDraftKey(code){return `pcio:survey-draft:${normaliseCode(code)}`}
function captureSurveyDraft(){
 if(!activeProfile||$("#surveyForm").hidden)return null;
 const respondent=readForm($("#surveyForm"),SCHEMA.respondent_fields,"respondent"),answers={};
 for(const q of activeQuestions){
  if(q.type==="likert")answers[q.id]=$("#surveyForm").querySelector(`input[name="${q.id}"]:checked`)?.value||"";
  else if(q.type==="multiselect")answers[q.id]=[...$("#surveyForm").querySelectorAll(`input[name="${q.id}"]:checked`)].map(x=>x.value);
  else if(q.type==="ranking")answers[q.id]=[...$("#surveyForm").querySelectorAll(`select[name="${q.id}"]`)].map(x=>x.value);
  else answers[q.id]=$("#surveyForm").querySelector(`[name="${q.id}"]`)?.value||"";
 }
 return {respondent,answers,updated_at_utc:new Date().toISOString()};
}
function applySurveyDraft(draft){
 if(!draft)return;
 fillForm(SCHEMA.respondent_fields,draft.respondent||{},"respondent");
 for(const q of activeQuestions){
  const value=draft.answers?.[q.id];
  if(value===undefined)continue;
  if(q.type==="likert"){
   const input=[...$("#surveyForm").querySelectorAll(`input[name="${q.id}"]`)].find(x=>x.value===String(value));
   if(input)input.checked=true;
  }else if(q.type==="multiselect"){
   const selected=new Set(value||[]);
   $("#surveyForm").querySelectorAll(`input[name="${q.id}"]`).forEach(x=>x.checked=selected.has(x.value));
  }else if(q.type==="ranking"){
   $("#surveyForm").querySelectorAll(`select[name="${q.id}"]`).forEach((x,i)=>x.value=(value||[])[i]||"");
  }else{
   const input=$("#surveyForm").querySelector(`[name="${q.id}"]`);
   if(input)input.value=value||"";
  }
 }
}
function questionAnswered(q){
 if(q.type==="likert")return Boolean($("#surveyForm").querySelector(`input[name="${q.id}"]:checked`));
 if(q.type==="multiselect")return $("#surveyForm").querySelectorAll(`input[name="${q.id}"]:checked`).length>0;
 if(q.type==="ranking")return [...$("#surveyForm").querySelectorAll(`select[name="${q.id}"]`)].filter(x=>x.value).length===q.rank_count;
 return Boolean($("#surveyForm").querySelector(`[name="${q.id}"]`)?.value.trim());
}
function updateSurveyProgress(){
 const box=$("#surveyProgress");
 if(!box||!activeProfile||$("#surveyForm").hidden){if(box)box.hidden=true;return}
 const answered=activeQuestions.filter(questionAnswered).length,total=activeQuestions.length,pct=total?answered/total*100:0;
 box.hidden=false;
 $("#surveyProgressText").textContent=`${T[lang].surveyProgress}: ${answered} / ${total}`;
 $("#surveyDraftState").textContent=T[lang].draftSaved;
 $("#surveyProgressFill").style.width=`${pct.toFixed(1)}%`;
}
const baseRenderSurvey=renderSurvey;
renderSurvey=profile=>{
 baseRenderSurvey(profile);
 let saved=null;
 try{saved=JSON.parse(localStorage.getItem(surveyDraftKey(profile.project_code))||"null")}catch{}
 applySurveyDraft(saved);
 updateSurveyProgress();
};
$("#surveyForm").addEventListener("input",()=>{
 const draft=captureSurveyDraft();
 if(draft&&activeProfile)localStorage.setItem(surveyDraftKey(activeProfile.project_code),JSON.stringify(draft));
 updateSurveyProgress();
});
const baseSurveySubmit=$("#surveyForm").onsubmit;
$("#surveyForm").onsubmit=e=>{
 baseSurveySubmit(e);
 if($("#surveyStatus").classList.contains("ok")&&activeProfile){
  localStorage.removeItem(surveyDraftKey(activeProfile.project_code));
  updateSurveyProgress();
 }
};
$("#runStaticAnalysis").onclick=()=>withLoading(renderStaticAnalysis,"loadingAnalysis");
$("#loadStaticDemo").onclick=()=>withLoading(loadStaticDemo,"loadingDemo");
$("#downloadStaticAnalysis").onclick=()=>{if(staticAnalysis)download(`${staticAnalysis.project_code}_pcio_static_screening.json`,JSON.stringify(staticAnalysis,null,2),"application/json")};
$("#downloadHandoff").onclick=()=>{if(!staticAnalysis)return;const code=staticAnalysis.project_code,payload={readme_zh:"将 company_profile 与 responses CSV 上传到 Streamlit 的“分析与决策”步骤。静态筛选仅供参考。",readme_en:"Upload the company profile and response CSV to the Streamlit Analysis and Decisions step. Static screening is for reference only.",company_profile:staticAnalysis.profile,response_csv_filename:`${code}_pcio_responses.csv`,static_screening:staticAnalysis};download(`${code}_streamlit_handoff.json`,JSON.stringify(payload,null,2),"application/json")};
$("#profileForm").addEventListener("submit",()=>{setTimeout(()=>{if(activeProfile)$("#analysisProjectCode").value=activeProfile.project_code},0)});
$$(".tab").forEach(b=>b.addEventListener("click",()=>{if(b.dataset.panel==="analysis"&&!$("#analysisProjectCode").value)$("#analysisProjectCode").value=$("#aggregateProjectCode").value||activeProfile?.project_code||""}));
$$("[data-open-panel]").forEach(el=>el.addEventListener("click",()=>activatePanel(el.dataset.openPanel)));
$("#heroStart").onclick=()=>activatePanel("profile");
$("#heroDemo").onclick=()=>{activatePanel("analysis");withLoading(loadStaticDemo,"loadingDemo")};
$("#menuToggle").onclick=()=>{
 const open=$("#siteNav").classList.toggle("open");
 $("#menuToggle").setAttribute("aria-expanded",String(open));
};
const baseSetLang=setLang;
setLang=next=>{
 baseSetLang(next);
 $("#menuToggle").title=next==="zh"?"打开导航菜单":"Open navigation menu";
 $("#siteNav").setAttribute("aria-label",next==="zh"?"主导航":"Primary navigation");
 updateSurveyProgress();
 if(staticAnalysis)renderStaticAnalysis();
};
setLang(lang);
</script>
"""


def build_streamlit_download() -> None:
    """Build the public download bundle without local data or generated outputs."""

    roots = [
        ROOT / "app",
        ROOT / "scripts",
        ROOT / "templates",
        ROOT / "docs",
        ROOT / "examples" / "complete",
        ROOT / ".streamlit",
    ]
    files = [
        ROOT / "README.md",
        ROOT / "LICENSE",
        ROOT / "CITATION.cff",
        ROOT / "requirements.txt",
        ROOT / "Dockerfile",
        ROOT / "docker-compose.yml",
    ]
    DOWNLOAD_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = DOWNLOAD_PATH.with_suffix(".zip.tmp")
    with ZipFile(temporary_path, "w", ZIP_DEFLATED, compresslevel=9) as archive:
        archive.writestr(
            "PCIO-Toolkit-Streamlit-1.0.0/START-HERE-bilingual.txt",
            "PCIO Toolkit 1.0.0 Streamlit 完整版 / Full Streamlit Edition\n\n"
            "中文：安装 requirements.txt 后运行 streamlit run app/streamlit_app.py。"
            "真实企业数据应部署在本地或受控内网。\n"
            "English: install requirements.txt, then run "
            "streamlit run app/streamlit_app.py. Keep real company data on a "
            "local machine or controlled intranet.\n",
        )
        for root in roots:
            if not root.exists():
                continue
            for path in root.rglob("*"):
                if (
                    not path.is_file()
                    or "__pycache__" in path.parts
                    or path.suffix.lower() in {".pyc", ".pyo"}
                ):
                    continue
                relative = path.relative_to(ROOT)
                archive.write(
                    path,
                    Path("PCIO-Toolkit-Streamlit-1.0.0") / relative,
                )
        for path in files:
            if path.is_file():
                archive.write(
                    path,
                    Path("PCIO-Toolkit-Streamlit-1.0.0") / path.name,
                )
    temporary_path.replace(DOWNLOAD_PATH)


def main() -> None:
    html = SOURCE_PATH.read_text(encoding="utf-8")
    statistical_engine = STATISTICAL_ENGINE_PATH.read_text(encoding="utf-8")
    html = html.replace(
        '<meta name="viewport" content="width=device-width,initial-scale=1">',
        '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
        '  <meta name="description" content="PCIO 1.0.0 bilingual manufacturing maturity survey, statistical analysis, risk, KPI, ROI, and PDCA improvement toolkit.">\n'
        '  <meta name="theme-color" content="#14283b">\n'
        '  <meta name="color-scheme" content="light">\n'
        '  <meta property="og:type" content="website">\n'
        '  <meta property="og:title" content="PCIO Production Survey & Personalized Toolkit">\n'
        '  <meta property="og:description" content="A bilingual 305-item manufacturing maturity survey and browser-side decision toolkit.">\n'
        '  <link rel="icon" href="assets/pcio-mark.svg" type="image/svg+xml">\n'
        '  <link rel="manifest" href="site.webmanifest">',
    )
    html = html.replace(
        "<title>PCIO Toolkit Survey</title>",
        "<title>PCIO Production Survey & Personalized Toolkit 1.0.0</title>",
    )
    html = html.replace("    @media print{", EXTRA_STYLE + "\n    @media print{")
    original_open = (
        '<body>\n'
        '  <header class="top"><div class="top-inner"><div class="brand"><span>PCIO</span> Toolkit</div><div class="spacer"></div><div class="seg"><button id="langZh" class="active">中文</button><button id="langEn">English</button></div></div></header>\n'
        '  <main class="shell">\n'
        '    <section class="hero"><h1 data-t="title"></h1><p data-t="subtitle"></p></section>\n'
        '    <div class="notice" data-t="privacy"></div>\n'
    )
    html = html.replace(original_open, WEBSITE_OPEN)
    html = html.replace(
        '<button class="tab active" data-panel="profile"',
        '<button class="tab active" data-step="01" data-panel="profile"',
    )
    html = html.replace(
        '<button class="tab" data-panel="survey"',
        '<button class="tab" data-step="02" data-panel="survey"',
    )
    html = html.replace(
        '<button class="tab" data-panel="aggregate"',
        '<button class="tab" data-step="03" data-panel="aggregate"',
    )
    html = html.replace(
        '      <button class="tab" data-step="03" data-panel="aggregate" data-t="aggregateTab"></button>\n',
        '      <button class="tab" data-step="03" data-panel="aggregate" data-t="aggregateTab"></button>\n'
        + ANALYSIS_TAB,
    )
    html = html.replace(
        '<div id="dynamicNotice" class="notice" hidden></div><form id="surveyForm" hidden>',
        '<div id="dynamicNotice" class="notice" hidden></div>'
        '<div id="surveyProgress" class="survey-progress" hidden>'
        '<div class="survey-progress-head"><b id="surveyProgressText"></b>'
        '<small id="surveyDraftState"></small></div>'
        '<div class="survey-progress-track"><div id="surveyProgressFill" class="survey-progress-fill"></div></div>'
        '</div><form id="surveyForm" hidden>',
    )
    html = html.replace(
        "  </main>\n<script>",
        ANALYSIS_PANEL + "\n" + WEBSITE_FOOTER + "\n<script>",
    )
    html = html.replace(
        "</body>",
        f"<script>\n{statistical_engine}\n</script>\n{EXTRA_SCRIPT}\n</body>",
    )
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_text(html, encoding="utf-8")
    build_streamlit_download()
    print(OUTPUT_PATH)
    print(DOWNLOAD_PATH)


if __name__ == "__main__":
    main()


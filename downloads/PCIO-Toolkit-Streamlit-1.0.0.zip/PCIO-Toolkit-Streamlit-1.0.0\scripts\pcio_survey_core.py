"""Shared Phase 2 survey logic for PCIO Toolkit.

The module uses only the Python standard library so the schema, validation,
CSV persistence, and descriptive aggregation work in low-cost environments.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import time
import uuid
from collections import defaultdict
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SCHEMA_PATH = ROOT / "templates" / "pcio_survey_schema.json"
DEFAULT_DATA_DIR = ROOT / "data" / "projects"
LIKERT_VALUES = {1, 2, 3, 4, 5}


def load_schema(path: str | Path = DEFAULT_SCHEMA_PATH) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def normalise_project_code(value: str) -> str:
    code = re.sub(r"[^A-Za-z0-9_-]+", "-", value.strip()).strip("-_").upper()
    if not 3 <= len(code) <= 40:
        raise ValueError("project_code must contain 3-40 letters, numbers, '-' or '_'")
    return code


def project_directory(project_code: str, data_dir: str | Path = DEFAULT_DATA_DIR) -> Path:
    return Path(data_dir) / normalise_project_code(project_code)


def option_codes(schema: dict[str, Any], option_name: str) -> set[str]:
    return {item["code"] for item in schema["options"][option_name]}


def _is_blank(value: Any) -> bool:
    return value is None or value == "" or value == []


def validate_fields(
    values: dict[str, Any],
    fields: Iterable[dict[str, Any]],
    schema: dict[str, Any],
) -> list[str]:
    errors: list[str] = []
    for field in fields:
        field_id = field["id"]
        value = values.get(field_id)
        if field.get("required") and _is_blank(value):
            errors.append(f"{field_id}: required")
            continue
        if _is_blank(value):
            continue
        field_type = field["type"]
        if field_type == "integer":
            try:
                numeric = int(value)
            except (TypeError, ValueError):
                errors.append(f"{field_id}: must be an integer")
                continue
            if "min" in field and numeric < field["min"]:
                errors.append(f"{field_id}: below minimum {field['min']}")
            if "max" in field and numeric > field["max"]:
                errors.append(f"{field_id}: above maximum {field['max']}")
        elif field_type in {"select", "multiselect"}:
            allowed = option_codes(schema, field["options"])
            selected = value if isinstance(value, list) else [value]
            unknown = [item for item in selected if item not in allowed]
            if unknown:
                errors.append(f"{field_id}: unknown option(s) {unknown}")
            if field_type == "multiselect":
                if len(selected) < field.get("min_items", 0):
                    errors.append(f"{field_id}: too few selections")
                if "max_items" in field and len(selected) > field["max_items"]:
                    errors.append(f"{field_id}: too many selections")
    return errors


def validate_profile(profile: dict[str, Any], schema: dict[str, Any]) -> list[str]:
    errors = validate_fields(profile, schema["profile_fields"], schema)
    if profile.get("project_code"):
        try:
            normalise_project_code(str(profile["project_code"]))
        except ValueError as exc:
            errors.append(str(exc))
    return errors


def question_applies(question: dict[str, Any], profile: dict[str, Any]) -> bool:
    if question.get("kind") == "core" or not question.get("applicability"):
        return True
    rule = question["applicability"]
    checks: list[bool] = []
    if rule.get("industries"):
        checks.append(profile.get("industry") in rule["industries"])
    if rule.get("production_types"):
        checks.append(profile.get("production_type") in rule["production_types"])
    if rule.get("pain_points"):
        selected = set(profile.get("pain_points") or [])
        checks.append(bool(selected.intersection(rule["pain_points"])))
    if not checks:
        return True
    return all(checks) if rule.get("match") == "all" else any(checks)


def selected_questions(schema: dict[str, Any], profile: dict[str, Any]) -> list[dict[str, Any]]:
    return [question for question in schema["questions"] if question_applies(question, profile)]


def dynamic_question_ids(schema: dict[str, Any], profile: dict[str, Any]) -> list[str]:
    return [
        question["id"]
        for question in selected_questions(schema, profile)
        if question.get("kind") == "dynamic"
    ]


def validate_response(
    respondent: dict[str, Any],
    answers: dict[str, Any],
    profile: dict[str, Any],
    schema: dict[str, Any],
) -> list[str]:
    errors = validate_fields(respondent, schema["respondent_fields"], schema)
    for question in selected_questions(schema, profile):
        value = answers.get(question["id"])
        if question.get("required") and _is_blank(value):
            errors.append(f"{question['id']}: required")
            continue
        if _is_blank(value):
            continue
        question_type = question["type"]
        if question_type == "likert":
            if str(value).strip().upper() == "NA" and question.get("allow_na"):
                continue
            try:
                numeric = int(value)
            except (TypeError, ValueError):
                errors.append(f"{question['id']}: must be 1-5")
                continue
            if numeric not in LIKERT_VALUES:
                errors.append(f"{question['id']}: must be 1-5")
        elif question_type == "multiselect":
            selected = value if isinstance(value, list) else str(value).split("|")
            selected = [item for item in selected if item]
            allowed = option_codes(schema, question["options"])
            if any(item not in allowed for item in selected):
                errors.append(f"{question['id']}: contains unknown option(s)")
            if question.get("max_items") and len(selected) > question["max_items"]:
                errors.append(f"{question['id']}: too many selections")
        elif question_type == "ranking":
            selected = value if isinstance(value, list) else str(value).split(">")
            selected = [item for item in selected if item]
            allowed = option_codes(schema, question["options"])
            if any(item not in allowed for item in selected):
                errors.append(f"{question['id']}: contains unknown option(s)")
            if len(selected) != len(set(selected)):
                errors.append(f"{question['id']}: duplicate ranked option(s)")
            if question.get("rank_count") and len(selected) != question["rank_count"]:
                errors.append(f"{question['id']}: rank exactly {question['rank_count']} items")
    return errors


def generate_respondent_code(project_code: str) -> str:
    raw = f"{normalise_project_code(project_code)}:{uuid.uuid4().hex}"
    return "R-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:10].upper()


def response_columns(schema: dict[str, Any]) -> list[str]:
    system_metadata = [
        "schema_version",
        "submission_id",
        "submitted_at_utc",
        "dynamic_question_ids",
    ]
    columns = [
        *system_metadata,
        *(field["id"] for field in schema["profile_fields"]),
        *(field["id"] for field in schema["respondent_fields"]),
        *(question["id"] for question in schema["questions"]),
    ]
    return list(dict.fromkeys(columns))


def _serialise_cell(value: Any, separator: str = "|") -> Any:
    if isinstance(value, (list, tuple, set)):
        return separator.join(str(item) for item in value)
    return value


def flatten_response(
    profile: dict[str, Any],
    respondent: dict[str, Any],
    answers: dict[str, Any],
    schema: dict[str, Any],
) -> dict[str, Any]:
    project_code = normalise_project_code(str(profile["project_code"]))
    respondent_code = (respondent.get("respondent_code") or "").strip()
    if not respondent_code:
        respondent_code = generate_respondent_code(project_code)
    row: dict[str, Any] = {column: "" for column in response_columns(schema)}
    row.update(
        {
            "schema_version": schema["schema_version"],
            "submission_id": uuid.uuid4().hex,
            "submitted_at_utc": datetime.now(timezone.utc).isoformat(),
            "dynamic_question_ids": "|".join(dynamic_question_ids(schema, profile)),
        }
    )
    for field in schema["profile_fields"]:
        row[field["id"]] = _serialise_cell(profile.get(field["id"], ""))
    for field in schema["respondent_fields"]:
        row[field["id"]] = _serialise_cell(respondent.get(field["id"], ""))
    row["project_code"] = project_code
    row["respondent_code"] = respondent_code
    for question in selected_questions(schema, profile):
        separator = ">" if question["type"] == "ranking" else "|"
        row[question["id"]] = _serialise_cell(answers.get(question["id"], ""), separator)
    return row


@contextmanager
def _exclusive_lock(path: Path, timeout_seconds: float = 8.0):
    lock_path = path.with_suffix(path.suffix + ".lock")
    deadline = time.time() + timeout_seconds
    descriptor: int | None = None
    while descriptor is None:
        try:
            descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            if time.time() >= deadline:
                raise TimeoutError(f"Could not obtain lock for {path}")
            time.sleep(0.08)
    try:
        os.write(descriptor, str(os.getpid()).encode("ascii"))
        yield
    finally:
        os.close(descriptor)
        lock_path.unlink(missing_ok=True)


def save_profile(
    profile: dict[str, Any],
    schema: dict[str, Any],
    data_dir: str | Path = DEFAULT_DATA_DIR,
) -> Path:
    errors = validate_profile(profile, schema)
    if errors:
        raise ValueError("; ".join(errors))
    target_dir = project_directory(profile["project_code"], data_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / "company_profile.json"
    payload = dict(profile)
    payload["project_code"] = normalise_project_code(str(profile["project_code"]))
    payload["schema_version"] = schema["schema_version"]
    payload["updated_at_utc"] = datetime.now(timezone.utc).isoformat()
    temporary = target.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(target)
    return target


def load_profile(project_code: str, data_dir: str | Path = DEFAULT_DATA_DIR) -> dict[str, Any]:
    target = project_directory(project_code, data_dir) / "company_profile.json"
    if not target.exists():
        raise FileNotFoundError(f"Project profile not found: {normalise_project_code(project_code)}")
    return json.loads(target.read_text(encoding="utf-8"))


def append_response(
    row: dict[str, Any],
    schema: dict[str, Any],
    data_dir: str | Path = DEFAULT_DATA_DIR,
) -> Path:
    target_dir = project_directory(row["project_code"], data_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / "responses.csv"
    columns = response_columns(schema)
    with _exclusive_lock(target):
        exists = target.exists() and target.stat().st_size > 0
        with target.open("a", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
            if not exists:
                writer.writeheader()
            writer.writerow({column: row.get(column, "") for column in columns})
    return target


def read_responses(
    project_code: str,
    data_dir: str | Path = DEFAULT_DATA_DIR,
) -> list[dict[str, str]]:
    target = project_directory(project_code, data_dir) / "responses.csv"
    if not target.exists():
        return []
    with target.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _scored_value(question: dict[str, Any], raw: Any) -> float | None:
    if raw in (None, "") or question["type"] != "likert":
        return None
    try:
        value = int(float(raw))
    except (TypeError, ValueError):
        return None
    if value not in LIKERT_VALUES:
        return None
    return float(6 - value if question.get("reverse") else value)


def aggregate_responses(
    rows: list[dict[str, Any]],
    schema: dict[str, Any],
) -> dict[str, Any]:
    question_values: dict[str, list[float]] = defaultdict(list)
    layer_values: dict[str, list[float]] = defaultdict(list)
    question_lookup = {question["id"]: question for question in schema["questions"]}
    attention_total = 0
    attention_passed = 0
    for row in rows:
        for question_id, question in question_lookup.items():
            value = _scored_value(question, row.get(question_id))
            if value is None:
                continue
            if question.get("analysis_role") == "attention":
                attention_total += 1
                expected = float(question.get("attention_check", {}).get("expected", 4))
                if float(row.get(question_id)) == expected:
                    attention_passed += 1
                continue
            question_values[question_id].append(value)
            if question.get("analysis_role") in {"scale", "outcome"}:
                layer_values[question["pcio_layer"]].append(value)
    question_summary = []
    for question in schema["questions"]:
        values = question_values.get(question["id"], [])
        if values:
            question_summary.append(
                {
                    "question_id": question["id"],
                    "pcio_layer": question["pcio_layer"],
                    "dimension": question["dimension"],
                    "n": len(values),
                    "mean": round(mean(values), 4),
                    "zh": question["zh"],
                    "en": question["en"],
                }
            )
    layer_summary = [
        {"pcio_layer": layer, "n_item_responses": len(values), "mean": round(mean(values), 4)}
        for layer, values in sorted(layer_values.items())
        if values
    ]
    return {
        "response_count": len(rows),
        "response_quality": {
            "attention_checks_answered": attention_total,
            "attention_checks_passed": attention_passed,
            "attention_pass_rate": (
                round(attention_passed / attention_total, 4) if attention_total else None
            ),
        },
        "layer_summary": layer_summary,
        "question_summary": question_summary,
        "note_zh": "反向题已换算为高分代表更成熟。此处仅为描述性聚合，正式信效度和推断统计在 Phase 3 完成。",
        "note_en": "Reverse items are rescored so higher values indicate greater maturity. This is descriptive aggregation only; formal reliability, validity, and inferential statistics are provided in Phase 3.",
    }


def rows_to_csv_bytes(rows: list[dict[str, Any]], schema: dict[str, Any]) -> bytes:
    from io import StringIO

    buffer = StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=response_columns(schema), extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow({column: row.get(column, "") for column in response_columns(schema)})
    return ("\ufeff" + buffer.getvalue()).encode("utf-8")

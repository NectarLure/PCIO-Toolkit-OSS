﻿import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = path.resolve(nodeRepl.cwd);
const schema = JSON.parse(
  await fs.readFile(path.join(root, "templates", "pcio_survey_schema.json"), "utf8"),
);
const templatePath = path.join(
  root,
  "templates",
  "PCIO-Company-Profile-and-Technician-Survey.xlsx",
);
const outputDir = path.join(root, "outputs", "phase2");
const outputPath = path.join(
  outputDir,
  "PCIO-Company-Profile-and-Technician-Survey.xlsx",
);
await fs.mkdir(outputDir, { recursive: true });

const wb = Workbook.create();
const start = wb.worksheets.add("START");
const profile = wb.worksheets.add("Company_Profile");
const survey = wb.worksheets.add("Printable_Survey");
const responses = wb.worksheets.add("Response_Data");
const codebook = wb.worksheets.add("Codebook");
const lists = wb.worksheets.add("Lists");

const colors = {
  ink: "#17212B",
  teal: "#0B6B66",
  tealSoft: "#DFF3EF",
  blueSoft: "#E7F0F8",
  gold: "#9A6A00",
  goldSoft: "#FFF2CC",
  redSoft: "#FDE8E8",
  grey: "#5D6975",
  line: "#D8DEE7",
  soft: "#F4F7F9",
  white: "#FFFFFF",
};

function colName(index) {
  let n = index + 1;
  let result = "";
  while (n > 0) {
    const mod = (n - 1) % 26;
    result = String.fromCharCode(65 + mod) + result;
    n = Math.floor((n - 1) / 26);
  }
  return result;
}

function styleTitle(sheet, range, title, subtitle) {
  sheet.getRange(range).merge();
  const titleCell = sheet.getRange(range.split(":")[0]);
  titleCell.values = [[title]];
  titleCell.format = {
    fill: colors.ink,
    font: { bold: true, color: colors.white, size: 20 },
    verticalAlignment: "center",
    horizontalAlignment: "left",
  };
  titleCell.format.rowHeight = 34;
  const startCell = range.split(":")[0];
  const row = Number(startCell.match(/\d+/)[0]) + 1;
  const endCol = range.split(":")[1].match(/[A-Z]+/)[0];
  sheet.getRange(`A${row}:${endCol}${row}`).merge();
  const subtitleCell = sheet.getRange(`A${row}`);
  subtitleCell.values = [[subtitle]];
  subtitleCell.format = {
    fill: colors.ink,
    font: { color: "#DDE6EC", size: 10 },
    verticalAlignment: "center",
  };
  subtitleCell.format.rowHeight = 24;
}

function styleHeader(range, fill = colors.teal) {
  range.format = {
    fill,
    font: { bold: true, color: colors.white, size: 10 },
    wrapText: true,
    verticalAlignment: "center",
    horizontalAlignment: "center",
    borders: { preset: "all", style: "thin", color: colors.line },
  };
}

function styleBody(range) {
  range.format = {
    font: { color: colors.ink, size: 10 },
    verticalAlignment: "top",
    borders: { preset: "all", style: "thin", color: colors.line },
  };
}

function optionLabel(optionName) {
  return schema.options[optionName]
    .map((item) => `${item.code} = ${item.zh} / ${item.en}`)
    .join("\n");
}

function activeFormula(question) {
  if (question.kind === "core" || !question.applicability) return '="YES"';
  const rule = question.applicability;
  const checks = [];
  if (rule.industries) {
    checks.push(
      ...rule.industries.map((value) => `'Company_Profile'!$D$9="${value}"`),
    );
  }
  if (rule.production_types) {
    checks.push(
      ...rule.production_types.map(
        (value) => `'Company_Profile'!$D$10="${value}"`,
      ),
    );
  }
  if (rule.pain_points) {
    checks.push(
      ...rule.pain_points.map(
        (value) =>
          `ISNUMBER(SEARCH("|${value}|","|"&'Company_Profile'!$D$13&"|"))`,
      ),
    );
  }
  const fn = rule.match === "all" ? "AND" : "OR";
  return `=IF(${fn}(${checks.join(",")}),"YES","NO")`;
}

// START
start.showGridLines = false;
styleTitle(
  start,
  "A1:H1",
  "PCIO Toolkit · Phase 2",
  "公司画像与生产技术人员问卷 / Company Profile and Production Technician Survey",
);
start.getRange("A4:H4").merge();
start.getRange("A4").values = [
  [
    "使用顺序 / Workflow: 1) Company_Profile 录入公司画像 → 2) Printable_Survey 打印或填写 → 3) Response_Data 汇总多人数据 → 4) Phase 3 运行正式统计。",
  ],
];
start.getRange("A4").format = {
  fill: colors.tealSoft,
  font: { bold: true, color: "#064A47", size: 11 },
  wrapText: true,
  verticalAlignment: "center",
};
start.getRange("A4").format.rowHeight = 42;

const summary = [
  ["Schema version", schema.schema_version, "Total instrument items", schema.instrument_design.total_instrument_items],
  ["Estimated time", `${schema.estimated_minutes} min`, "Survey questions", schema.questions.length],
  ["Basic-information fields", schema.profile_fields.length + schema.respondent_fields.length, "Response capacity", "200 rows"],
];
start.getRange("A6:D8").values = summary;
start.getRange("A6:D8").format = {
  borders: { preset: "all", style: "thin", color: colors.line },
  verticalAlignment: "center",
};
start.getRange("A6:A8").format = { fill: colors.soft, font: { bold: true } };
start.getRange("C6:C8").format = { fill: colors.soft, font: { bold: true } };
start.getRange("B6:B8").format = { fill: colors.white, font: { bold: true, color: colors.teal, size: 14 } };
start.getRange("D6:D8").format = { fill: colors.white, font: { bold: true, color: colors.teal, size: 14 } };

start.getRange("A10:H10").merge();
start.getRange("A10").values = [["填写规则 / Response Rules"]];
start.getRange("A10").format = {
  fill: colors.teal,
  font: { bold: true, color: colors.white, size: 12 },
};
const instructions = [
  ["1", "项目负责人", "先填写 Company_Profile。痛点和当前系统使用代码，并以 | 分隔。", "Complete Company_Profile first. Enter pain-point and system codes separated by |."],
  ["2", "生产技术人员", "按最近 6-12 个月的日常实际情况作答，不按理想状态作答。", "Answer from actual work during the past 6-12 months, not the ideal future state."],
  ["3", "量表", "1=非常不同意/几乎做不到；5=非常同意/稳定做到；空白=不适用。", "1=strongly disagree/almost never; 5=strongly agree/consistently; blank=not applicable."],
  ["4", "隐私", "不填写姓名、手机号、密码、配方或其他敏感信息。", "Do not enter names, phone numbers, passwords, formulas, or other sensitive data."],
  ["5", "多人数据", "每名填写者在 Response_Data 使用一行；不要修改题目列名。", "Use one Response_Data row per participant; do not change question column names."],
  ["6", "统计边界", "本工作簿仅收集与整理数据；正式信效度和推断统计在 Phase 3 完成。", "This workbook collects and organises data; formal statistics are provided in Phase 3."],
];
styleHeader(start.getRange("A11:D11"), colors.ink);
start.getRange("A11:D11").values = [["步骤", "角色", "中文说明", "English guidance"]];
start.getRange(`A12:D${11 + instructions.length}`).values = instructions;
styleBody(start.getRange(`A12:D${11 + instructions.length}`));
start.getRange(`C12:D${11 + instructions.length}`).format.wrapText = true;
start.getRange("A18:H18").merge();
start.getRange("A18").values = [[schema.privacy_notice.zh + "\n" + schema.privacy_notice.en]];
start.getRange("A18").format = {
  fill: colors.goldSoft,
  font: { color: "#594200", bold: true },
  wrapText: true,
  borders: { preset: "outside", style: "thin", color: colors.gold },
};
start.getRange("A18").format.rowHeight = 52;
start.getRange("A1:H20").format.font.name = "Microsoft YaHei";
start.getRange("A:A").format.columnWidth = 18;
start.getRange("B:B").format.columnWidth = 20;
start.getRange("C:C").format.columnWidth = 42;
start.getRange("D:D").format.columnWidth = 42;
start.getRange("E:H").format.columnWidth = 14;
start.freezePanes.freezeRows(4);

// Lists
lists.showGridLines = false;
styleTitle(lists, "A1:I1", "Validation Lists / 选项代码", "Use stable codes in data sheets; display text is bilingual.");
let listCol = 0;
const validationRanges = {};
for (const [name, items] of Object.entries(schema.options)) {
  const startCol = listCol;
  const endCol = listCol + 2;
  const block = [[name, "中文", "English"], ...items.map((item) => [item.code, item.zh, item.en])];
  const range = `${colName(startCol)}4:${colName(endCol)}${3 + block.length}`;
  lists.getRange(range).values = block;
  styleHeader(lists.getRange(`${colName(startCol)}4:${colName(endCol)}4`), colors.ink);
  styleBody(lists.getRange(`${colName(startCol)}5:${colName(endCol)}${3 + block.length}`));
  validationRanges[name] = `Lists!$${colName(startCol)}$5:$${colName(startCol)}$${3 + block.length}`;
  lists.getRange(`${colName(startCol)}:${colName(startCol)}`).format.columnWidth = 24;
  lists.getRange(`${colName(startCol + 1)}:${colName(startCol + 2)}`).format.columnWidth = 30;
  listCol += 4;
}
lists.freezePanes.freezeRows(4);

// Company profile
profile.showGridLines = false;
styleTitle(
  profile,
  "A1:E1",
  "公司画像 / Company Profile",
  "黄色单元格为填写区。多选字段使用代码并以 | 分隔，例如 equipment_downtime|energy_cost。",
);
profile.getRange("A4:E4").values = [["Field ID", "中文字段", "English field", "Input / 填写", "Guidance / 说明"]];
styleHeader(profile.getRange("A4:E4"));
const profileRows = schema.profile_fields.map((field) => [
  field.id,
  field.zh + (field.required ? " *" : ""),
  field.en + (field.required ? " *" : ""),
  "",
  field.options ? optionLabel(field.options) : (field.help_zh || "") + (field.help_en ? `\n${field.help_en}` : ""),
]);
profile.getRange(`A5:E${4 + profileRows.length}`).values = profileRows;
styleBody(profile.getRange(`A5:E${4 + profileRows.length}`));
profile.getRange(`D5:D${4 + profileRows.length}`).format = {
  fill: colors.goldSoft,
  borders: { preset: "all", style: "thin", color: colors.gold },
};
profile.getRange(`B5:C${4 + profileRows.length}`).format.wrapText = true;
profile.getRange(`E5:E${4 + profileRows.length}`).format = {
  fill: colors.soft,
  font: { color: colors.grey, size: 9 },
  wrapText: true,
  borders: { preset: "all", style: "thin", color: colors.line },
};
schema.profile_fields.forEach((field, index) => {
  const row = 5 + index;
  if (field.type === "select") {
    profile.getRange(`D${row}`).dataValidation = {
      rule: { type: "list", formula1: validationRanges[field.options] },
    };
  }
  if (field.type === "integer") {
    profile.getRange(`D${row}`).dataValidation = {
      rule: {
        type: "whole",
        operator: "between",
        formula1: field.min ?? 0,
        formula2: field.max ?? 1000000,
      },
    };
  }
});
profile.getRange("A:A").format.columnWidth = 26;
profile.getRange("B:B").format.columnWidth = 34;
profile.getRange("C:C").format.columnWidth = 38;
profile.getRange("D:D").format.columnWidth = 34;
profile.getRange("E:E").format.columnWidth = 55;
profile.getRange(`A5:E${4 + profileRows.length}`).format.rowHeight = 42;
schema.profile_fields.forEach((field, index) => {
  const row = 5 + index;
  if (field.options) profile.getRange(`A${row}:E${row}`).format.rowHeight = 82;
  if (field.id === "pain_points" || field.id === "current_systems") {
    profile.getRange(`A${row}:E${row}`).format.rowHeight = 132;
  }
});
profile.freezePanes.freezeRows(4);

// Printable survey
survey.showGridLines = false;
styleTitle(
  survey,
  "A1:L1",
  "生产技术人员成熟度问卷 / Production-Technician Maturity Survey",
  "完整问卷280题，预计40-50分钟。Likert题回答1-5；仅标注允许时可填NA。",
);
survey.getRange("A4:L4").values = [[
  "Active?",
  "No.",
  "Section",
  "Layer",
  "Dimension",
  "Question ID",
  "中文题目",
  "English question",
  "Response",
  "Response format",
  "Option codes / 选项代码",
  "Comment / 备注",
]];
styleHeader(survey.getRange("A4:L4"));
const questionRows = schema.questions.map((question, index) => [
  null,
  index + 1,
  question.section || question.pcio_layer,
  question.pcio_layer,
  question.dimension,
  question.id,
  question.zh,
  question.en,
  "",
  question.type === "likert"
    ? `Likert 1-5${question.allow_na ? " / NA allowed" : ""}`
    : question.type === "multiselect"
      ? `Multi-select, max ${question.max_items}`
      : question.type === "ranking"
        ? `Rank exactly ${question.rank_count}`
        : "Open text",
  question.options ? optionLabel(question.options) : "",
  "",
]);
survey.getRange(`A5:L${4 + questionRows.length}`).values = questionRows;
survey.getRange(`A5:A${4 + questionRows.length}`).formulas = schema.questions.map((question) => [
  activeFormula(question),
]);
styleBody(survey.getRange(`A5:L${4 + questionRows.length}`));
survey.getRange(`G5:L${4 + questionRows.length}`).format.wrapText = true;
survey.getRange(`I5:I${4 + questionRows.length}`).format = {
  fill: colors.goldSoft,
  borders: { preset: "all", style: "thin", color: colors.line },
  verticalAlignment: "top",
};
schema.questions.forEach((question, index) => {
  const row = index + 5;
  if (question.type === "likert") {
    survey.getRange(`I${row}`).dataValidation = question.allow_na
      ? { rule: { type: "list", values: [1, 2, 3, 4, 5, "NA"] } }
      : { rule: { type: "whole", operator: "between", formula1: 1, formula2: 5 } };
  }
});
survey.getRange(`A5:A${4 + questionRows.length}`).conditionalFormats.addCustom(
  '=A5="YES"',
  { fill: colors.tealSoft, font: { bold: true, color: "#064A47" } },
);
survey.getRange(`A5:L${4 + questionRows.length}`).conditionalFormats.addCustom(
  '=$A5="NO"',
  { fill: "#ECEFF2", font: { color: "#88939D" } },
);
survey.tables.add(
  `A4:L${4 + questionRows.length}`,
  true,
  "PrintableSurveyTable",
).style = "TableStyleMedium2";
survey.getRange("A:A").format.columnWidth = 11;
survey.getRange("B:B").format.columnWidth = 7;
survey.getRange("C:C").format.columnWidth = 9;
survey.getRange("D:D").format.columnWidth = 9;
survey.getRange("E:E").format.columnWidth = 23;
survey.getRange("F:F").format.columnWidth = 18;
survey.getRange("G:G").format.columnWidth = 48;
survey.getRange("H:H").format.columnWidth = 52;
survey.getRange("I:I").format.columnWidth = 18;
survey.getRange("J:J").format.columnWidth = 24;
survey.getRange("K:K").format.columnWidth = 46;
survey.getRange("L:L").format.columnWidth = 28;
survey.getRange(`A5:L${4 + questionRows.length}`).format.rowHeight = 52;
survey.freezePanes.freezeRows(4);

// Response Data
responses.showGridLines = false;
const metadataHeaders = [...new Set([
  "schema_version",
  "submission_id",
  "submitted_at_utc",
  "dynamic_question_ids",
  ...schema.profile_fields.map((field) => field.id),
  ...schema.respondent_fields.map((field) => field.id),
])];
const responseHeaders = [...metadataHeaders, ...schema.questions.map((question) => question.id)];
const lastResponseCol = colName(responseHeaders.length - 1);
styleTitle(
  responses,
  "A1:Q1",
  "多人响应数据 / Multi-Respondent Data",
  "每名填写者使用一行。不要修改列名。空白表示题目不适用或未回答。",
);
responses.getRange(`A4:${lastResponseCol}4`).values = [responseHeaders];
styleHeader(responses.getRange(`A4:${lastResponseCol}4`), colors.ink);
const blankRows = Array.from({ length: 200 }, () => responseHeaders.map(() => ""));
responses.getRange(`A5:${lastResponseCol}204`).values = blankRows;
styleBody(responses.getRange(`A5:${lastResponseCol}204`));
responses.tables.add(
  `A4:${lastResponseCol}204`,
  true,
  "PCIOResponseData",
).style = "TableStyleMedium2";
for (const field of [...schema.profile_fields, ...schema.respondent_fields]) {
  const index = responseHeaders.indexOf(field.id);
  if (index < 0) continue;
  const range = responses.getRange(`${colName(index)}5:${colName(index)}204`);
  if (field.type === "select") {
    range.dataValidation = {
      rule: { type: "list", formula1: validationRanges[field.options] },
    };
  } else if (field.type === "integer") {
    range.dataValidation = {
      rule: {
        type: "whole",
        operator: "between",
        formula1: field.min ?? 0,
        formula2: field.max ?? 1000000,
      },
    };
  }
}
schema.questions.forEach((question) => {
  if (question.type !== "likert") return;
  const index = responseHeaders.indexOf(question.id);
  const range = responses.getRange(`${colName(index)}5:${colName(index)}204`);
  range.dataValidation = question.allow_na
    ? { rule: { type: "list", values: [1, 2, 3, 4, 5, "NA"] } }
    : { rule: { type: "whole", operator: "between", formula1: 1, formula2: 5 } };
});
for (let i = 0; i < responseHeaders.length; i += 1) {
  responses.getRange(`${colName(i)}:${colName(i)}`).format.columnWidth =
    i < metadataHeaders.length ? 18 : 13;
}
responses.getRange(`A4:${lastResponseCol}4`).format.rowHeight = 52;
responses.freezePanes.freezeRows(4);
responses.freezePanes.freezeColumns(4);

// Codebook
codebook.showGridLines = false;
styleTitle(
  codebook,
  "A1:Q1",
  "Question Codebook / 问卷代码本",
  "Stable IDs are shared by Excel, HTML, Streamlit, CSV, and Phase 3 analytics.",
);
const codebookHeaders = [
  "Question ID",
  "PCIO Layer",
  "Dimension",
  "Kind",
  "Type",
  "Required",
  "Reverse",
  "Analysis role",
  "Scenario",
  "Attention expected",
  "Validity anchor",
  "中文题目",
  "English question",
  "Options",
  "Allow NA",
  "Rank count",
  "Max selections",
];
codebook.getRange("A4:Q4").values = [codebookHeaders];
styleHeader(codebook.getRange("A4:Q4"));
const codebookRows = schema.questions.map((question) => [
  question.id,
  question.pcio_layer,
  question.dimension,
  question.kind,
  question.type,
  question.required ? "Y" : "N",
  question.reverse ? "Y" : "N",
  question.analysis_role,
  question.kind === "scenario" ? "Y" : "N",
  question.attention_check?.expected ?? "",
  question.validity_anchor ? "Y" : "N",
  question.zh,
  question.en,
  question.options ? optionLabel(question.options) : "",
  question.allow_na ? "Y" : "N",
  question.rank_count ?? "",
  question.max_items ?? "",
]);
codebook.getRange(`A5:Q${4 + codebookRows.length}`).values = codebookRows;
styleBody(codebook.getRange(`A5:Q${4 + codebookRows.length}`));
codebook.getRange(`L5:N${4 + codebookRows.length}`).format.wrapText = true;
codebook.tables.add(
  `A4:Q${4 + codebookRows.length}`,
  true,
  "QuestionCodebook",
).style = "TableStyleMedium2";
["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"].forEach((col, i) => {
  codebook.getRange(`${col}:${col}`).format.columnWidth = [18, 10, 24, 12, 12, 10, 9, 16, 10, 14, 14][i];
});
codebook.getRange("L:L").format.columnWidth = 50;
codebook.getRange("M:M").format.columnWidth = 55;
codebook.getRange("N:N").format.columnWidth = 48;
codebook.getRange("O:Q").format.columnWidth = 15;
codebook.getRange(`A5:Q${4 + codebookRows.length}`).format.rowHeight = 52;
codebook.freezePanes.freezeRows(4);

const inspect = await wb.inspect({
  kind: "sheet,table",
  include: "id,name",
  maxChars: 5000,
});
await fs.writeFile(
  path.join(outputDir, "excel-inspect.ndjson"),
  inspect.ndjson,
  "utf8",
);
const errorScan = await wb.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 },
  summary: "Phase 2 workbook formula error scan",
});
await fs.writeFile(
  path.join(outputDir, "excel-error-scan.ndjson"),
  errorScan.ndjson,
  "utf8",
);

for (const [sheetName, range, fileName] of [
  ["START", "A1:H18", "preview-start.png"],
  ["Company_Profile", `A1:E${4 + profileRows.length}`, "preview-profile.png"],
  ["Printable_Survey", "A1:L24", "preview-survey.png"],
  ["Response_Data", "A1:Q12", "preview-response-data.png"],
  ["Codebook", "A1:Q18", "preview-codebook.png"],
  ["Lists", "A1:I16", "preview-lists.png"],
]) {
  const preview = await wb.render({ sheetName, range, scale: 1.2, format: "png" });
  await fs.writeFile(
    path.join(outputDir, fileName),
    new Uint8Array(await preview.arrayBuffer()),
  );
}

const xlsx = await SpreadsheetFile.exportXlsx(wb);
await xlsx.save(templatePath);
await xlsx.save(outputPath);

nodeRepl.write(
  JSON.stringify({
    templatePath,
    outputPath,
    sheets: ["START", "Company_Profile", "Printable_Survey", "Response_Data", "Codebook", "Lists"],
    questions: schema.questions.length,
    responseColumns: responseHeaders.length,
  }),
);


﻿"""Generate complete chemical-process and discrete-manufacturing examples."""

from __future__ import annotations

import csv
import json
import sys
import zipfile
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.pcio_analysis import (
    analyze_pcio_survey,
    analysis_excel_bytes,
    write_analysis_package,
)
from scripts.pcio_decision_support import (
    complete_package_zip_bytes,
    generate_decision_support,
    write_decision_support_package,
)
from scripts.pcio_report import generate_bilingual_report
from scripts.pcio_survey_core import (
    flatten_response,
    load_schema,
    response_columns,
    selected_questions,
)


EXAMPLE_ROOT = ROOT / "examples" / "complete"

SPECS = [
    {
        "slug": "chemical-process",
        "profile": ROOT / "examples" / "phase2" / "chemical-process-company-profile.json",
        "n": 60,
        "seed": 20260610,
        "means": [2.85, 3.20, 2.75, 2.65, 3.15],
        "roi": {
            "currency": "CNY",
            "investment": 300000,
            "annual_addressable_value": 2400000,
            "annual_operating_cost": 45000,
            "improvement_low_pct": 7.6,
            "improvement_high_pct": 11.2,
            "horizon_years": 3,
        },
    },
    {
        "slug": "discrete-manufacturing",
        "profile": ROOT
        / "examples"
        / "phase2"
        / "discrete-manufacturing-company-profile.json",
        "n": 64,
        "seed": 20260611,
        "means": [2.70, 2.82, 2.55, 2.48, 2.78],
        "roi": {
            "currency": "CNY",
            "investment": 180000,
            "annual_addressable_value": 1500000,
            "annual_operating_cost": 30000,
            "improvement_low_pct": 5.0,
            "improvement_high_pct": 10.0,
            "horizon_years": 3,
        },
    },
]


def _likert(value: float) -> int:
    return int(np.clip(np.rint(value), 1, 5))


def generate_rows(
    profile: dict[str, Any],
    n: int,
    seed: int,
    means: list[float],
) -> list[dict[str, object]]:
    schema = load_schema()
    rng = np.random.default_rng(seed)
    covariance = np.array(
        [
            [1.00, 0.24, 0.20, 0.16, 0.12],
            [0.24, 1.00, 0.30, 0.22, 0.14],
            [0.20, 0.30, 1.00, 0.31, 0.18],
            [0.16, 0.22, 0.31, 1.00, 0.20],
            [0.12, 0.14, 0.18, 0.20, 1.00],
        ]
    )
    factors = rng.multivariate_normal(np.zeros(5), covariance, size=n)
    latent = np.asarray(means) + factors * np.array([0.55, 0.48, 0.50, 0.53, 0.46])
    layers = ["P", "C", "I", "O", "H"]
    active_questions = selected_questions(schema, profile)
    roles = ["operator", "technician", "process", "team_lead", "automation"]
    shifts = ["day", "night", "rotating", "regular"]
    rows: list[dict[str, object]] = []
    for index in range(n):
        layer_value = dict(zip(layers, latent[index]))
        respondent = {
            "respondent_code": f"SYN-{index + 1:03d}",
            "role": roles[index % len(roles)],
            "department": f"生产{index % 4 + 1}组",
            "shift": shifts[index % len(shifts)],
            "years_experience": int(1 + index % 20),
            "tenure_current_position": int(1 + index % 10),
            "education_level": "college",
            "digital_exposure_years": int(1 + index % 8),
            "digital_tool_frequency": "daily",
            "participated_digital_project": "yes" if index % 3 == 0 else "no",
            "training_hours_12m": int(6 + index % 24),
            "decision_involvement": "approve_local" if index % 5 == 0 else "suggest",
        }
        answers: dict[str, object] = {}
        for question in active_questions:
            if question["type"] == "textarea":
                answers[question["id"]] = {
                    "OPEN_01": "设备、质量、节拍和跨班组信息影响当前稳定运行。",
                    "OPEN_02": "先补齐关键测点、统一记录口径并减少重复录入。",
                    "OPEN_03": "本记录为 PCIO Toolkit 合成示例，仅供参考。",
                }[question["id"]]
                continue
            if question["type"] == "multiselect":
                answers[question["id"]] = [
                    item["code"]
                    for item in schema["options"][question["options"]][
                        : min(3, question.get("max_items", 3))
                    ]
                ]
                continue
            if question["type"] == "ranking":
                answers[question["id"]] = [
                    item["code"]
                    for item in schema["options"][question["options"]][
                        : question["rank_count"]
                    ]
                ]
                continue
            if question.get("analysis_role") == "attention":
                answers[question["id"]] = 4
                continue
            if question["pcio_layer"] in layer_value:
                desired = layer_value[question["pcio_layer"]] + rng.normal(0, 0.48)
            elif question["pcio_layer"] == "R":
                p, c, i_score, o, h = (layer_value[layer] for layer in layers)
                weights = {
                    "PERF_QUALITY": (0.38, 0.08, 0.24, 0.18, 0.12),
                    "PERF_COST": (0.34, 0.12, 0.18, 0.26, 0.10),
                    "PERF_EFF": (0.42, 0.14, 0.14, 0.20, 0.10),
                    "PERF_FLEX": (0.40, 0.11, 0.20, 0.17, 0.12),
                }[question["id"]]
                desired = (
                    weights[0] * p
                    + weights[1] * c
                    + weights[2] * i_score
                    + weights[3] * o
                    + weights[4] * h
                    + 0.35
                    + rng.normal(0, 0.34)
                )
            else:
                desired = 3.0 + rng.normal(0, 0.5)
            scored = _likert(desired)
            answers[question["id"]] = 6 - scored if question.get("reverse") else scored
        rows.append(flatten_response(profile, respondent, answers, schema))
    return rows


def _relative(path: Path) -> str:
    return path.resolve().relative_to(ROOT).as_posix()


def build_example(spec: dict[str, Any]) -> dict[str, Any]:
    schema = load_schema()
    profile = json.loads(Path(spec["profile"]).read_text(encoding="utf-8"))
    rows = generate_rows(profile, spec["n"], spec["seed"], spec["means"])
    frame = pd.DataFrame(rows)
    example_dir = EXAMPLE_ROOT / spec["slug"]
    output_dir = example_dir / "output"
    example_dir.mkdir(parents=True, exist_ok=True)
    profile_path = example_dir / "company_profile.json"
    response_path = example_dir / "synthetic_technician_responses.csv"
    profile_path.write_text(
        json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with response_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=response_columns(schema))
        writer.writeheader()
        writer.writerows(rows)

    analysis = analyze_pcio_survey(profile, frame, schema)
    report = generate_bilingual_report(profile, analysis, schema)
    decision = generate_decision_support(profile, analysis, spec["roi"], schema)
    analysis_paths = write_analysis_package(analysis, output_dir)
    report_path = output_dir / "PCIO-Implementation-Case-Report-bilingual.md"
    report_path.write_text(report, encoding="utf-8")
    decision_paths = write_decision_support_package(decision, output_dir)
    analysis_zip = example_dir / "PCIO-Complete-Analysis-Package.zip"
    analysis_zip.write_bytes(
        complete_package_zip_bytes(
            profile,
            analysis,
            report,
            decision,
            analysis_excel_bytes(analysis),
        )
    )

    example_zip = example_dir / "PCIO-Complete-Example-Package.zip"
    with zipfile.ZipFile(example_zip, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.write(profile_path, "company_profile.json")
        archive.write(response_path, "synthetic_technician_responses.csv")
        archive.write(analysis_zip, "PCIO-Complete-Analysis-Package.zip")
        for path in output_dir.rglob("*"):
            if path.is_file():
                archive.write(path, f"output/{path.relative_to(output_dir).as_posix()}")

    score_map = {
        row["variable"]: row["mean"]
        for row in analysis["tables"]["scale_descriptives"]
        if row["variable"] in {"P", "C", "I", "O", "H", "PERF_OVERALL"}
    }
    manifest = {
        "example": spec["slug"],
        "toolkit_version": "1.3.0",
        "survey_schema_version": schema["schema_version"],
        "total_instrument_items": schema["instrument_design"]["total_instrument_items"],
        "improvement_workflow_included": True,
        "reference_only_zh": "全部公司、人员和收益数据均为匿名或合成数据，仅供参考。",
        "reference_only_en": "All company, respondent, and benefit data are anonymised or synthetic and for reference only.",
        "profile": _relative(profile_path),
        "responses": _relative(response_path),
        "analysis": {key: _relative(value) for key, value in analysis_paths.items()},
        "report": _relative(report_path),
        "decision_support": {
            key: _relative(value) for key, value in decision_paths.items()
        },
        "analysis_zip": _relative(analysis_zip),
        "example_zip": _relative(example_zip),
        "valid_responses": analysis["data_quality"]["retained_rows"],
        "scores": score_map,
        "selected_risks": len(decision["risk"]["risks"]),
        "recommended_kpis": len(decision["kpis"]),
        "payback_range_months": decision["roi"]["payback_range_months"],
    }
    manifest_path = example_dir / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    readme = (
        f"# {profile['company_name']} / {spec['slug']}\n\n"
        "本示例匹配 305 项专业问卷，包含公司画像、280 道合成技术人员答卷、"
        "SPSS 风格统计结果、双语案例报告、风险矩阵、KPI、三情景 ROI、"
        "企业改善操作流程、3/6 个月复测计划和完整 ZIP。\n\n"
        "**全部数据和改善结果仅供参考，不构成安全结论、预算报价或收益承诺。**\n\n"
        "This example matches the 305-item professional instrument and contains the "
        "company profile, 280 synthetic technician questions, SPSS-style outputs, "
        "bilingual report, risk matrix, KPIs, three-scenario ROI, enterprise "
        "improvement workflow, month-3/month-6 retest plan, and complete ZIP.\n\n"
        "**All data and improvement results are for reference only and are not safety "
        "conclusions, price quotes, or benefit guarantees.**\n"
    )
    (example_dir / "README.md").write_text(readme, encoding="utf-8")
    return manifest


def main() -> int:
    manifests = [build_example(spec) for spec in SPECS]
    index = {
        "toolkit_version": "1.3.0",
        "survey_schema_version": load_schema()["schema_version"],
        "total_instrument_items": load_schema()["instrument_design"][
            "total_instrument_items"
        ],
        "reference_only_zh": "所有示例均为匿名或合成数据，仅供参考。",
        "reference_only_en": "All examples use anonymised or synthetic data and are for reference only.",
        "examples": manifests,
    }
    EXAMPLE_ROOT.mkdir(parents=True, exist_ok=True)
    (EXAMPLE_ROOT / "manifest.json").write_text(
        json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(index, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


# Templates / 模板

本目录保存双语可编辑模板。Phase 2 已提供：

- `PCIO-Company-Profile-and-Technician-Survey.xlsx`：可编辑、可打印的305项公司画像与生产技术人员问卷工作簿。
- `pcio_survey_form.html`：无需安装的单文件离线表单，支持本机聚合及 CSV/JSON 导入导出。
- `pcio_survey_schema.json`：Excel、HTML、Streamlit和CSV共用的305项权威字段、题目、计分及质量控制定义。

This directory stores bilingual editable templates. Phase 2 provides the Excel workbook, the self-contained HTML form, and the shared authoritative JSON schema listed above.

1.0 可部署静态站位于 `../site/index.html`，由以下命令重建：

```powershell
.\.venv\Scripts\python scripts/build_phase5_static_site.py
```

The deployable version 1.0 static site is generated at `../site/index.html`.

"""SPSS-style analysis engine for PCIO technician survey data."""

from __future__ import annotations

import json
import math
import platform
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Any, BinaryIO, Iterable

import numpy as np
import pandas as pd
import scipy
from scipy import stats
import statsmodels
import statsmodels.api as sm
from openpyxl.styles import Font, PatternFill
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Border, Side
from statsmodels.stats.diagnostic import het_breuschpagan
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson, jarque_bera

from scripts.pcio_survey_core import load_schema, normalise_project_code, selected_questions


PCIO_LAYERS = ("P", "C", "I", "O")
PREDICTOR_LAYERS = ("P", "C", "I", "O", "H")
PERFORMANCE_ITEMS = ("PERF_QUALITY", "PERF_COST", "PERF_EFF", "PERF_FLEX")
PERFORMANCE_LABELS = {
    "PERF_OVERALL": {"zh": "综合生产绩效", "en": "Overall production performance"},
    "PERF_QUALITY": {"zh": "质量改善", "en": "Quality improvement"},
    "PERF_COST": {"zh": "成本改善", "en": "Cost improvement"},
    "PERF_EFF": {"zh": "效率改善", "en": "Efficiency improvement"},
    "PERF_FLEX": {"zh": "柔性改善", "en": "Flexibility improvement"},
}
LAYER_LABELS = {
    "P": {"zh": "P 感知层", "en": "P Perception"},
    "C": {"zh": "C 连接层", "en": "C Connectivity"},
    "I": {"zh": "I 集成层", "en": "I Integration"},
    "O": {"zh": "O 优化层", "en": "O Optimisation"},
    "H": {"zh": "人机协同", "en": "Human-machine collaboration"},
    "R": {"zh": "生产绩效", "en": "Production performance"},
}


def _warning(code: str, zh: str, en: str) -> dict[str, str]:
    return {"code": code, "zh": zh, "en": en}


def _json_scalar(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return None if not math.isfinite(float(value)) else float(value)
    if isinstance(value, np.bool_):
        return bool(value)
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    return value


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    return _json_scalar(value)


def read_profile(source: str | Path | BinaryIO | bytes) -> dict[str, Any]:
    if isinstance(source, bytes):
        payload = source.decode("utf-8-sig")
    elif hasattr(source, "read"):
        raw = source.read()
        payload = raw.decode("utf-8-sig") if isinstance(raw, bytes) else raw
    else:
        payload = Path(source).read_text(encoding="utf-8-sig")
    return json.loads(payload)


def read_response_csv(source: str | Path | BinaryIO | bytes) -> pd.DataFrame:
    if isinstance(source, bytes):
        return pd.read_csv(BytesIO(source), encoding="utf-8-sig")
    return pd.read_csv(source, encoding="utf-8-sig")


def combine_response_csvs(sources: Iterable[str | Path | BinaryIO | bytes]) -> pd.DataFrame:
    frames = [read_response_csv(source) for source in sources]
    if not frames:
        raise ValueError("At least one response CSV is required.")
    return pd.concat(frames, ignore_index=True, sort=False)


def _score_series(series: pd.Series, reverse: bool) -> tuple[pd.Series, int]:
    normalised = series.astype(str).str.strip().str.upper()
    numeric = pd.to_numeric(series, errors="coerce")
    missing_tokens = normalised.isin(["", "NA", "N/A", "NONE", "NAN"])
    invalid = int(((series.notna()) & ~missing_tokens & numeric.isna()).sum())
    outside = numeric.notna() & ~numeric.isin([1, 2, 3, 4, 5])
    invalid += int(outside.sum())
    numeric = numeric.mask(outside)
    return (6.0 - numeric if reverse else numeric.astype(float)), invalid


def _row_mean(frame: pd.DataFrame, minimum_fraction: float = 0.6) -> pd.Series:
    if frame.empty:
        return pd.Series(np.nan, index=frame.index, dtype=float)
    minimum = max(1, math.ceil(frame.shape[1] * minimum_fraction))
    return frame.mean(axis=1, skipna=True).where(frame.notna().sum(axis=1) >= minimum)


def prepare_analysis_data(
    profile: dict[str, Any],
    responses: pd.DataFrame,
    schema: dict[str, Any] | None = None,
) -> dict[str, Any]:
    schema = schema or load_schema()
    raw = responses.copy()
    imported_rows = len(raw)
    warnings: list[dict[str, str]] = []
    required_metadata = {"project_code"}
    missing_metadata = sorted(required_metadata.difference(raw.columns))
    if missing_metadata:
        raise ValueError(f"Response CSV is missing required columns: {missing_metadata}")

    project_code = normalise_project_code(str(profile["project_code"]))
    normalised_codes = raw["project_code"].fillna("").astype(str).map(
        lambda value: normalise_project_code(value) if value.strip() else ""
    )
    mismatch_mask = normalised_codes != project_code
    project_mismatch_rows = int(mismatch_mask.sum())
    if project_mismatch_rows:
        warnings.append(
            _warning(
                "project_mismatch",
                f"已排除 {project_mismatch_rows} 条其他项目代码的记录。",
                f"{project_mismatch_rows} row(s) from other project codes were excluded.",
            )
        )
    raw = raw.loc[~mismatch_mask].copy()

    duplicates_removed = 0
    if "submission_id" in raw.columns:
        present = raw["submission_id"].fillna("").astype(str).str.strip() != ""
        duplicated = present & raw["submission_id"].duplicated(keep="last")
        duplicates_removed = int(duplicated.sum())
        raw = raw.loc[~duplicated].copy()
    if duplicates_removed:
        warnings.append(
            _warning(
                "duplicate_submission",
                f"已移除 {duplicates_removed} 条重复提交。",
                f"{duplicates_removed} duplicate submission(s) were removed.",
            )
        )

    question_lookup = {question["id"]: question for question in schema["questions"]}
    selected = selected_questions(schema, profile)
    selected_likert = [q for q in selected if q["type"] == "likert"]
    missing_question_columns = [q["id"] for q in selected_likert if q["id"] not in raw.columns]
    if missing_question_columns:
        warnings.append(
            _warning(
                "missing_active_columns",
                f"{len(missing_question_columns)} 个启用题目列缺失，已按缺失值处理。",
                f"{len(missing_question_columns)} active question column(s) were absent and treated as missing.",
            )
        )
        for question_id in missing_question_columns:
            raw[question_id] = np.nan

    scored_columns: dict[str, pd.Series] = {}
    invalid_values = 0
    for question in schema["questions"]:
        if question["type"] != "likert":
            continue
        if question["id"] not in raw.columns:
            raw[question["id"]] = np.nan
        scored_columns[question["id"]], invalid = _score_series(
            raw[question["id"]], bool(question.get("reverse"))
        )
        invalid_values += invalid
    scored = pd.DataFrame(scored_columns, index=raw.index)
    if invalid_values:
        warnings.append(
            _warning(
                "invalid_likert",
                f"{invalid_values} 个非法 Likert 值已转换为缺失值。",
                f"{invalid_values} invalid Likert value(s) were converted to missing.",
            )
        )

    scale_scores = pd.DataFrame(index=raw.index)
    scale_items: dict[str, list[str]] = {}
    for layer in PREDICTOR_LAYERS:
        ids = [
            q["id"]
            for q in selected_likert
            if q["pcio_layer"] == layer
            and q.get("analysis_role", "scale") == "scale"
        ]
        scale_items[layer] = ids
        scale_scores[layer] = _row_mean(scored[ids]) if ids else np.nan
    for item in PERFORMANCE_ITEMS:
        scale_scores[item] = scored[item]
    scale_scores["PERF_OVERALL"] = _row_mean(scored[list(PERFORMANCE_ITEMS)], 0.75)

    core_construct_ids = [
        q["id"]
        for q in schema["questions"]
        if q.get("validity_anchor")
        and q["type"] == "likert"
        and q.get("analysis_role") == "scale"
    ]
    attention_items = [
        q for q in selected_likert if q.get("analysis_role") == "attention"
    ]
    attention_failures = pd.Series(0, index=raw.index, dtype=int)
    attention_answered = pd.Series(0, index=raw.index, dtype=int)
    for question in attention_items:
        expected = question.get("attention_check", {}).get("expected", 4)
        values = pd.to_numeric(raw[question["id"]], errors="coerce")
        answered = values.notna()
        attention_answered += answered.astype(int)
        attention_failures += (answered & values.ne(expected)).astype(int)
    attention_flagged_rows = int((attention_failures > 0).sum())
    if attention_flagged_rows:
        warnings.append(
            _warning(
                "attention_check_failure",
                f"{attention_flagged_rows} 份答卷至少未通过一道注意力检测题；未自动删除，需在敏感性分析中复核。",
                f"{attention_flagged_rows} response(s) failed at least one attention check. They were retained and should be reviewed in sensitivity analysis.",
            )
        )
    retained_rows = len(raw)
    if retained_rows < 30:
        warnings.append(
            _warning(
                "small_sample",
                "有效项目响应少于 30 份，推断统计必须谨慎解释。",
                "Fewer than 30 valid project responses are available; inferential results require caution.",
            )
        )

    return {
        "raw": raw.reset_index(drop=True),
        "scored_items": scored.reset_index(drop=True),
        "scale_scores": scale_scores.reset_index(drop=True),
        "scale_items": scale_items,
        "core_construct_ids": core_construct_ids,
        "question_lookup": question_lookup,
        "quality": {
            "imported_rows": imported_rows,
            "retained_rows": retained_rows,
            "project_mismatch_rows": project_mismatch_rows,
            "duplicates_removed": duplicates_removed,
            "invalid_likert_values": invalid_values,
            "active_likert_items": len(selected_likert),
            "attention_check_items": len(attention_items),
            "attention_flagged_rows": attention_flagged_rows,
            "attention_pass_rate": (
                float(
                    (
                        attention_answered.sum() - attention_failures.sum()
                    )
                    / attention_answered.sum()
                )
                if attention_answered.sum()
                else None
            ),
            "validity_anchor_items": len(core_construct_ids),
            "warnings": warnings,
        },
    }


def descriptive_table(
    data: pd.DataFrame,
    variables: Iterable[str],
    labels: dict[str, dict[str, str]] | None = None,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for variable in variables:
        if variable not in data:
            continue
        values = pd.to_numeric(data[variable], errors="coerce").dropna()
        if values.empty:
            continue
        sem = values.std(ddof=1) / math.sqrt(len(values)) if len(values) > 1 else np.nan
        margin = stats.t.ppf(0.975, len(values) - 1) * sem if len(values) > 1 else np.nan
        rows.append(
            {
                "variable": variable,
                "label_zh": (labels or {}).get(variable, {}).get("zh", variable),
                "label_en": (labels or {}).get(variable, {}).get("en", variable),
                "n": len(values),
                "missing": int(data[variable].isna().sum()),
                "mean": values.mean(),
                "std_dev": values.std(ddof=1) if len(values) > 1 else np.nan,
                "min": values.min(),
                "max": values.max(),
                "ci95_lower": values.mean() - margin if len(values) > 1 else np.nan,
                "ci95_upper": values.mean() + margin if len(values) > 1 else np.nan,
            }
        )
    return json_safe(rows)


def cronbach_alpha(frame: pd.DataFrame) -> dict[str, Any]:
    usable = frame.dropna(axis=1, how="all")
    usable = usable.loc[:, usable.nunique(dropna=True) > 1]
    if usable.empty:
        return {"alpha": None, "n": 0, "items": 0, "status": "insufficient"}
    minimum = max(2, math.ceil(usable.shape[1] * 0.8))
    eligible = usable.loc[usable.notna().sum(axis=1) >= minimum].copy()
    complete = eligible.fillna(eligible.mean(axis=0))
    k = complete.shape[1]
    n = complete.shape[0]
    if k < 2 or n < 3:
        return {"alpha": None, "n": n, "items": k, "status": "insufficient"}
    item_variances = complete.var(axis=0, ddof=1).sum()
    total_variance = complete.sum(axis=1).var(ddof=1)
    if total_variance <= 0:
        return {"alpha": None, "n": n, "items": k, "status": "zero_variance"}
    alpha = k / (k - 1) * (1 - item_variances / total_variance)
    return {
        "alpha": alpha,
        "n": n,
        "items": k,
        "status": "ok",
        "missing_rule": "respondent >=80% complete; remaining cells item-mean imputed",
    }


def reliability_table(prepared: dict[str, Any]) -> list[dict[str, Any]]:
    scored = prepared["scored_items"]
    rows: list[dict[str, Any]] = []
    for scale, item_ids in prepared["scale_items"].items():
        result = cronbach_alpha(scored[item_ids])
        rows.append({"scale": scale, "item_set": "active_company", **result})
    result = cronbach_alpha(scored[list(PERFORMANCE_ITEMS)])
    rows.append({"scale": "R", "item_set": "performance_4_items", **result})
    return json_safe(rows)


def kmo_bartlett(frame: pd.DataFrame) -> dict[str, Any]:
    usable = frame.dropna(axis=1, how="all")
    usable = usable.loc[:, usable.nunique(dropna=True) > 1]
    complete = usable.dropna(axis=0, how="any")
    n, p = complete.shape
    if p < 2 or n < max(5, p + 1):
        return {
            "status": "insufficient",
            "n": n,
            "variables": p,
            "kmo_overall": None,
            "bartlett_chi_square": None,
            "bartlett_df": None,
            "bartlett_p": None,
            "item_kmo": [],
        }
    correlation = np.corrcoef(complete.to_numpy(dtype=float), rowvar=False)
    correlation = np.nan_to_num(correlation, nan=0.0)
    np.fill_diagonal(correlation, 1.0)
    regularised = correlation + np.eye(p) * 1e-8
    inverse = np.linalg.pinv(regularised)
    denominator = np.sqrt(np.outer(np.diag(inverse), np.diag(inverse)))
    partial = -inverse / denominator
    np.fill_diagonal(partial, 0.0)
    corr_sq = correlation**2
    partial_sq = partial**2
    np.fill_diagonal(corr_sq, 0.0)
    item_numerator = corr_sq.sum(axis=0)
    item_denominator = item_numerator + partial_sq.sum(axis=0)
    item_kmo_values = np.divide(
        item_numerator,
        item_denominator,
        out=np.full(p, np.nan),
        where=item_denominator > 0,
    )
    overall_denominator = corr_sq.sum() + partial_sq.sum()
    kmo = corr_sq.sum() / overall_denominator if overall_denominator > 0 else np.nan

    sign, log_determinant = np.linalg.slogdet(regularised)
    if sign <= 0:
        bartlett = bartlett_p = np.nan
    else:
        bartlett = -(n - 1 - (2 * p + 5) / 6) * log_determinant
        bartlett_p = stats.chi2.sf(bartlett, p * (p - 1) / 2)
    return json_safe(
        {
            "status": "ok",
            "n": n,
            "variables": p,
            "kmo_overall": kmo,
            "bartlett_chi_square": bartlett,
            "bartlett_df": p * (p - 1) // 2,
            "bartlett_p": bartlett_p,
            "item_kmo": [
                {"variable": column, "kmo": item_kmo_values[index]}
                for index, column in enumerate(complete.columns)
            ],
            "sample_to_variable_ratio": n / p,
        }
    )


def correlation_tables(
    scale_scores: pd.DataFrame,
    variables: Iterable[str],
) -> dict[str, Any]:
    variables = [variable for variable in variables if variable in scale_scores]
    r_matrix = pd.DataFrame(np.nan, index=variables, columns=variables)
    p_matrix = pd.DataFrame(np.nan, index=variables, columns=variables)
    n_matrix = pd.DataFrame(0, index=variables, columns=variables)
    long_rows: list[dict[str, Any]] = []
    for i, left in enumerate(variables):
        for j, right in enumerate(variables):
            pair = scale_scores[[left, right]].dropna()
            n_matrix.loc[left, right] = len(pair)
            if left == right and len(pair):
                r_matrix.loc[left, right] = 1.0
                p_matrix.loc[left, right] = 0.0
            elif len(pair) >= 3 and pair[left].nunique() > 1 and pair[right].nunique() > 1:
                coefficient, p_value = stats.pearsonr(pair[left], pair[right])
                r_matrix.loc[left, right] = coefficient
                p_matrix.loc[left, right] = p_value
            if j > i:
                long_rows.append(
                    {
                        "variable_1": left,
                        "variable_2": right,
                        "n": int(n_matrix.loc[left, right]),
                        "pearson_r": r_matrix.loc[left, right],
                        "p_value": p_matrix.loc[left, right],
                    }
                )
    return json_safe(
        {
            "r_matrix": r_matrix.reset_index(names="variable").to_dict("records"),
            "p_matrix": p_matrix.reset_index(names="variable").to_dict("records"),
            "n_matrix": n_matrix.reset_index(names="variable").to_dict("records"),
            "long_table": long_rows,
        }
    )


def group_difference_tests(
    raw: pd.DataFrame,
    scale_scores: pd.DataFrame,
    group_variables: Iterable[str] = ("participated_digital_project", "shift", "role"),
    outcomes: Iterable[str] = (*PREDICTOR_LAYERS, "PERF_OVERALL"),
    minimum_group_n: int = 5,
) -> list[dict[str, Any]]:
    data = pd.concat(
        [raw.reset_index(drop=True), scale_scores.reset_index(drop=True)],
        axis=1,
    )
    rows: list[dict[str, Any]] = []
    for group_variable in group_variables:
        if group_variable not in data:
            continue
        for outcome in outcomes:
            if outcome not in data:
                continue
            subset = data[[group_variable, outcome]].copy()
            subset[group_variable] = (
                subset[group_variable].fillna("").astype(str).str.strip()
            )
            subset[outcome] = pd.to_numeric(subset[outcome], errors="coerce")
            subset = subset.loc[
                (subset[group_variable] != "") & subset[outcome].notna()
            ]
            grouped = [
                (name, group[outcome].to_numpy(dtype=float))
                for name, group in subset.groupby(group_variable, sort=True)
            ]
            summaries = [
                {
                    "group": name,
                    "n": len(values),
                    "mean": np.mean(values) if len(values) else np.nan,
                    "std_dev": np.std(values, ddof=1) if len(values) > 1 else np.nan,
                }
                for name, values in grouped
            ]
            base = {
                "group_variable": group_variable,
                "outcome": outcome,
                "n_total": len(subset),
                "minimum_group_n": minimum_group_n,
                "groups": summaries,
            }
            if len(grouped) < 2 or any(len(values) < minimum_group_n for _, values in grouped):
                rows.append(
                    {
                        **base,
                        "test": "not_run",
                        "status": "insufficient",
                        "statistic": None,
                        "df1": None,
                        "df2": None,
                        "p_value": None,
                        "p_fdr_bh": None,
                        "effect_size_name": None,
                        "effect_size": None,
                    }
                )
                continue
            if len(grouped) == 2:
                (_, left), (_, right) = grouped
                statistic, p_value = stats.ttest_ind(
                    left, right, equal_var=False, nan_policy="omit"
                )
                left_var = np.var(left, ddof=1)
                right_var = np.var(right, ddof=1)
                left_term = left_var / len(left)
                right_term = right_var / len(right)
                denominator = (
                    (left_term**2) / (len(left) - 1)
                    + (right_term**2) / (len(right) - 1)
                )
                welch_df = (
                    (left_term + right_term) ** 2 / denominator
                    if denominator > 0
                    else np.nan
                )
                pooled_denominator = len(left) + len(right) - 2
                pooled_variance = (
                    ((len(left) - 1) * left_var + (len(right) - 1) * right_var)
                    / pooled_denominator
                    if pooled_denominator > 0
                    else np.nan
                )
                pooled_sd = math.sqrt(pooled_variance) if pooled_variance > 0 else np.nan
                cohen_d = (
                    (np.mean(left) - np.mean(right)) / pooled_sd
                    if pooled_sd and np.isfinite(pooled_sd)
                    else np.nan
                )
                correction = (
                    1 - 3 / (4 * (len(left) + len(right)) - 9)
                    if len(left) + len(right) > 2
                    else np.nan
                )
                rows.append(
                    {
                        **base,
                        "test": "welch_t_test",
                        "status": "ok",
                        "statistic": statistic,
                        "df1": welch_df,
                        "df2": None,
                        "p_value": p_value,
                        "p_fdr_bh": None,
                        "effect_size_name": "hedges_g",
                        "effect_size": cohen_d * correction,
                    }
                )
            else:
                arrays = [values for _, values in grouped]
                statistic, p_value = stats.f_oneway(*arrays)
                grand_mean = subset[outcome].mean()
                ss_between = sum(
                    len(values) * (np.mean(values) - grand_mean) ** 2
                    for _, values in grouped
                )
                ss_total = float(((subset[outcome] - grand_mean) ** 2).sum())
                rows.append(
                    {
                        **base,
                        "test": "one_way_anova",
                        "status": "ok",
                        "statistic": statistic,
                        "df1": len(grouped) - 1,
                        "df2": len(subset) - len(grouped),
                        "p_value": p_value,
                        "p_fdr_bh": None,
                        "effect_size_name": "eta_squared",
                        "effect_size": ss_between / ss_total if ss_total > 0 else np.nan,
                    }
                )
    valid_indices = [
        index
        for index, row in enumerate(rows)
        if row["status"] == "ok" and row["p_value"] is not None
    ]
    if valid_indices:
        adjusted = multipletests(
            [rows[index]["p_value"] for index in valid_indices],
            method="fdr_bh",
        )[1]
        for index, adjusted_p in zip(valid_indices, adjusted):
            rows[index]["p_fdr_bh"] = adjusted_p
    return json_safe(rows)


def _regression_model(
    data: pd.DataFrame,
    dependent: str,
    predictors: Iterable[str],
) -> dict[str, Any]:
    predictors = [predictor for predictor in predictors if predictor in data]
    model_data = data[[dependent] + predictors].dropna().copy()
    predictors = [
        predictor for predictor in predictors if model_data[predictor].nunique(dropna=True) > 1
    ]
    model_data = model_data[[dependent] + predictors]
    minimum_n = max(30, 5 * len(predictors) + 5)
    if len(predictors) < 2 or len(model_data) < minimum_n or model_data[dependent].nunique() < 2:
        return {
            "dependent": dependent,
            "status": "insufficient",
            "n": len(model_data),
            "minimum_n": minimum_n,
            "predictors": predictors,
            "model": {},
            "coefficients": [],
        }

    standardised = model_data.apply(lambda column: (column - column.mean()) / column.std(ddof=1))
    y = standardised[dependent]
    x = sm.add_constant(standardised[predictors], has_constant="add")
    result = sm.OLS(y, x).fit(cov_type="HC3")
    residuals = result.resid
    jb_stat, jb_p, _, _ = jarque_bera(residuals)
    bp_stat, bp_p, _, _ = het_breuschpagan(residuals, x)
    influence = result.get_influence()
    cooks = influence.cooks_distance[0]
    vif_rows = []
    for index, variable in enumerate(x.columns):
        if variable == "const":
            continue
        try:
            vif = variance_inflation_factor(x.to_numpy(), index)
        except (ValueError, np.linalg.LinAlgError):
            vif = np.nan
        vif_rows.append({"variable": variable, "vif": vif})

    coefficient_rows = []
    for variable in x.columns:
        coefficient_rows.append(
            {
                "dependent": dependent,
                "predictor": "Intercept" if variable == "const" else variable,
                "standardised_beta": result.params[variable],
                "robust_std_error": result.bse[variable],
                "t": result.tvalues[variable],
                "p_value": result.pvalues[variable],
                "ci95_lower": result.conf_int().loc[variable, 0],
                "ci95_upper": result.conf_int().loc[variable, 1],
            }
        )
    predictor_indices = [
        index for index, row in enumerate(coefficient_rows) if row["predictor"] != "Intercept"
    ]
    if predictor_indices:
        adjusted = multipletests(
            [coefficient_rows[index]["p_value"] for index in predictor_indices],
            method="fdr_bh",
        )[1]
        for index, p_adjusted in zip(predictor_indices, adjusted):
            coefficient_rows[index]["p_fdr_bh"] = p_adjusted
    return json_safe(
        {
            "dependent": dependent,
            "status": "ok",
            "n": len(model_data),
            "minimum_n": minimum_n,
            "predictors": predictors,
            "model": {
                "r_squared": result.rsquared,
                "adjusted_r_squared": result.rsquared_adj,
                "f_statistic": result.fvalue,
                "f_p_value": result.f_pvalue,
                "df_model": result.df_model,
                "df_residual": result.df_resid,
                "aic": result.aic,
                "bic": result.bic,
                "durbin_watson": durbin_watson(residuals),
                "jarque_bera": jb_stat,
                "jarque_bera_p": jb_p,
                "breusch_pagan": bp_stat,
                "breusch_pagan_p": bp_p,
                "max_cooks_distance": np.max(cooks) if len(cooks) else np.nan,
                "max_vif": max((row["vif"] for row in vif_rows), default=np.nan),
                "covariance": "HC3 robust",
            },
            "coefficients": coefficient_rows,
            "vif": vif_rows,
        }
    )


def regression_models(scale_scores: pd.DataFrame) -> list[dict[str, Any]]:
    dependents = ["PERF_OVERALL", *PERFORMANCE_ITEMS]
    return [
        _regression_model(scale_scores, dependent, PREDICTOR_LAYERS)
        for dependent in dependents
    ]


def _maturity_band(score: float | None) -> dict[str, str]:
    if score is None:
        return {"zh": "数据不足", "en": "Insufficient data"}
    if score < 2.5:
        return {"zh": "基础缺口", "en": "Foundational gap"}
    if score < 3.2:
        return {"zh": "局部分散", "en": "Fragmented"}
    if score < 3.8:
        return {"zh": "发展中", "en": "Developing"}
    if score < 4.2:
        return {"zh": "受控运行", "en": "Managed"}
    return {"zh": "接近理想", "en": "Near target"}


def business_interpretation(analysis: dict[str, Any]) -> dict[str, Any]:
    scale_rows = analysis["tables"]["scale_descriptives"]
    layer_scores = {
        row["variable"]: row["mean"]
        for row in scale_rows
        if row["variable"] in PREDICTOR_LAYERS
    }
    pcio_scores = {key: value for key, value in layer_scores.items() if key in PCIO_LAYERS}
    lowest = min(pcio_scores, key=pcio_scores.get) if pcio_scores else None
    highest = max(pcio_scores, key=pcio_scores.get) if pcio_scores else None
    overall = next(
        (row["mean"] for row in scale_rows if row["variable"] == "PERF_OVERALL"),
        None,
    )
    strongest_correlation = None
    candidates = [
        row
        for row in analysis["tables"]["correlations"]["long_table"]
        if "PERF_OVERALL" in {row["variable_1"], row["variable_2"]}
        and row["pearson_r"] is not None
        and ({row["variable_1"], row["variable_2"]} & set(PREDICTOR_LAYERS))
    ]
    if candidates:
        strongest_correlation = max(candidates, key=lambda row: abs(row["pearson_r"]))

    significant_predictors: list[dict[str, Any]] = []
    overall_model = next(
        (model for model in analysis["tables"]["regressions"] if model["dependent"] == "PERF_OVERALL"),
        None,
    )
    if overall_model and overall_model["status"] == "ok":
        significant_predictors = [
            row
            for row in overall_model["coefficients"]
            if row["predictor"] != "Intercept"
            and row.get("p_fdr_bh") is not None
            and row["p_fdr_bh"] < 0.05
        ]

    zh: list[str] = []
    en: list[str] = []
    if lowest and highest:
        zh.append(
            f"四层中，{LAYER_LABELS[lowest]['zh']}均值最低（{pcio_scores[lowest]:.2f}），"
            f"{LAYER_LABELS[highest]['zh']}最高（{pcio_scores[highest]:.2f}）。"
        )
        en.append(
            f"Among the four PCIO layers, {LAYER_LABELS[lowest]['en']} is lowest "
            f"({pcio_scores[lowest]:.2f}) and {LAYER_LABELS[highest]['en']} is highest "
            f"({pcio_scores[highest]:.2f})."
        )
    if overall is not None:
        band = _maturity_band(overall)
        zh.append(f"综合生产绩效感知均值为 {overall:.2f}/5，属于“{band['zh']}”区间。")
        en.append(
            f"Perceived overall production performance is {overall:.2f}/5, in the "
            f"'{band['en']}' band."
        )
    if strongest_correlation:
        other = (
            strongest_correlation["variable_2"]
            if strongest_correlation["variable_1"] == "PERF_OVERALL"
            else strongest_correlation["variable_1"]
        )
        zh.append(
            f"与综合绩效关系最强的当前样本维度为 {LAYER_LABELS[other]['zh']} "
            f"(r={strongest_correlation['pearson_r']:.3f})；相关不等于因果。"
        )
        en.append(
            f"The strongest current-sample association with overall performance is "
            f"{LAYER_LABELS[other]['en']} (r={strongest_correlation['pearson_r']:.3f}); "
            "correlation does not establish causality."
        )
    if significant_predictors:
        names_zh = "、".join(LAYER_LABELS[row["predictor"]]["zh"] for row in significant_predictors)
        names_en = ", ".join(LAYER_LABELS[row["predictor"]]["en"] for row in significant_predictors)
        zh.append(f"在 FDR 校正后的综合绩效回归中，{names_zh}保留统计关联。")
        en.append(
            f"In the overall-performance regression after FDR correction, {names_en} "
            "retain statistical associations."
        )
    else:
        zh.append("综合绩效回归未发现经 FDR 校正后仍显著的单一层级，建议按系统短板而非单个 p 值排序。")
        en.append(
            "No single layer remains significant after FDR correction in the overall model; "
            "prioritise system bottlenecks rather than one p-value."
        )
    significant_group_differences = [
        row
        for row in analysis["tables"].get("group_differences", [])
        if row["status"] == "ok"
        and row.get("p_fdr_bh") is not None
        and row["p_fdr_bh"] < 0.05
    ]
    if significant_group_differences:
        pairs = "、".join(
            f"{row['group_variable']}→{row['outcome']}"
            for row in significant_group_differences
        )
        zh.append(f"FDR 校正后仍保留的组间差异为：{pairs}；需结合岗位与班次样本结构解释。")
        en.append(
            "Group differences retained after FDR correction: "
            + ", ".join(
                f"{row['group_variable']}→{row['outcome']}"
                for row in significant_group_differences
            )
            + "; interpret them with the role and shift sample structure."
        )
    else:
        zh.append(
            "按是否参与数字化项目、班次和岗位进行的组间检验在 FDR 校正后均未显著；"
            "这表示当前样本未发现稳定差异，不等于各组完全相同。"
        )
        en.append(
            "No group difference by digital-project participation, shift, or role remained "
            "significant after FDR correction; this is absence of stable evidence, not proof "
            "that all groups are identical."
        )
    zh.append(
        "外部 n=52 区域样本中 Sensor_Inf=4.5077 为四项技术影响均值最高，但仅略高于 IoT。"
        "本项目据此采用“感知与数据质量优先”，不把该结果解释为普遍因果。"
    )
    en.append(
        "In the external regional sample of n=52, Sensor_Inf=4.5077 was the highest of "
        "four technology-influence means, only slightly above IoT. The toolkit therefore "
        "uses a perception-and-data-quality-first rule without claiming universal causality."
    )
    return {
        "zh": zh,
        "en": en,
        "lowest_pcio_layer": lowest,
        "highest_pcio_layer": highest,
        "layer_scores": json_safe(layer_scores),
        "performance_overall": _json_scalar(overall),
        "strongest_performance_correlation": strongest_correlation,
        "significant_overall_predictors": significant_predictors,
        "significant_group_differences": significant_group_differences,
    }


def analyze_pcio_survey(
    profile: dict[str, Any],
    responses: pd.DataFrame,
    schema: dict[str, Any] | None = None,
) -> dict[str, Any]:
    schema = schema or load_schema()
    prepared = prepare_analysis_data(profile, responses, schema)
    question_labels = {
        question["id"]: {"zh": question["zh"], "en": question["en"]}
        for question in schema["questions"]
    }
    scale_labels = {
        **{layer: LAYER_LABELS[layer] for layer in PREDICTOR_LAYERS},
        **PERFORMANCE_LABELS,
    }
    active_ids = [
        question["id"]
        for question in selected_questions(schema, profile)
        if question["type"] == "likert"
        and question.get("analysis_role") != "attention"
    ]
    scale_variables = [*PREDICTOR_LAYERS, *PERFORMANCE_ITEMS, "PERF_OVERALL"]
    kmo = kmo_bartlett(prepared["scored_items"][prepared["core_construct_ids"]])
    if kmo.get("status") == "ok":
        if (kmo.get("kmo_overall") or 0) < 0.6:
            prepared["quality"]["warnings"].append(
                _warning(
                    "low_kmo",
                    "总体 KMO 低于 0.60，因子结构仅可作探索性解释。",
                    "Overall KMO is below 0.60; factor-structure interpretation is exploratory.",
                )
            )
        if (kmo.get("sample_to_variable_ratio") or 0) < 5:
            prepared["quality"]["warnings"].append(
                _warning(
                    "low_sample_variable_ratio",
                    "KMO 题项层面的样本量与变量数之比低于 5:1。",
                    "The KMO item-level sample-to-variable ratio is below 5:1.",
                )
            )
    analysis: dict[str, Any] = {
        "analysis_version": "3.0.0",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "software": {
            "python": platform.python_version(),
            "pandas": pd.__version__,
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "statsmodels": statsmodels.__version__,
        },
        "profile": profile,
        "data_quality": prepared["quality"],
        "method": {
            "likert_range": "1-5",
            "reverse_scoring": "6-x",
            "scale_score": "row mean when at least 60% of active scale items are present",
            "performance_overall": "mean of at least 3 of 4 performance items",
            "reliability": (
                "Cronbach's alpha by P/C/I/O/H scale after retaining respondents with "
                "at least 80% scale completion and item-mean imputing remaining cells"
            ),
            "validity": (
                "KMO and Bartlett on a pre-specified balanced 20-item validity-anchor "
                "subset (four anchors per P/C/I/O/H scale); full EFA/CFA requires a "
                "substantially larger independent sample"
            ),
            "group_difference": (
                "Welch t-test for two groups and one-way ANOVA for three or more groups; "
                "minimum n=5 per group with BH-FDR across tests"
            ),
            "correlation": "two-sided pairwise Pearson correlation",
            "regression": "standardised OLS with HC3 robust standard errors and BH-FDR",
        },
        "tables": {
            "item_descriptives": descriptive_table(
                prepared["scored_items"], active_ids, question_labels
            ),
            "scale_descriptives": descriptive_table(
                prepared["scale_scores"], scale_variables, scale_labels
            ),
            "reliability": reliability_table(prepared),
            "kmo_bartlett": kmo,
            "correlations": correlation_tables(prepared["scale_scores"], scale_variables),
            "group_differences": group_difference_tests(
                prepared["raw"], prepared["scale_scores"]
            ),
            "regressions": regression_models(prepared["scale_scores"]),
        },
    }
    analysis["interpretation"] = business_interpretation(analysis)
    return json_safe(analysis)


def _table_frame(rows: list[dict[str, Any]]) -> pd.DataFrame:
    return pd.DataFrame(rows) if rows else pd.DataFrame({"status": ["No valid output"]})


def analysis_excel_bytes(analysis: dict[str, Any]) -> bytes:
    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        overview = pd.DataFrame(
            [
                ["Analysis version", analysis["analysis_version"]],
                ["Generated UTC", analysis["generated_at_utc"]],
                ["Project code", analysis["profile"].get("project_code", "")],
                ["Company", analysis["profile"].get("company_name", "")],
                ["Retained responses", analysis["data_quality"]["retained_rows"]],
                ["Sensor benchmark", "n=52; Sensor_Inf mean=4.5077 (external reference)"],
            ],
            columns=["Field", "Value"],
        )
        overview.to_excel(writer, sheet_name="Overview", index=False)
        pd.DataFrame(
            [
                {"metric": key, "value": json.dumps(value, ensure_ascii=False) if isinstance(value, list) else value}
                for key, value in analysis["data_quality"].items()
            ]
        ).to_excel(writer, sheet_name="Data_Quality", index=False)
        _table_frame(analysis["tables"]["scale_descriptives"]).to_excel(
            writer, sheet_name="Scale_Descriptives", index=False
        )
        _table_frame(analysis["tables"]["item_descriptives"]).to_excel(
            writer, sheet_name="Item_Descriptives", index=False
        )
        _table_frame(analysis["tables"]["reliability"]).to_excel(
            writer, sheet_name="Reliability", index=False
        )
        kmo = analysis["tables"]["kmo_bartlett"]
        pd.DataFrame(
            [{key: value for key, value in kmo.items() if key != "item_kmo"}]
        ).to_excel(writer, sheet_name="KMO_Bartlett", index=False)
        _table_frame(kmo.get("item_kmo", [])).to_excel(
            writer, sheet_name="Item_KMO", index=False
        )
        _table_frame(analysis["tables"]["correlations"]["r_matrix"]).to_excel(
            writer, sheet_name="Correlation_R", index=False
        )
        _table_frame(analysis["tables"]["correlations"]["p_matrix"]).to_excel(
            writer, sheet_name="Correlation_P", index=False
        )
        group_rows = []
        for row in analysis["tables"]["group_differences"]:
            flattened = {key: value for key, value in row.items() if key != "groups"}
            flattened["groups"] = json.dumps(row.get("groups", []), ensure_ascii=False)
            group_rows.append(flattened)
        _table_frame(group_rows).to_excel(
            writer, sheet_name="Group_Differences", index=False
        )
        model_rows = []
        coefficient_rows = []
        vif_rows = []
        for model in analysis["tables"]["regressions"]:
            model_rows.append(
                {
                    "dependent": model["dependent"],
                    "status": model["status"],
                    "n": model["n"],
                    **model.get("model", {}),
                }
            )
            coefficient_rows.extend(model.get("coefficients", []))
            vif_rows.extend(
                {"dependent": model["dependent"], **row} for row in model.get("vif", [])
            )
        _table_frame(model_rows).to_excel(writer, sheet_name="Regression_Models", index=False)
        _table_frame(coefficient_rows).to_excel(
            writer, sheet_name="Regression_Coefficients", index=False
        )
        _table_frame(vif_rows).to_excel(writer, sheet_name="VIF", index=False)
        interpretation_rows = []
        for language in ("zh", "en"):
            interpretation_rows.extend(
                {"language": language, "interpretation": text}
                for text in analysis["interpretation"][language]
            )
        _table_frame(interpretation_rows).to_excel(
            writer, sheet_name="Interpretation", index=False
        )
        workbook = writer.book
        dashboard = workbook.create_sheet("Dashboard", 0)
        dashboard.sheet_view.showGridLines = False
        dashboard.merge_cells("A1:H2")
        dashboard["A1"] = "PCIO Survey Analysis Dashboard / PCIO 问卷分析总览"
        dashboard["A1"].font = Font(size=18, bold=True, color="FFFFFF")
        dashboard["A1"].fill = PatternFill(fill_type="solid", fgColor="16324F")
        dashboard["A1"].alignment = Alignment(horizontal="left", vertical="center")
        scale_lookup = {
            row["variable"]: row for row in analysis["tables"]["scale_descriptives"]
        }
        kmo = analysis["tables"]["kmo_bartlett"]
        cards = [
            ("A4", "Valid responses / 有效样本", analysis["data_quality"]["retained_rows"]),
            ("C4", "KMO", kmo.get("kmo_overall")),
            (
                "E4",
                "Overall performance / 综合绩效",
                scale_lookup.get("PERF_OVERALL", {}).get("mean"),
            ),
            ("G4", "Ideal reference / 理想参考", 4.2),
        ]
        thin = Side(style="thin", color="D9E1E8")
        for cell, label, value in cards:
            column = dashboard[cell].column
            dashboard.cell(4, column, label)
            dashboard.cell(5, column, value)
            dashboard.merge_cells(
                start_row=4, start_column=column, end_row=4, end_column=column + 1
            )
            dashboard.merge_cells(
                start_row=5, start_column=column, end_row=5, end_column=column + 1
            )
            for row_index in (4, 5):
                target = dashboard.cell(row_index, column)
                target.alignment = Alignment(horizontal="center", vertical="center")
                target.border = Border(top=thin, bottom=thin, left=thin, right=thin)
            dashboard.cell(4, column).fill = PatternFill(
                fill_type="solid", fgColor="DDEBF7"
            )
            dashboard.cell(4, column).font = Font(bold=True, color="16324F")
            dashboard.cell(5, column).font = Font(size=16, bold=True, color="0F766E")
            if isinstance(value, float):
                dashboard.cell(5, column).number_format = "0.000"

        dashboard["A8"] = "Layer / 层级"
        dashboard["B8"] = "Mean / 均值"
        dashboard["C8"] = "Gap to 4.2 / 差距"
        for row_index, layer in enumerate(PREDICTOR_LAYERS, start=9):
            dashboard.cell(row_index, 1, LAYER_LABELS[layer]["en"])
            score = scale_lookup.get(layer, {}).get("mean")
            dashboard.cell(row_index, 2, score)
            dashboard.cell(row_index, 3, max(0, 4.2 - score) if score is not None else None)
            dashboard.cell(row_index, 2).number_format = "0.00"
            dashboard.cell(row_index, 3).number_format = "0.00"
        for cell in dashboard["8:8"]:
            if cell.column <= 3:
                cell.fill = PatternFill(fill_type="solid", fgColor="0F766E")
                cell.font = Font(bold=True, color="FFFFFF")

        dashboard["A16"] = "Reliability / 信度"
        dashboard["A17"] = "Scale"
        dashboard["B17"] = "Items"
        dashboard["C17"] = "n"
        dashboard["D17"] = "Cronbach's α"
        for row_index, row in enumerate(analysis["tables"]["reliability"], start=18):
            dashboard.cell(row_index, 1, row["scale"])
            dashboard.cell(row_index, 2, row["items"])
            dashboard.cell(row_index, 3, row["n"])
            dashboard.cell(row_index, 4, row["alpha"])
            dashboard.cell(row_index, 4).number_format = "0.000"
        for cell in dashboard["17:17"]:
            if cell.column <= 4:
                cell.fill = PatternFill(fill_type="solid", fgColor="0F766E")
                cell.font = Font(bold=True, color="FFFFFF")

        chart = BarChart()
        chart.type = "bar"
        chart.style = 10
        chart.title = "PCIO and collaboration scores / PCIO及协同得分"
        chart.y_axis.title = "Layer"
        chart.x_axis.title = "Mean score (1-5)"
        chart.x_axis.scaling.min = 0
        chart.x_axis.scaling.max = 5
        chart.height = 7.5
        chart.width = 13.5
        chart.add_data(Reference(dashboard, min_col=2, min_row=8, max_row=13), titles_from_data=True)
        chart.set_categories(Reference(dashboard, min_col=1, min_row=9, max_row=13))
        chart.legend = None
        dashboard.add_chart(chart, "E8")
        dashboard.column_dimensions["A"].width = 28
        dashboard.column_dimensions["B"].width = 14
        dashboard.column_dimensions["C"].width = 18
        dashboard.column_dimensions["D"].width = 16
        for column in ("E", "F", "G", "H"):
            dashboard.column_dimensions[column].width = 16
        dashboard.row_dimensions[1].height = 26
        dashboard.freeze_panes = "A8"

        for sheet in workbook.worksheets:
            if sheet.title == "Dashboard":
                continue
            sheet.freeze_panes = "A2"
            sheet.auto_filter.ref = sheet.dimensions
            sheet.sheet_view.showGridLines = False
            for cell in sheet[1]:
                cell.font = Font(
                    name=cell.font.name or "Calibri",
                    size=cell.font.sz or 11,
                    bold=True,
                    color="FFFFFF",
                )
                cell.fill = PatternFill(fill_type="solid", fgColor="16324F")
            for column in sheet.columns:
                letter = column[0].column_letter
                max_length = min(
                    48,
                    max(len(str(cell.value)) if cell.value is not None else 0 for cell in column)
                    + 2,
                )
                sheet.column_dimensions[letter].width = max(10, max_length)
    return buffer.getvalue()


def write_analysis_package(
    analysis: dict[str, Any],
    output_dir: str | Path,
) -> dict[str, Path]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    tables_dir = output / "tables"
    tables_dir.mkdir(exist_ok=True)
    json_path = output / "pcio_analysis_results.json"
    json_path.write_text(
        json.dumps(analysis, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    excel_path = output / "pcio_spss_style_tables.xlsx"
    excel_path.write_bytes(analysis_excel_bytes(analysis))
    table_map = {
        "scale_descriptives": analysis["tables"]["scale_descriptives"],
        "item_descriptives": analysis["tables"]["item_descriptives"],
        "reliability": analysis["tables"]["reliability"],
        "correlations": analysis["tables"]["correlations"]["long_table"],
        "group_differences": [
            {
                **{key: value for key, value in row.items() if key != "groups"},
                "groups": json.dumps(row.get("groups", []), ensure_ascii=False),
            }
            for row in analysis["tables"]["group_differences"]
        ],
    }
    for name, rows in table_map.items():
        _table_frame(rows).to_csv(
            tables_dir / f"{name}.csv", index=False, encoding="utf-8-sig"
        )
    regression_rows = []
    for model in analysis["tables"]["regressions"]:
        regression_rows.extend(model.get("coefficients", []))
    _table_frame(regression_rows).to_csv(
        tables_dir / "regression_coefficients.csv", index=False, encoding="utf-8-sig"
    )
    return {"json": json_path, "excel": excel_path, "tables": tables_dir}

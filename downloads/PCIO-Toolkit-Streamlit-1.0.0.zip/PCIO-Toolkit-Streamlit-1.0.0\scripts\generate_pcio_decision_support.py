﻿"""Command-line entry point for PCIO Phase 4 risk, KPI, and ROI outputs."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.pcio_decision_support import (  # noqa: E402
    generate_decision_support,
    write_decision_support_package,
)
from scripts.pcio_survey_core import load_schema  # noqa: E402


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate a personalised PCIO risk matrix, KPI set, and ROI workbook."
    )
    parser.add_argument("--profile", required=True, help="Company profile JSON path.")
    parser.add_argument("--analysis", required=True, help="Phase 3 analysis JSON path.")
    parser.add_argument("--output-dir", required=True, help="Output directory.")
    parser.add_argument("--investment", type=float)
    parser.add_argument("--annual-addressable-value", type=float)
    parser.add_argument("--annual-operating-cost", type=float)
    parser.add_argument("--improvement-low-pct", type=float)
    parser.add_argument("--improvement-high-pct", type=float)
    parser.add_argument("--horizon-years", type=int, default=3)
    parser.add_argument("--currency", default="CNY")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    profile = json.loads(Path(args.profile).read_text(encoding="utf-8"))
    analysis = json.loads(Path(args.analysis).read_text(encoding="utf-8"))
    provided = [
        args.investment,
        args.annual_addressable_value,
        args.annual_operating_cost,
        args.improvement_low_pct,
        args.improvement_high_pct,
    ]
    roi_inputs = None
    if any(value is not None for value in provided):
        if any(value is None for value in provided):
            raise ValueError("Provide all ROI numeric arguments or omit all of them.")
        roi_inputs = {
            "currency": args.currency,
            "investment": args.investment,
            "annual_addressable_value": args.annual_addressable_value,
            "annual_operating_cost": args.annual_operating_cost,
            "improvement_low_pct": args.improvement_low_pct,
            "improvement_high_pct": args.improvement_high_pct,
            "horizon_years": args.horizon_years,
            "source": "command_line",
            "assumption_note_zh": "用户输入的规划假设；仍需财务与业务负责人确认。",
            "assumption_note_en": "User-entered planning assumptions subject to finance and business validation.",
        }
    decision = generate_decision_support(
        profile, analysis, roi_inputs=roi_inputs, schema=load_schema()
    )
    paths = write_decision_support_package(decision, args.output_dir)
    print(
        json.dumps(
            {
                **{key: str(value) for key, value in paths.items()},
                "selected_risks": len(decision["risk"]["risks"]),
                "recommended_kpis": len(decision["kpis"]),
                "payback_range_months": decision["roi"]["payback_range_months"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


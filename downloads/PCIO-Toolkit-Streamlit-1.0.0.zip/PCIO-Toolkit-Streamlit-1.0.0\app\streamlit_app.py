"""PCIO bilingual survey, statistical analysis, and case-report application."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.pcio_survey_core import (  # noqa: E402
    aggregate_responses,
    append_response,
    flatten_response,
    load_profile,
    load_schema,
    read_responses,
    rows_to_csv_bytes,
    save_profile,
    selected_questions,
    validate_profile,
    validate_response,
)
from scripts.pcio_analysis import (  # noqa: E402
    LAYER_LABELS as ANALYSIS_LAYER_LABELS,
    analyze_pcio_survey,
    analysis_excel_bytes,
    combine_response_csvs,
    read_profile,
)
from scripts.pcio_report import generate_bilingual_report  # noqa: E402
from scripts.pcio_decision_support import (  # noqa: E402
    complete_package_zip_bytes,
    decision_support_excel_bytes,
    generate_decision_support,
    profile_roi_input_defaults,
)


SCHEMA = load_schema()


def localised_warning(warning: Any, language: str) -> str:
    """Render current bilingual warnings and legacy string warnings safely."""
    if isinstance(warning, dict):
        return str(
            warning.get(language)
            or warning.get("en")
            or warning.get("zh")
            or warning.get("code")
            or warning
        )
    return str(warning)


TEXT = {
    "zh": {
        "page_title": "PCIO 生产调查与个性化实施工具包",
        "page_subtitle": "公司画像、多人问卷、统计分析、风险矩阵、KPI 与 ROI",
        "workflow": "工作流程",
        "workflow_profile": "1 公司画像",
        "workflow_survey": "2 技术人员问卷",
        "workflow_aggregate": "3 聚合与导出",
        "workflow_analysis": "4 分析与决策",
        "workflow_help": "按顺序完成画像、问卷、聚合和分析；已保存项目可直接进入任一步。",
        "sidebar_note": "本地或企业内网部署。案例指标仅供参考，正式决策需人工审核。",
        "score_overview": "PCIO 能力得分概览",
        "export_center": "分析包下载中心",
        "export_note": "优先下载完整 ZIP；单项文件用于复核、二次分析或内部审批。",
        "risk_legend": "绿色=低，黄色=中，橙色=高，红色=极高",
        "profile_tab": "公司画像",
        "survey_tab": "技术人员问卷",
        "aggregate_tab": "聚合与导出",
        "analysis_tab": "分析与案例报告",
        "language": "界面语言",
        "save_profile": "保存公司画像",
        "profile_saved": "公司画像已保存。请把项目代码发给参与填写的技术人员。",
        "project_code": "项目代码",
        "load_project": "载入项目",
        "project_not_found": "未找到项目。请先由项目负责人保存公司画像。",
        "profile_summary": "当前项目画像",
        "dynamic_note": "根据行业、产线类型和痛点，本项目追加 {count} 道场景题。",
        "instrument_note": "完整问卷共280题，另含12项匿名个人信息；建议预留40-50分钟，并按模块连续作答。",
        "not_applicable": "不适用/无法判断",
        "rank_help": "请按点击顺序排列，必须选择 {count} 项且不得重复。",
        "respondent": "匿名填写信息",
        "submit": "提交问卷",
        "submitted": "提交成功。匿名响应代码：{code}",
        "validation": "请完成以下项目：",
        "responses": "有效提交数",
        "layer_summary": "PCIO 描述性聚合",
        "question_summary": "题目均值",
        "download_raw": "下载聚合响应 CSV",
        "download_summary": "下载描述性汇总 JSON",
        "no_responses": "当前项目暂无问卷提交。",
        "privacy": SCHEMA["privacy_notice"]["zh"],
        "scale": "1=非常不同意/几乎做不到；5=非常同意/稳定做到",
        "required": "必填",
        "select": "请选择",
        "choose_options": "请选择（可多选）",
        "save_first": "先保存公司画像，再进入问卷。",
        "descriptive_only": "本页提供快速描述性聚合；完整信效度、相关、回归和案例报告请进入“分析与案例报告”。",
        "analysis_source": "数据来源",
        "saved_project": "分析已保存项目",
        "upload_files": "上传画像 JSON + 问卷 CSV",
        "profile_json": "公司画像 JSON",
        "response_csvs": "技术人员问卷 CSV（可多选）",
        "run_analysis": "一键生成完整分析包",
        "analysis_ready": "分析完成",
        "data_quality": "数据质量",
        "reliability": "Cronbach's α 信度",
        "validity": "KMO / Bartlett 效度",
        "group_difference": "组间差异检验",
        "correlation": "Pearson 相关矩阵",
        "regression": "多元线性回归",
        "business_reading": "公司业务解读",
        "case_report": "贵公司 PCIO 实施案例分析报告",
        "decision_support": "风险、KPI 与 ROI",
        "risk_matrix": "4×4 动态风险矩阵",
        "risk_register": "优先风险与缓解措施",
        "kpi_dashboard": "个性化 KPI 仪表盘",
        "roi_calculator": "ROI 快速估算",
        "roi_assumptions": "ROI 规划假设（可编辑）",
        "investment": "一次性投资",
        "annual_value": "年度可改善价值池",
        "annual_cost": "年度新增运维成本",
        "improvement_low": "预期改善下限（%）",
        "improvement_high": "预期改善上限（%）",
        "currency": "币种",
        "high_risks": "高及极高风险",
        "kpi_count": "推荐 KPI",
        "payback": "静态回收期",
        "annual_net_benefit": "年度净收益区间",
        "download_analysis": "下载分析结果 JSON",
        "download_excel": "下载 SPSS 风格分析 Excel",
        "download_report": "下载双语案例报告 Markdown",
        "download_decision": "下载风险/KPI/ROI JSON",
        "download_decision_excel": "下载风险/KPI/ROI Excel",
        "download_package": "下载完整分析包 ZIP",
        "need_files": "请上传一份公司画像 JSON 和至少一份问卷 CSV。",
        "analysis_failed": "分析失败：",
        "sample": "有效样本",
        "kmo": "KMO",
        "performance": "综合生产绩效",
    },
    "en": {
        "page_title": "PCIO Production Survey and Personalised Implementation Toolkit",
        "page_subtitle": "Company profiling, surveys, statistics, risk matrix, KPI, and ROI",
        "workflow": "Workflow",
        "workflow_profile": "1 Company profile",
        "workflow_survey": "2 Technician survey",
        "workflow_aggregate": "3 Aggregate and export",
        "workflow_analysis": "4 Analysis and decisions",
        "workflow_help": "Complete profile, survey, aggregation, and analysis in sequence. Saved projects can enter any step directly.",
        "sidebar_note": "Designed for local or intranet deployment. Case metrics are references only and final decisions require human review.",
        "score_overview": "PCIO capability score overview",
        "export_center": "Analysis package download centre",
        "export_note": "Download the complete ZIP first; individual files support review, secondary analysis, and approval.",
        "risk_legend": "Green=low, yellow=moderate, orange=high, red=critical",
        "profile_tab": "Company Profile",
        "survey_tab": "Technician Survey",
        "aggregate_tab": "Aggregate and Export",
        "analysis_tab": "Analysis and Case Report",
        "language": "Interface language",
        "save_profile": "Save company profile",
        "profile_saved": "Company profile saved. Share the project code with participating technicians.",
        "project_code": "Project code",
        "load_project": "Load project",
        "project_not_found": "Project not found. Ask the project owner to save the company profile first.",
        "profile_summary": "Current project profile",
        "dynamic_note": "{count} scenario questions were added based on the sector, production type, and pain points.",
        "instrument_note": "The full survey contains 280 questions plus 12 anonymous respondent fields. Allow 40-50 minutes and complete it module by module.",
        "not_applicable": "Not applicable / unable to judge",
        "rank_help": "Select in priority order. Choose exactly {count} unique items.",
        "respondent": "Anonymous respondent details",
        "submit": "Submit survey",
        "submitted": "Submission complete. Anonymous response code: {code}",
        "validation": "Complete the following items:",
        "responses": "Valid submissions",
        "layer_summary": "PCIO descriptive aggregation",
        "question_summary": "Question means",
        "download_raw": "Download aggregated response CSV",
        "download_summary": "Download descriptive summary JSON",
        "no_responses": "No survey responses are available for this project.",
        "privacy": SCHEMA["privacy_notice"]["en"],
        "scale": "1=strongly disagree/almost never; 5=strongly agree/consistently",
        "required": "Required",
        "select": "Select",
        "choose_options": "Choose one or more",
        "save_first": "Save the company profile before opening the survey.",
        "descriptive_only": "This tab provides quick descriptive aggregation. Open Analysis and Case Report for reliability, validity, correlation, regression, and reporting.",
        "analysis_source": "Data source",
        "saved_project": "Analyse a saved project",
        "upload_files": "Upload profile JSON + response CSV files",
        "profile_json": "Company profile JSON",
        "response_csvs": "Technician response CSV files",
        "run_analysis": "Generate complete analysis package",
        "analysis_ready": "Analysis complete",
        "data_quality": "Data quality",
        "reliability": "Cronbach's alpha reliability",
        "validity": "KMO / Bartlett validity",
        "group_difference": "Group-difference tests",
        "correlation": "Pearson correlation matrix",
        "regression": "Multiple linear regression",
        "business_reading": "Company-specific business interpretation",
        "case_report": "PCIO Implementation Case Analysis for Your Company",
        "decision_support": "Risk, KPI, and ROI",
        "risk_matrix": "Dynamic 4×4 Risk Matrix",
        "risk_register": "Priority Risks and Mitigations",
        "kpi_dashboard": "Personalised KPI Dashboard",
        "roi_calculator": "Rapid ROI Estimate",
        "roi_assumptions": "ROI planning assumptions (editable)",
        "investment": "One-time investment",
        "annual_value": "Annual addressable value",
        "annual_cost": "Added annual operating cost",
        "improvement_low": "Expected improvement low (%)",
        "improvement_high": "Expected improvement high (%)",
        "currency": "Currency",
        "high_risks": "High and critical risks",
        "kpi_count": "Recommended KPIs",
        "payback": "Simple payback",
        "annual_net_benefit": "Annual net-benefit range",
        "download_analysis": "Download analysis JSON",
        "download_excel": "Download SPSS-style analysis Excel",
        "download_report": "Download bilingual case report Markdown",
        "download_decision": "Download risk/KPI/ROI JSON",
        "download_decision_excel": "Download risk/KPI/ROI Excel",
        "download_package": "Download complete analysis ZIP",
        "need_files": "Upload one company profile JSON and at least one response CSV.",
        "analysis_failed": "Analysis failed: ",
        "sample": "Valid sample",
        "kmo": "KMO",
        "performance": "Overall production performance",
    },
}

LAYER_LABELS = {
    "zh": {
        "P": "P 感知层：设备与现场数据",
        "C": "C 连接层：数据传输与获取",
        "I": "I 集成层：追溯、口径与工作流",
        "O": "O 优化层：数据驱动改善",
        "H": "人机协同：工具、培训与协作",
        "R": "生产绩效感知",
        "B": "障碍、优先级与开放题",
    },
    "en": {
        "P": "P Perception: assets and shop-floor data",
        "C": "C Connectivity: data movement and access",
        "I": "I Integration: traceability, definitions, and workflows",
        "O": "O Optimisation: data-driven improvement",
        "H": "Human-machine collaboration: tools, training, and teamwork",
        "R": "Perceived production performance",
        "B": "Barriers, priorities, and open questions",
    },
}


def label(item: dict[str, Any], language: str) -> str:
    return item[language]


def option_items(option_name: str) -> list[dict[str, str]]:
    return SCHEMA["options"][option_name]


def option_label_map(option_name: str, language: str) -> dict[str, str]:
    return {item["code"]: item[language] for item in option_items(option_name)}


def render_field(field: dict[str, Any], language: str, prefix: str) -> Any:
    field_id = field["id"]
    key = f"{prefix}_{field_id}"
    caption = label(field, language)
    if field.get("required"):
        caption += " *"
    help_text = field.get(f"help_{language}")
    field_type = field["type"]
    if field_type == "text":
        return st.text_input(caption, key=key, help=help_text)
    if field_type == "textarea":
        return st.text_area(caption, key=key, help=help_text)
    if field_type == "integer":
        return st.number_input(
            caption,
            min_value=int(field.get("min", 0)),
            max_value=int(field.get("max", 1000000)),
            value=int(field.get("min", 0)),
            step=1,
            key=key,
            help=help_text,
        )
    options = option_items(field["options"])
    codes = [item["code"] for item in options]
    labels = option_label_map(field["options"], language)
    if field_type == "select":
        return st.selectbox(
            caption,
            options=codes,
            index=None,
            placeholder=TEXT[language]["select"],
            format_func=lambda value: labels[value],
            key=key,
            help=help_text,
        )
    if field_type == "multiselect":
        return st.multiselect(
            caption,
            options=codes,
            format_func=lambda value: labels[value],
            max_selections=field.get("max_items"),
            placeholder=TEXT[language]["choose_options"],
            key=key,
            help=help_text,
        )
    raise ValueError(f"Unsupported field type: {field_type}")


def show_errors(errors: list[str], language: str) -> None:
    st.error(TEXT[language]["validation"] + "\n\n- " + "\n- ".join(errors))


def profile_view(language: str) -> None:
    st.subheader(TEXT[language]["profile_tab"])
    with st.form("company_profile_form"):
        profile: dict[str, Any] = {}
        left, right = st.columns(2)
        for index, field in enumerate(SCHEMA["profile_fields"]):
            target = left if index % 2 == 0 else right
            with target:
                profile[field["id"]] = render_field(field, language, "profile")
        submitted = st.form_submit_button(TEXT[language]["save_profile"], type="primary")
    if submitted:
        errors = validate_profile(profile, SCHEMA)
        if errors:
            show_errors(errors, language)
        else:
            target = save_profile(profile, SCHEMA)
            st.session_state["active_project_code"] = profile["project_code"]
            st.success(TEXT[language]["profile_saved"])
            st.caption(str(target.relative_to(ROOT)))


def project_loader(language: str, key_prefix: str) -> tuple[str, dict[str, Any] | None]:
    default_code = st.session_state.get("active_project_code", "")
    code = st.text_input(TEXT[language]["project_code"], value=default_code, key=f"{key_prefix}_code")
    if not code:
        return "", None
    try:
        profile = load_profile(code)
    except (FileNotFoundError, ValueError):
        st.warning(TEXT[language]["project_not_found"])
        return code, None
    st.session_state["active_project_code"] = profile["project_code"]
    return profile["project_code"], profile


def survey_view(language: str) -> None:
    st.subheader(TEXT[language]["survey_tab"])
    project_code, profile = project_loader(language, "survey_project")
    if not profile:
        st.info(TEXT[language]["save_first"])
        return
    with st.expander(TEXT[language]["profile_summary"], expanded=False):
        st.json(profile)
    questions = selected_questions(SCHEMA, profile)
    st.info(TEXT[language]["instrument_note"])
    st.caption(TEXT[language]["privacy"])
    st.caption(TEXT[language]["scale"])

    with st.form("technician_survey_form"):
        st.markdown(f"#### {TEXT[language]['respondent']}")
        respondent: dict[str, Any] = {}
        respondent_columns = st.columns(3)
        for index, field in enumerate(SCHEMA["respondent_fields"]):
            with respondent_columns[index % 3]:
                respondent[field["id"]] = render_field(field, language, "respondent")

        answers: dict[str, Any] = {}
        section_codes = ["P", "C", "I", "O", "H", "B"]
        section_tabs = st.tabs(
            [
                f"{code} · {LAYER_LABELS[language][code]}"
                for code in section_codes
            ]
        )
        for section_code, tab in zip(section_codes, section_tabs):
            section_questions = [
                question
                for question in questions
                if question.get("section", question["pcio_layer"]) == section_code
            ]
            with tab:
                st.caption(
                    (
                        f"本模块 {len(section_questions)} 题"
                        if language == "zh"
                        else f"{len(section_questions)} items in this module"
                    )
                )
                for question in section_questions:
                    question_label = f"`{question['id']}` {question[language]}"
                    if question.get("kind") == "scenario":
                        question_label += " · " + (
                            "情景题" if language == "zh" else "Scenario"
                        )
                    if question.get("analysis_role") == "attention":
                        question_label += " · " + (
                            "注意力检测" if language == "zh" else "Attention check"
                        )
                    question_type = question["type"]
                    if question_type == "likert":
                        choices: list[Any] = [1, 2, 3, 4, 5]
                        if question.get("allow_na"):
                            choices.append("NA")
                        answers[question["id"]] = st.selectbox(
                            question_label,
                            options=choices,
                            index=None,
                            placeholder=TEXT[language]["select"],
                            format_func=lambda value: (
                                TEXT[language]["not_applicable"]
                                if value == "NA"
                                else str(value)
                            ),
                            key=f"answer_{question['id']}",
                        )
                    elif question_type == "multiselect":
                        option_map = option_label_map(question["options"], language)
                        answers[question["id"]] = st.multiselect(
                            question_label,
                            options=list(option_map),
                            format_func=lambda value, labels=option_map: labels[value],
                            max_selections=question.get("max_items"),
                            key=f"answer_{question['id']}",
                        )
                    elif question_type == "ranking":
                        option_map = option_label_map(question["options"], language)
                        answers[question["id"]] = st.multiselect(
                            question_label,
                            options=list(option_map),
                            format_func=lambda value, labels=option_map: labels[value],
                            max_selections=question["rank_count"],
                            help=TEXT[language]["rank_help"].format(
                                count=question["rank_count"]
                            ),
                            key=f"answer_{question['id']}",
                        )
                    else:
                        answers[question["id"]] = st.text_area(
                            question_label,
                            key=f"answer_{question['id']}",
                        )
        submitted = st.form_submit_button(TEXT[language]["submit"], type="primary")

    if submitted:
        errors = validate_response(respondent, answers, profile, SCHEMA)
        if errors:
            show_errors(errors, language)
            return
        row = flatten_response(profile, respondent, answers, SCHEMA)
        append_response(row, SCHEMA)
        st.success(TEXT[language]["submitted"].format(code=row["respondent_code"]))


def aggregate_view(language: str) -> None:
    st.subheader(TEXT[language]["aggregate_tab"])
    project_code, profile = project_loader(language, "aggregate_project")
    if not profile:
        return
    rows = read_responses(project_code)
    st.metric(TEXT[language]["responses"], len(rows))
    if not rows:
        st.info(TEXT[language]["no_responses"])
        return
    summary = aggregate_responses(rows, SCHEMA)
    st.caption(TEXT[language]["descriptive_only"])
    st.markdown(f"#### {TEXT[language]['layer_summary']}")
    layer_rows = []
    for item in summary["layer_summary"]:
        layer_rows.append(
            {
                ("层级" if language == "zh" else "Layer"): LAYER_LABELS[language].get(
                    item["pcio_layer"], item["pcio_layer"]
                ),
                ("有效题项响应" if language == "zh" else "Valid item responses"): item[
                    "n_item_responses"
                ],
                ("均值" if language == "zh" else "Mean"): item["mean"],
            }
        )
    st.dataframe(layer_rows, use_container_width=True, hide_index=True)

    st.markdown(f"#### {TEXT[language]['question_summary']}")
    question_rows = []
    for item in summary["question_summary"]:
        question_rows.append(
            {
                "ID": item["question_id"],
                ("层级" if language == "zh" else "Layer"): item["pcio_layer"],
                "n": item["n"],
                ("均值" if language == "zh" else "Mean"): item["mean"],
                ("题目" if language == "zh" else "Question"): item[language],
            }
        )
    st.dataframe(question_rows, use_container_width=True, hide_index=True)

    left, right = st.columns(2)
    with left:
        st.download_button(
            TEXT[language]["download_raw"],
            data=rows_to_csv_bytes(rows, SCHEMA),
            file_name=f"{project_code}_pcio_responses.csv",
            mime="text/csv",
        )
    with right:
        st.download_button(
            TEXT[language]["download_summary"],
            data=json.dumps(summary, ensure_ascii=False, indent=2).encode("utf-8"),
            file_name=f"{project_code}_pcio_phase2_summary.json",
            mime="application/json",
        )


def roi_input_form(profile: dict[str, Any], language: str) -> dict[str, Any]:
    defaults = profile_roi_input_defaults(profile)
    project_key = str(profile.get("project_code", "default")).strip() or "default"
    with st.expander(TEXT[language]["roi_assumptions"], expanded=False):
        st.caption(
            defaults[
                "assumption_note_zh" if language == "zh" else "assumption_note_en"
            ]
        )
        currency = st.selectbox(
            TEXT[language]["currency"],
            ["CNY", "USD", "EUR"],
            index=0,
            key=f"roi_currency_{project_key}",
        )
        row_one = st.columns(3)
        investment = row_one[0].number_input(
            TEXT[language]["investment"],
            min_value=0.0,
            value=float(defaults["investment"]),
            step=10000.0,
            key=f"roi_investment_{project_key}",
        )
        annual_value = row_one[1].number_input(
            TEXT[language]["annual_value"],
            min_value=0.0,
            value=float(defaults["annual_addressable_value"]),
            step=50000.0,
            key=f"roi_annual_value_{project_key}",
        )
        annual_cost = row_one[2].number_input(
            TEXT[language]["annual_cost"],
            min_value=0.0,
            value=float(defaults["annual_operating_cost"]),
            step=5000.0,
            key=f"roi_annual_cost_{project_key}",
        )
        row_two = st.columns(2)
        improvement_low = row_two[0].number_input(
            TEXT[language]["improvement_low"],
            min_value=0.0,
            max_value=100.0,
            value=float(defaults["improvement_low_pct"]),
            step=0.5,
            key=f"roi_improvement_low_{project_key}",
        )
        improvement_high = row_two[1].number_input(
            TEXT[language]["improvement_high"],
            min_value=0.0,
            max_value=100.0,
            value=max(float(defaults["improvement_high_pct"]), improvement_low),
            step=0.5,
            key=f"roi_improvement_high_{project_key}",
        )
    return {
        "currency": currency,
        "investment": investment,
        "annual_addressable_value": annual_value,
        "annual_operating_cost": annual_cost,
        "improvement_low_pct": improvement_low,
        "improvement_high_pct": max(improvement_low, improvement_high),
        "horizon_years": 3,
        "source": "streamlit_user_input",
        "assumption_note_zh": "用户可编辑的规划假设；需由财务与业务负责人确认。",
        "assumption_note_en": "Editable planning assumptions subject to finance and business validation.",
    }


def risk_matrix_html(decision: dict[str, Any], language: str) -> str:
    matrix = decision["risk"]["matrix"]
    headers = "".join(
        f"<div class='risk-head'>{'影响' if language == 'zh' else 'Impact'} {impact}</div>"
        for impact in range(1, 5)
    )
    rows = []
    for matrix_row in matrix:
        cells = []
        for cell in matrix_row["cells"]:
            ids = "<br>".join(cell["risk_ids"]) or "&nbsp;"
            cells.append(
                f"<div class='risk-cell' style='background:{cell['color']}'>{ids}</div>"
            )
        rows.append(
            f"<div class='risk-axis'>{'概率' if language == 'zh' else 'Likelihood'} "
            f"{matrix_row['likelihood']}</div>{''.join(cells)}"
        )
    return (
        "<style>"
        ".risk-grid{display:grid;grid-template-columns:minmax(82px,1.1fr) repeat(4,minmax(80px,1fr));"
        "gap:4px;margin:8px 0 16px}.risk-head,.risk-axis{background:#16324f;color:white;"
        "padding:10px 6px;text-align:center;font-weight:700}.risk-cell{min-height:62px;padding:10px 6px;"
        "text-align:center;color:#17212b;font-weight:700;border:1px solid #d8dee7}"
        "@media(max-width:700px){.risk-grid{grid-template-columns:72px repeat(4,minmax(60px,1fr));"
        "font-size:12px}.risk-cell{min-height:54px;padding:7px 3px}}</style>"
        f"<div class='risk-grid'><div class='risk-head'>4×4</div>{headers}{''.join(rows)}</div>"
    )


def pcio_score_html(scale_rows: list[dict[str, Any]], language: str) -> str:
    colours = {"P": "#0b756f", "C": "#3f6f9f", "I": "#b67a12", "O": "#bf4e45"}
    rows = []
    for row in scale_rows:
        layer = row["variable"]
        if layer not in colours:
            continue
        value = float(row["mean"])
        layer_name = ANALYSIS_LAYER_LABELS[layer][language]
        rows.append(
            "<div class='pcio-score-row'>"
            f"<strong>{layer_name}</strong>"
            "<div class='pcio-score-track'>"
            f"<div class='pcio-score-fill' style='width:{value / 5 * 100:.1f}%;"
            f"background:{colours[layer]}'></div></div>"
            f"<span>{value:.2f}/5</span></div>"
        )
    return (
        "<style>.pcio-score-list{display:grid;gap:10px;margin:8px 0 20px}"
        ".pcio-score-row{display:grid;grid-template-columns:minmax(150px,1.6fr) "
        "minmax(180px,4fr) 64px;gap:12px;align-items:center}"
        ".pcio-score-track{height:13px;background:#e2e8ec;border:1px solid #d4dce1}"
        ".pcio-score-fill{height:100%}"
        ".pcio-score-row span{text-align:right;font-variant-numeric:tabular-nums}"
        "@media(max-width:700px){.pcio-score-row{grid-template-columns:105px 1fr 54px;"
        "gap:7px;font-size:12px}}</style>"
        f"<div class='pcio-score-list'>{''.join(rows)}</div>"
    )


def _money(value: float | None, currency: str) -> str:
    return "N/A" if value is None else f"{currency} {value:,.0f}"


def _run_analysis_from_source(
    language: str,
) -> tuple[dict[str, Any], Any, dict[str, Any]] | None:
    source = st.radio(
        TEXT[language]["analysis_source"],
        ["saved", "upload"],
        format_func=lambda value: (
            TEXT[language]["saved_project"]
            if value == "saved"
            else TEXT[language]["upload_files"]
        ),
        horizontal=True,
        key="analysis_source",
    )
    if source == "saved":
        project_code, profile = project_loader(language, "analysis_project")
        if not profile:
            return None
        rows = read_responses(project_code)
        if not rows:
            st.info(TEXT[language]["no_responses"])
            return None
        responses = pd.DataFrame(rows)
    else:
        profile_file = st.file_uploader(
            TEXT[language]["profile_json"], type=["json"], key="analysis_profile_upload"
        )
        response_files = st.file_uploader(
            TEXT[language]["response_csvs"],
            type=["csv"],
            accept_multiple_files=True,
            key="analysis_response_uploads",
        )
        if not profile_file or not response_files:
            st.info(TEXT[language]["need_files"])
            return None
        profile = read_profile(profile_file.getvalue())
        responses = combine_response_csvs([item.getvalue() for item in response_files])
    roi_inputs = roi_input_form(profile, language)
    if not st.button(TEXT[language]["run_analysis"], type="primary", key="run_phase3"):
        return None
    analysis = analyze_pcio_survey(profile, responses, SCHEMA)
    return profile, analysis, roi_inputs


def analysis_view(language: str) -> None:
    st.subheader(TEXT[language]["analysis_tab"])
    try:
        result = _run_analysis_from_source(language)
    except Exception as exc:
        st.error(TEXT[language]["analysis_failed"] + str(exc))
        return
    if result:
        profile, analysis, roi_inputs = result
        report = generate_bilingual_report(profile, analysis, SCHEMA)
        decision = generate_decision_support(
            profile, analysis, roi_inputs=roi_inputs, schema=SCHEMA
        )
        st.session_state["phase3_profile"] = profile
        st.session_state["phase3_analysis"] = analysis
        st.session_state["phase3_report"] = report
        st.session_state["phase4_decision"] = decision
    elif "phase3_analysis" not in st.session_state:
        return

    profile = st.session_state["phase3_profile"]
    analysis = st.session_state["phase3_analysis"]
    report = st.session_state["phase3_report"]
    decision = st.session_state.get("phase4_decision")
    if decision is None:
        decision = generate_decision_support(profile, analysis, schema=SCHEMA)
        st.session_state["phase4_decision"] = decision
    st.success(TEXT[language]["analysis_ready"])
    scale_rows = analysis["tables"]["scale_descriptives"]
    scale_map = {row["variable"]: row["mean"] for row in scale_rows}
    metrics = st.columns(3)
    metrics[0].metric(TEXT[language]["sample"], analysis["data_quality"]["retained_rows"])
    metrics[1].metric(
        TEXT[language]["kmo"],
        f"{analysis['tables']['kmo_bartlett'].get('kmo_overall') or 0:.3f}",
    )
    metrics[2].metric(
        TEXT[language]["performance"],
        f"{scale_map.get('PERF_OVERALL', 0):.2f}/5",
    )

    st.markdown(f"#### {TEXT[language]['data_quality']}")
    quality_rows = [
        {"metric": key, "value": value}
        for key, value in analysis["data_quality"].items()
        if key != "warnings"
    ]
    st.dataframe(quality_rows, use_container_width=True, hide_index=True)
    for warning in analysis["data_quality"].get("warnings", []):
        st.warning(localised_warning(warning, language))

    pcio_rows = [
        {
            ("层级" if language == "zh" else "Layer"): ANALYSIS_LAYER_LABELS[row["variable"]][
                language
            ],
            ("均值" if language == "zh" else "Mean"): row["mean"],
            ("标准差" if language == "zh" else "Std. deviation"): row["std_dev"],
            "n": row["n"],
        }
        for row in scale_rows
        if row["variable"] in {"P", "C", "I", "O", "H"}
    ]
    st.dataframe(pcio_rows, use_container_width=True, hide_index=True)
    st.markdown(f"#### {TEXT[language]['score_overview']}")
    st.markdown(pcio_score_html(scale_rows, language), unsafe_allow_html=True)

    left, right = st.columns(2)
    with left:
        st.markdown(f"#### {TEXT[language]['reliability']}")
        st.dataframe(
            analysis["tables"]["reliability"], use_container_width=True, hide_index=True
        )
    with right:
        st.markdown(f"#### {TEXT[language]['validity']}")
        kmo = analysis["tables"]["kmo_bartlett"]
        st.dataframe(
            [
                {
                    "KMO": kmo.get("kmo_overall"),
                    "Bartlett χ²": kmo.get("bartlett_chi_square"),
                    "df": kmo.get("bartlett_df"),
                    "p": kmo.get("bartlett_p"),
                    "n": kmo.get("n"),
                }
            ],
            use_container_width=True,
            hide_index=True,
        )

    st.markdown(f"#### {TEXT[language]['group_difference']}")
    group_rows = []
    for row in analysis["tables"]["group_differences"]:
        group_rows.append(
            {
                ("分组变量" if language == "zh" else "Grouping variable"): row[
                    "group_variable"
                ],
                ("结果变量" if language == "zh" else "Outcome"): row["outcome"],
                ("检验" if language == "zh" else "Test"): row["test"],
                ("状态" if language == "zh" else "Status"): row["status"],
                "n": row["n_total"],
                ("统计量" if language == "zh" else "Statistic"): row["statistic"],
                "p": row["p_value"],
                "FDR q": row["p_fdr_bh"],
                ("效应量" if language == "zh" else "Effect size"): row[
                    "effect_size"
                ],
            }
        )
    st.dataframe(group_rows, use_container_width=True, hide_index=True)

    st.markdown(f"#### {TEXT[language]['correlation']}")
    st.dataframe(
        analysis["tables"]["correlations"]["r_matrix"],
        use_container_width=True,
        hide_index=True,
    )

    st.markdown(f"#### {TEXT[language]['regression']}")
    model_rows = []
    for model in analysis["tables"]["regressions"]:
        model_rows.append(
            {
                ("因变量" if language == "zh" else "Dependent"): model["dependent"],
                ("状态" if language == "zh" else "Status"): model["status"],
                "n": model["n"],
                "R²": model.get("model", {}).get("r_squared"),
                ("调整R²" if language == "zh" else "Adjusted R²"): model.get(
                    "model", {}
                ).get("adjusted_r_squared"),
                "F p": model.get("model", {}).get("f_p_value"),
                "Max VIF": model.get("model", {}).get("max_vif"),
            }
        )
    st.dataframe(model_rows, use_container_width=True, hide_index=True)

    st.markdown(f"#### {TEXT[language]['business_reading']}")
    for item in analysis["interpretation"][language]:
        st.write("- " + item)

    st.markdown("---")
    st.markdown(f"### {TEXT[language]['decision_support']}")
    st.caption(decision["evidence_boundary"][language])

    risk_rows = decision["risk"]["risks"]
    high_risk_count = sum(
        row["band"] in {"high", "critical"} for row in risk_rows
    )
    roi = decision["roi"]
    payback = roi["payback_range_months"]
    currency = roi["inputs"].get("currency", "CNY")
    roi_scenarios = {row["scenario"]: row for row in roi["scenarios"]}
    decision_metrics = st.columns(4)
    decision_metrics[0].metric(TEXT[language]["high_risks"], high_risk_count)
    decision_metrics[1].metric(TEXT[language]["kpi_count"], len(decision["kpis"]))
    decision_metrics[2].metric(
        TEXT[language]["payback"],
        (
            f"{payback['optimistic']:.1f}-{payback['conservative']:.1f} "
            + ("个月" if language == "zh" else "months")
            if payback["optimistic"] is not None
            else "N/A"
        ),
    )
    decision_metrics[3].metric(
        TEXT[language]["annual_net_benefit"],
        (
            f"{_money(roi_scenarios['conservative']['annual_net_benefit'], currency)}"
            f" - {_money(roi_scenarios['optimistic']['annual_net_benefit'], currency)}"
        ),
    )

    st.markdown(f"#### {TEXT[language]['risk_matrix']}")
    st.markdown(risk_matrix_html(decision, language), unsafe_allow_html=True)
    st.caption(TEXT[language]["risk_legend"])
    st.markdown(f"#### {TEXT[language]['risk_register']}")
    risk_table = [
        {
            ("排名" if language == "zh" else "Rank"): row["priority_rank"],
            "ID": row["risk_id"],
            ("类别" if language == "zh" else "Category"): row[
                "category_zh" if language == "zh" else "category_en"
            ],
            ("风险" if language == "zh" else "Risk"): row[
                "title_zh" if language == "zh" else "title_en"
            ],
            ("概率" if language == "zh" else "Likelihood"): row["likelihood"],
            ("影响" if language == "zh" else "Impact"): row["impact"],
            ("得分" if language == "zh" else "Score"): row["score"],
            "PDCA": row["pdca_stage"],
            ("缓解措施" if language == "zh" else "Mitigation"): row[
                "mitigation_zh" if language == "zh" else "mitigation_en"
            ],
        }
        for row in risk_rows
    ]
    st.dataframe(risk_table, use_container_width=True, hide_index=True)

    st.markdown(f"#### {TEXT[language]['kpi_dashboard']}")
    kpi_table = [
        {
            ("排名" if language == "zh" else "Rank"): row["priority_rank"],
            ("优先级" if language == "zh" else "Priority"): row["priority"],
            "PCIO": row["pcio_layer"],
            "KPI": row["name_zh" if language == "zh" else "name_en"],
            ("当前成熟度" if language == "zh" else "Current maturity"): row[
                "current_maturity_score"
            ],
            ("目标区间" if language == "zh" else "Target range"): (
                f"{row['target_low']}-{row['target_high']} {row['unit']}"
            ),
            ("预期结果" if language == "zh" else "Expected outcome"): (
                row["expected_outcome_zh" if language == "zh" else "expected_outcome_en"]
                or row["rationale_zh" if language == "zh" else "rationale_en"]
            ),
            ("证据" if language == "zh" else "Evidence"): row["evidence"],
        }
        for row in decision["kpis"]
    ]
    st.dataframe(kpi_table, use_container_width=True, hide_index=True)

    st.markdown(f"#### {TEXT[language]['roi_calculator']}")
    roi_table = [
        {
            ("情景" if language == "zh" else "Scenario"): row["scenario"],
            ("改善率" if language == "zh" else "Improvement"): f"{row['improvement_pct']:.1f}%",
            ("年度毛收益" if language == "zh" else "Annual gross benefit"): _money(
                row["annual_gross_benefit"], currency
            ),
            ("年度净收益" if language == "zh" else "Annual net benefit"): _money(
                row["annual_net_benefit"], currency
            ),
            ("回收期（月）" if language == "zh" else "Payback months"): row[
                "payback_months"
            ],
            ("三年ROI" if language == "zh" else "Three-year ROI"): (
                f"{row.get('roi_3y_pct', 0):.1f}%"
                if row.get("roi_3y_pct") is not None
                else "N/A"
            ),
        }
        for row in roi["scenarios"]
    ]
    st.dataframe(roi_table, use_container_width=True, hide_index=True)
    st.caption(roi["interpretation_zh" if language == "zh" else "interpretation_en"])

    analysis_json = json.dumps(analysis, ensure_ascii=False, indent=2).encode("utf-8")
    excel_bytes = analysis_excel_bytes(analysis)
    report_bytes = report.encode("utf-8")
    decision_json = json.dumps(decision, ensure_ascii=False, indent=2).encode("utf-8")
    decision_excel = decision_support_excel_bytes(decision)
    complete_zip = complete_package_zip_bytes(
        profile, analysis, report, decision, excel_bytes
    )
    st.markdown(f"### {TEXT[language]['export_center']}")
    st.caption(TEXT[language]["export_note"])
    with st.container(border=True):
        st.download_button(
            TEXT[language]["download_package"],
            complete_zip,
            file_name=f"{profile['project_code']}_PCIO_complete_analysis_package.zip",
            mime="application/zip",
            type="primary",
            use_container_width=True,
        )
        download_columns = st.columns(3)
        download_columns[0].download_button(
            TEXT[language]["download_analysis"],
            analysis_json,
            file_name=f"{profile['project_code']}_pcio_analysis.json",
            mime="application/json",
            use_container_width=True,
        )
        download_columns[1].download_button(
            TEXT[language]["download_excel"],
            excel_bytes,
            file_name=f"{profile['project_code']}_pcio_spss_style_tables.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )
        download_columns[2].download_button(
            TEXT[language]["download_report"],
            report_bytes,
            file_name=f"{profile['project_code']}_PCIO_case_report_bilingual.md",
            mime="text/markdown",
            use_container_width=True,
        )
        decision_downloads = st.columns(2)
        decision_downloads[0].download_button(
            TEXT[language]["download_decision"],
            decision_json,
            file_name=f"{profile['project_code']}_pcio_risk_kpi_roi.json",
            mime="application/json",
            use_container_width=True,
        )
        decision_downloads[1].download_button(
            TEXT[language]["download_decision_excel"],
            decision_excel,
            file_name=f"{profile['project_code']}_pcio_risk_kpi_roi.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )
    with st.expander(TEXT[language]["case_report"], expanded=True):
        st.markdown(report)


st.set_page_config(
    page_title="PCIO Toolkit",
    page_icon="⚙",
    layout="wide",
    initial_sidebar_state="expanded",
)
st.markdown(
    """
    <style>
    :root {--pcio-navy:#17324d;--pcio-teal:#0b756f;--pcio-gold:#b67a12;--pcio-coral:#bf4e45;}
    .stApp {background:#f5f7f8;}
    .block-container {max-width: 1180px; padding-top: 1.3rem; padding-bottom: 4rem;}
    h1, h2, h3, h4 {letter-spacing: 0;}
    .pcio-header {background:var(--pcio-navy); color:white; padding:24px 28px; border-left:7px solid var(--pcio-teal); margin-bottom:14px;}
    .pcio-header h1 {font-size:32px; line-height:1.2; margin:0 0 7px; color:white;}
    .pcio-header p {margin:0; color:#dce6ec; font-size:15px;}
    div[data-testid="stForm"] {background:white; border: 1px solid #d8dee7; border-radius: 6px; padding: 1.25rem;}
    div[data-testid="stMetric"] {background:white; border:1px solid #d8dee7; border-top:3px solid var(--pcio-teal); padding:12px;}
    div[role="radiogroup"] {gap:6px;}
    div[data-testid="stDownloadButton"] button {min-height:42px;}
    .stAlert {border-radius: 6px;}
    [data-testid="stSidebar"] {border-right:1px solid #d8dee7;}
    @media(max-width:700px) {
      .block-container {padding-left:0.8rem; padding-right:0.8rem; padding-top:0.8rem;}
      .pcio-header {padding:18px 16px;}
      .pcio-header h1 {font-size:24px; overflow-wrap:anywhere;}
      div[data-testid="stHorizontalBlock"] {gap:0.55rem;}
    }
    </style>
    """,
    unsafe_allow_html=True,
)

language = st.sidebar.radio(
    TEXT["zh"]["language"] + " / Language",
    ["zh", "en"],
    horizontal=True,
    key="interface_language",
)
st.sidebar.markdown("### PCIO Toolkit")
st.sidebar.caption(TEXT[language]["workflow_help"])
st.sidebar.info(TEXT[language]["sidebar_note"])
st.markdown(
    f"""
    <section class="pcio-header">
      <h1>{TEXT[language]["page_title"]}</h1>
      <p>{TEXT[language]["page_subtitle"]}</p>
    </section>
    """,
    unsafe_allow_html=True,
)
st.warning(TEXT[language]["privacy"], icon="⚠")

navigation = {
    "profile": TEXT[language]["workflow_profile"],
    "survey": TEXT[language]["workflow_survey"],
    "aggregate": TEXT[language]["workflow_aggregate"],
    "analysis": TEXT[language]["workflow_analysis"],
}
current_view = st.radio(
    TEXT[language]["workflow"],
    options=list(navigation),
    format_func=lambda value: navigation[value],
    horizontal=True,
    label_visibility="collapsed",
    key="workflow_navigation",
)
if current_view == "profile":
    profile_view(language)
elif current_view == "survey":
    survey_view(language)
elif current_view == "aggregate":
    aggregate_view(language)
else:
    analysis_view(language)

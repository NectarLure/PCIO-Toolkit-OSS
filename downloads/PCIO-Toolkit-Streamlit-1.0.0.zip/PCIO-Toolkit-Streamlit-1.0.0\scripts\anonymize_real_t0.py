﻿from __future__ import annotations

import hashlib
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Mm, Pt


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "data" / "real_cases_T0_anonymized"

SOURCE_HASHES = {
    "survey_csv": "ACE09633E33A9EB5F0DCBE181AD637529B99378DFAD38CA027BF2DD69E28AAEA",
    "questionnaire": "5F37A861600506ADC5D7E78CCB0F1B64D21EB2AF60F7249C43DED6FF8F9386E5",
    "case_t": "533FB96EC18F64B65B18F6C94C9BB9D5E4495247B34AF526B8FA5EC37EE5C4F9",
    "case_p": "1C07E1B4BCFE44D3DADD22C5C5D8A13FCF87E1A4BEA6F7793A087405234C7A21",
}

SURVEY_ITEMS = [
    "Quality_Imp",
    "Cost_Red",
    "Eff_Imp",
    "Flex_Imp",
    "IoT_Inf",
    "Sensor_Inf",
    "BigData_Inf",
    "AI_Inf",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def find_sources() -> dict[str, Path]:
    wanted = set(SOURCE_HASHES.values())
    found: dict[str, Path] = {}
    output_resolved = OUTPUT_DIR.resolve()

    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        try:
            path.resolve().relative_to(output_resolved)
            continue
        except ValueError:
            pass
        if path.suffix.lower() not in {".csv", ".docx"}:
            continue
        file_hash = sha256(path)
        if file_hash not in wanted:
            continue
        key = next(name for name, value in SOURCE_HASHES.items() if value == file_hash)
        found[key] = path

    missing = sorted(set(SOURCE_HASHES) - set(found))
    if missing:
        raise FileNotFoundError(f"Missing expected source files: {missing}")
    return found


def age_group(value: int) -> str:
    if value <= 34:
        return "25-34"
    if value <= 44:
        return "35-44"
    return "45+"


def experience_group(value: int) -> str:
    if value <= 3:
        return "1-3"
    if value <= 5:
        return "4-5"
    if value <= 10:
        return "6-10"
    return "11+"


def anonymize_survey(source: Path) -> dict[str, Path]:
    frame = pd.read_csv(source, encoding="utf-8-sig")
    frame.columns = [str(column).strip() for column in frame.columns]

    required = {
        "ID",
        "Company",
        "Gender",
        "Position",
        "Education",
        "StartedProject",
        "Age",
        "Experience",
        *SURVEY_ITEMS,
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Survey columns missing: {missing}")

    group_counts = frame["Company"].value_counts().to_dict()
    if sorted(group_counts.values()) != [12, 19, 21]:
        raise ValueError(f"Unexpected company group counts: {group_counts}")

    label_by_count = {
        12: ("Case T", "案例T：罐区运营场景", "T"),
        19: ("Case P", "案例P：流程生产型企业", "P"),
        21: ("Other organization", "其他组织（未纳入两案例标签）", "O"),
    }
    company_map = {
        source_label: label_by_count[count]
        for source_label, count in group_counts.items()
    }

    counters: defaultdict[str, int] = defaultdict(int)
    respondent_ids: list[str] = []
    cases: list[str] = []
    case_descriptions: list[str] = []
    for source_label in frame["Company"]:
        case, description, prefix = company_map[source_label]
        counters[prefix] += 1
        respondent_ids.append(f"{prefix}{counters[prefix]:03d}")
        cases.append(case)
        case_descriptions.append(description)

    anonymized = pd.DataFrame(
        {
            "Respondent_ID": respondent_ids,
            "Case": cases,
            "Case_Description": case_descriptions,
            "Gender": frame["Gender"],
            "Position": frame["Position"],
            "Education": frame["Education"],
            "StartedProject": frame["StartedProject"],
            "Age_Group": frame["Age"].map(lambda value: age_group(int(value))),
            "Experience_Group": frame["Experience"].map(
                lambda value: experience_group(int(value))
            ),
        }
    )
    for item in SURVEY_ITEMS:
        anonymized[item] = frame[item]

    controlled_path = OUTPUT_DIR / "T0_survey_controlled_anonymized.csv"
    anonymized.to_csv(controlled_path, index=False, encoding="utf-8-sig")

    pt_path = OUTPUT_DIR / "T0_survey_cases_PT_controlled_anonymized.csv"
    anonymized[anonymized["Case"].isin(["Case P", "Case T"])].to_csv(
        pt_path, index=False, encoding="utf-8-sig"
    )

    paper_fields = [
        "Respondent_ID",
        "Case",
        "Case_Description",
        "Position",
        "StartedProject",
        *SURVEY_ITEMS,
    ]
    paper_path = OUTPUT_DIR / "T0_survey_paper_analysis.csv"
    anonymized[paper_fields].to_csv(paper_path, index=False, encoding="utf-8-sig")

    aggregate_rows: list[dict[str, object]] = []
    for (case, description), group in anonymized.groupby(
        ["Case", "Case_Description"], sort=True
    ):
        row: dict[str, object] = {
            "Case": case,
            "Case_Description": description,
            "N": len(group),
            "StartedProject_Yes_N": int((group["StartedProject"] == "Yes").sum()),
        }
        for item in SURVEY_ITEMS:
            row[f"{item}_Mean"] = round(float(group[item].mean()), 3)
        aggregate_rows.append(row)

    summary_path = OUTPUT_DIR / "T0_survey_paper_summary.csv"
    pd.DataFrame(aggregate_rows).to_csv(
        summary_path, index=False, encoding="utf-8-sig"
    )

    return {
        "controlled": controlled_path,
        "pt_subset": pt_path,
        "paper_analysis": paper_path,
        "paper_summary": summary_path,
    }


def clear_metadata(document: Document, title: str) -> None:
    properties = document.core_properties
    properties.author = ""
    properties.last_modified_by = ""
    properties.title = title
    properties.subject = "真实T0材料脱敏副本"
    properties.keywords = ""
    properties.comments = ""
    properties.category = ""
    properties.identifier = ""
    properties.language = "zh-CN"
    properties.version = ""
    properties.created = datetime(2026, 6, 13)
    properties.modified = datetime(2026, 6, 13)


def replace_paragraph_text(paragraph, text: str) -> None:
    if paragraph.runs:
        paragraph.runs[0].text = text
        for run in paragraph.runs[1:]:
            run.text = ""
    else:
        paragraph.add_run(text)


def anonymize_questionnaire(source: Path) -> Path:
    document = Document(source)
    for paragraph in document.paragraphs:
        text = paragraph.text.strip()
        if "问卷采用匿名形式，姓名可不填" in text:
            replace_paragraph_text(
                paragraph,
                text.replace("问卷采用匿名形式，姓名可不填", "问卷不采集姓名"),
            )
        elif text.startswith("A1. 姓名"):
            replace_paragraph_text(
                paragraph, "A1. 受访者编号：由研究团队生成，不由受访者填写"
            )
        elif text.startswith("A6. 所属具体企业/公司名称"):
            replace_paragraph_text(paragraph, "A6. 场景代码：")
        elif text.startswith("□") and "Other（请指定" in text:
            replace_paragraph_text(
                paragraph,
                "□ Case P（流程生产型企业）  "
                "□ Case T（罐区运营场景）  "
                "□ Other organization",
            )

    clear_metadata(document, "真实T0调查问卷（脱敏版）")
    path = OUTPUT_DIR / "T0_questionnaire_anonymized.docx"
    document.save(path)
    return path


def configure_document(document: Document, title: str) -> None:
    section = document.sections[0]
    section.page_width = Mm(210)
    section.page_height = Mm(297)
    section.top_margin = Mm(20)
    section.bottom_margin = Mm(20)
    section.left_margin = Mm(22)
    section.right_margin = Mm(22)

    normal = document.styles["Normal"]
    normal.font.name = "Arial"
    normal.font.size = Pt(10.5)
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")

    for style_name, font_name, size in [
        ("Title", "黑体", 18),
        ("Heading 1", "黑体", 14),
        ("Heading 2", "黑体", 12),
    ]:
        style = document.styles[style_name]
        style.font.name = "Arial"
        style.font.size = Pt(size)
        style._element.rPr.rFonts.set(qn("w:eastAsia"), font_name)

    clear_metadata(document, title)


def add_title(document: Document, title: str) -> None:
    paragraph = document.add_paragraph()
    paragraph.style = document.styles["Title"]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.add_run(title)


def add_bullets(document: Document, items: list[str]) -> None:
    for item in items:
        document.add_paragraph(item, style="List Bullet")


def add_mapping_table(
    document: Document, headers: tuple[str, str, str], rows: list[tuple[str, str, str]]
) -> None:
    table = document.add_table(rows=1, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    for index, header in enumerate(headers):
        table.rows[0].cells[index].text = header
    for row in rows:
        cells = table.add_row().cells
        for index, value in enumerate(row):
            cells[index].text = value


def build_case_t_document() -> Path:
    title = "案例T：罐区运营场景（真实T0脱敏提炼副本）"
    document = Document()
    configure_document(document, title)
    add_title(document, title)

    document.add_heading("1. 证据性质与边界", level=1)
    document.add_paragraph(
        "本文件由真实罐区场景的T0材料脱敏提炼而成。材料用于识别场景约束、"
        "形成设计需求及检查PCIO Toolkit的情境适配性。它不包含PCIO Toolkit"
        "部署后的T1/T2数据，不支持绩效提升、因果效果、KPI达成或真实ROI结论。"
    )

    document.add_heading("2. 脱敏处理", level=1)
    add_bullets(
        document,
        [
            "删除全部原始HMI/监控系统截图和嵌入媒体。",
            "删除企业名、系统名、日期时间、真实区域名、装卸位编号和现场定位线索。",
            "删除真实设备、仪表、阀门、泵、储罐和测点编号。",
            "删除实时测量值、报警阈值、批次设定量及其他可能暴露运行状态的参数。",
            "仅保留与设计需求相关的概括性功能观察。",
        ],
    )

    document.add_heading("3. 脱敏场景概况", level=1)
    document.add_paragraph(
        "案例T为罐区运营场景。原始材料显示该场景包含多个储存与装卸区域，"
        "并通过泵、阀门、储罐、传感器和集中监控界面支持日常操作。"
        "材料重点涉及总览监控、装卸控制、报警记录、趋势分析和多区域切换。"
    )

    document.add_heading("4. 通用化区域与设备编号", level=1)
    add_mapping_table(
        document,
        ("匿名编号", "通用名称", "保留用途"),
        [
            ("Area 1", "罐区总览与导航区域", "支持全局状态和跨区域切换"),
            ("Area 2", "装卸作业区域", "支持装卸任务和人工确认"),
            ("Area 3", "报警管理区域", "支持报警查看、筛选和确认"),
            ("Area 4", "趋势分析区域", "支持历史趋势和异常追溯"),
            ("Area 5", "储存与转运区域", "支持库存状态和物料转运"),
            ("M01", "储存单元", "液位、温度或压力状态承载"),
            ("M02", "输送单元", "物料转运"),
            ("M03", "阀控单元", "流向切换与隔离"),
            ("M04", "感知单元", "采集液位、温度、压力或流量"),
            ("M05", "装卸接口", "连接装卸任务与批次操作"),
            ("M06", "监控界面", "总览、导航和操作入口"),
            ("M07", "报警模块", "报警记录与人工确认"),
            ("M08", "趋势模块", "实时与历史数据展示"),
        ],
    )
    document.add_paragraph(
        "注：Area 1–Area 5和M01–M08均为本次脱敏生成的通用编号，"
        "不保留与原始现场编号的一一映射。"
    )

    document.add_heading("5. 保留的T0观察", level=1)
    add_bullets(
        document,
        [
            "集中界面使用工艺示意、就地参数和统一导航组织多区域信息。",
            "弹出式控制窗口用于在总览基础上查看或确认局部操作。",
            "报警记录模块包含事件查看、筛选和确认等功能。",
            "趋势模块支持按参数类别查看实时或历史变化。",
            "颜色、符号和高亮状态用于区分运行、停止、报警和当前页面。",
            "多区域、多任务和多测点并存，对信息分层、状态一致性和人工确认提出要求。",
        ],
    )

    document.add_heading("6. 可提炼的设计需求", level=1)
    add_bullets(
        document,
        [
            "诊断结果应能关联到可核查的测点、报警、趋势或操作证据。",
            "人工制品应支持多区域情境配置，同时避免暴露真实现场标识。",
            "高风险操作和阈值调整应保留人工确认与责任边界。",
            "建议应区分感知、连接、集成和优化层级，优先处理基础数据能力。",
            "后续复测应基于经确认的T0基线，而不是把界面状态直接解释为绩效结果。",
        ],
    )

    path = OUTPUT_DIR / "Case_T_tank_area_T0_anonymized.docx"
    document.save(path)
    return path


def build_case_p_document() -> Path:
    title = "案例P：流程生产型企业（真实T0脱敏提炼副本）"
    document = Document()
    configure_document(document, title)
    add_title(document, title)

    document.add_heading("1. 证据性质与边界", level=1)
    document.add_paragraph(
        "本文件由真实流程生产场景的T0材料脱敏提炼而成。材料用于识别过程控制"
        "与数据治理需求，并形成对PCIO Toolkit场景适配性的形成性评价。"
        "它不包含部署后的重复测量，不支持产量、质量、能耗、停机或ROI改善结论。"
    )

    document.add_heading("2. 脱敏处理", level=1)
    add_bullets(
        document,
        [
            "删除全部原始工艺流程图和嵌入媒体。",
            "删除企业名、项目名、原料与产品专名、配方、精细工艺路线和现场位置线索。",
            "删除真实设备、仪表、阀门、泵、储罐、产线和控制回路编号。",
            "删除具体设定值、报警限值、温压流量参数和可还原控制逻辑的细节。",
            "仅保留源材料明确记载的通用过程特征、潜在问题和设计相关建议。",
        ],
    )

    document.add_heading("3. 脱敏场景概况", level=1)
    document.add_paragraph(
        "案例P为多阶段流程生产型企业。原始T0材料涉及反应、蒸发、分离、"
        "物料回收、固液分离、真空公用系统和产品储存等连续或批次单元。"
        "各单元依赖温度、压力、液位、流量和设备状态测量，并存在跨单元联动。"
    )

    document.add_heading("4. 通用化产线、区域与设备编号", level=1)
    add_mapping_table(
        document,
        ("匿名编号", "通用名称", "保留用途"),
        [
            ("Line 1", "反应与配料阶段", "支持配料、温控和批次顺序"),
            ("Line 2", "蒸发与浓缩阶段", "支持多变量协调和能效观察"),
            ("Line 3", "分离与精制阶段", "支持温压控制和质量相关测量"),
            ("Line 4", "物料回收阶段", "支持循环、回收和跨单元衔接"),
            ("Line 5", "固液分离与真空阶段", "支持设备状态和公用系统稳定"),
            ("Area 1", "产品与公用介质储存区域", "支持库存、转运和安全监测"),
            ("M01", "反应单元", "配料、反应和批次控制"),
            ("M02", "蒸发单元", "蒸发、浓缩和液位协调"),
            ("M03", "分离单元", "精制和组分分离"),
            ("M04", "换热单元", "加热、冷却和热量交换"),
            ("M05", "储存单元", "原料、产品或公用介质存储"),
            ("M06", "输送单元", "进料、回流或转运"),
            ("M07", "阀控单元", "调节、切断和联锁"),
            ("M08", "感知单元", "温度、压力、液位、流量或状态测量"),
            ("M09", "固液分离单元", "分离过程和设备状态监测"),
            ("M10", "真空公用单元", "为多个过程单元提供真空条件"),
            ("M11", "控制与监控单元", "顺序控制、报警、趋势和数据记录"),
        ],
    )
    document.add_paragraph(
        "注：Line、Area和M编号均为脱敏标签，不保留与原始产线或设备编号的映射。"
    )

    document.add_heading("5. 保留的T0观察", level=1)
    add_bullets(
        document,
        [
            "多阶段流程之间存在物料、热量、压力和公用系统耦合。",
            "关键控制依赖温度、压力、液位、流量和设备状态测量。",
            "源材料记录的潜在问题包括配料精度、测点不足、控制滞后、联锁完整性、"
            "多变量耦合、结垢维护、振动、真空波动和储存切换风险。",
            "源材料提出的候选改进包括闭环控制、测量冗余、报警联锁、趋势记录、"
            "设备状态监测、数据分析和人工确认。",
            "上述内容是T0问题与建议，不代表相关功能已部署，也不代表改善已经发生。",
        ],
    )

    document.add_heading("6. 可提炼的设计需求", level=1)
    add_bullets(
        document,
        [
            "诊断应先识别感知和连接基础，再讨论跨单元集成或高级优化。",
            "风险项应关联到可核查的测点、联锁、报警、维护或操作证据。",
            "KPI建议必须以现场确认的运营基线为前提，问卷感知分数不能替代基线。",
            "高级控制和自动建议应保留人工确认、回退机制和责任边界。",
            "后续PDCA复测需使用同一口径的T0指标，当前材料不提供T1/T2结果。",
        ],
    )

    path = OUTPUT_DIR / "Case_P_process_manufacturing_T0_anonymized.docx"
    document.save(path)
    return path


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    sources = find_sources()
    generated = anonymize_survey(sources["survey_csv"])
    generated["questionnaire"] = anonymize_questionnaire(sources["questionnaire"])
    generated["case_t"] = build_case_t_document()
    generated["case_p"] = build_case_p_document()

    print("Generated anonymized T0 files:")
    for name, path in generated.items():
        print(f"- {name}: {path.relative_to(ROOT)} | SHA256={sha256(path)}")


if __name__ == "__main__":
    main()


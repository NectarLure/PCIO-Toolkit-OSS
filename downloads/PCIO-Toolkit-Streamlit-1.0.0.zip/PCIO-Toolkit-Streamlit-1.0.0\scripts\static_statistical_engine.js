const PCIO_STATIC_LAYERS=["P","C","I","O","H"];
const PCIO_STATIC_PERFORMANCE=["PERF_QUALITY","PERF_COST","PERF_EFF","PERF_FLEX"];

function pcioFinite(values){return values.filter(v=>typeof v==="number"&&Number.isFinite(v))}
function pcioMean(values){const x=pcioFinite(values);return x.length?x.reduce((a,b)=>a+b,0)/x.length:null}
function pcioVariance(values){const x=pcioFinite(values),m=pcioMean(x);return x.length>1?x.reduce((s,v)=>s+(v-m)**2,0)/(x.length-1):null}
function pcioSd(values){const v=pcioVariance(values);return v===null?null:Math.sqrt(Math.max(0,v))}
function pcioFmt(value,digits=4){return typeof value==="number"&&Number.isFinite(value)?value.toFixed(digits):"N/A"}
function pcioP(value){return typeof value==="number"&&Number.isFinite(value)?(value<0.0001?"<0.0001":value.toFixed(4)):"N/A"}
function pcioTranspose(matrix){return matrix[0].map((_,j)=>matrix.map(row=>row[j]))}
function pcioMatMul(a,b){const bt=pcioTranspose(b);return a.map(row=>bt.map(col=>row.reduce((s,v,i)=>s+v*col[i],0)))}
function pcioMatVec(a,v){return a.map(row=>row.reduce((s,x,i)=>s+x*v[i],0))}
function pcioOuter(a,b){return a.map(x=>b.map(y=>x*y))}
function pcioIdentity(n){return Array.from({length:n},(_,i)=>Array.from({length:n},(_,j)=>i===j?1:0))}
function pcioMatrixInverse(matrix){
 const n=matrix.length,a=matrix.map((row,i)=>[...row,...pcioIdentity(n)[i]]);
 for(let col=0;col<n;col++){
  let pivot=col;
  for(let row=col+1;row<n;row++)if(Math.abs(a[row][col])>Math.abs(a[pivot][col]))pivot=row;
  if(Math.abs(a[pivot][col])<1e-12)return null;
  [a[col],a[pivot]]=[a[pivot],a[col]];
  const divisor=a[col][col];
  for(let j=0;j<2*n;j++)a[col][j]/=divisor;
  for(let row=0;row<n;row++)if(row!==col){
   const factor=a[row][col];
   for(let j=0;j<2*n;j++)a[row][j]-=factor*a[col][j];
  }
 }
 return a.map(row=>row.slice(n));
}
function pcioDeterminant(matrix){
 const a=matrix.map(row=>[...row]),n=a.length;let det=1,sign=1;
 for(let col=0;col<n;col++){
  let pivot=col;
  for(let row=col+1;row<n;row++)if(Math.abs(a[row][col])>Math.abs(a[pivot][col]))pivot=row;
  if(Math.abs(a[pivot][col])<1e-14)return 0;
  if(pivot!==col){[a[col],a[pivot]]=[a[pivot],a[col]];sign*=-1}
  const value=a[col][col];det*=value;
  for(let row=col+1;row<n;row++){const factor=a[row][col]/value;for(let j=col+1;j<n;j++)a[row][j]-=factor*a[col][j]}
 }
 return det*sign;
}
function pcioLogGamma(z){
 const coefficients=[0.9999999999998099,676.5203681218851,-1259.1392167224028,771.3234287776531,-176.6150291621406,12.507343278686905,-0.13857109526572012,9.984369578019572e-6,1.5056327351493116e-7];
 if(z<0.5)return Math.log(Math.PI)-Math.log(Math.sin(Math.PI*z))-pcioLogGamma(1-z);
 z-=1;let x=coefficients[0];for(let i=1;i<coefficients.length;i++)x+=coefficients[i]/(z+i);
 const t=z+7.5;return 0.5*Math.log(2*Math.PI)+(z+0.5)*Math.log(t)-t+Math.log(x);
}
function pcioBetaCf(a,b,x){
 const max=200,eps=3e-12,fpmin=1e-30;let qab=a+b,qap=a+1,qam=a-1,c=1,d=1-qab*x/qap;
 if(Math.abs(d)<fpmin)d=fpmin;d=1/d;let h=d;
 for(let m=1;m<=max;m++){
  const m2=2*m;let aa=m*(b-m)*x/((qam+m2)*(a+m2));d=1+aa*d;if(Math.abs(d)<fpmin)d=fpmin;c=1+aa/c;if(Math.abs(c)<fpmin)c=fpmin;d=1/d;h*=d*c;
  aa=-(a+m)*(qab+m)*x/((a+m2)*(qap+m2));d=1+aa*d;if(Math.abs(d)<fpmin)d=fpmin;c=1+aa/c;if(Math.abs(c)<fpmin)c=fpmin;d=1/d;const delta=d*c;h*=delta;
  if(Math.abs(delta-1)<eps)break;
 }
 return h;
}
function pcioRegularizedBeta(x,a,b){
 if(x<=0)return 0;if(x>=1)return 1;
 const bt=Math.exp(pcioLogGamma(a+b)-pcioLogGamma(a)-pcioLogGamma(b)+a*Math.log(x)+b*Math.log(1-x));
 return x<(a+1)/(a+b+2)?bt*pcioBetaCf(a,b,x)/a:1-bt*pcioBetaCf(b,a,1-x)/b;
}
function pcioTCdf(t,df){if(!(df>0))return null;const x=df/(df+t*t),tail=0.5*pcioRegularizedBeta(x,df/2,0.5);return t>=0?1-tail:tail}
function pcioFSf(f,df1,df2){return f>=0?pcioRegularizedBeta(df2/(df2+df1*f),df2/2,df1/2):1}
function pcioGammaQ(a,x){
 if(x<0||a<=0)return null;if(x===0)return 1;
 const gln=pcioLogGamma(a),eps=3e-12,fpmin=1e-30,max=300;
 if(x<a+1){let ap=a,sum=1/a,del=sum;for(let n=1;n<=max;n++){ap+=1;del*=x/ap;sum+=del;if(Math.abs(del)<Math.abs(sum)*eps)break}return 1-sum*Math.exp(-x+a*Math.log(x)-gln)}
 let b=x+1-a,c=1/fpmin,d=1/b,h=d;
 for(let i=1;i<=max;i++){const an=-i*(i-a);b+=2;d=an*d+b;if(Math.abs(d)<fpmin)d=fpmin;c=b+an/c;if(Math.abs(c)<fpmin)c=fpmin;d=1/d;const delta=d*c;h*=delta;if(Math.abs(delta-1)<eps)break}
 return Math.exp(-x+a*Math.log(x)-gln)*h;
}
function pcioBhFdr(rows,key="p_value",target="p_fdr_bh"){
 const valid=rows.map((row,index)=>({index,p:row[key]})).filter(x=>typeof x.p==="number"&&Number.isFinite(x.p)).sort((a,b)=>a.p-b.p),m=valid.length;
 let running=1;for(let i=m-1;i>=0;i--){running=Math.min(running,valid[i].p*m/(i+1));rows[valid[i].index][target]=Math.min(1,running)}
 return rows;
}
function pcioCorrelation(x,y){
 const pairs=x.map((v,i)=>[v,y[i]]).filter(p=>p.every(v=>typeof v==="number"&&Number.isFinite(v))),n=pairs.length;
 if(n<3)return{n,r:null,p_value:null};
 const xs=pairs.map(p=>p[0]),ys=pairs.map(p=>p[1]),mx=pcioMean(xs),my=pcioMean(ys);
 const numerator=pairs.reduce((s,p)=>s+(p[0]-mx)*(p[1]-my),0),dx=Math.sqrt(xs.reduce((s,v)=>s+(v-mx)**2,0)),dy=Math.sqrt(ys.reduce((s,v)=>s+(v-my)**2,0));
 if(dx===0||dy===0)return{n,r:null,p_value:null};
 const r=Math.max(-1,Math.min(1,numerator/(dx*dy))),t=Math.abs(r)*Math.sqrt((n-2)/Math.max(1e-12,1-r*r)),cdf=pcioTCdf(t,n-2);
 return{n,r,p_value:cdf===null?null:2*(1-cdf)};
}
function pcioCorrelationMatrix(data,variables){
 const long=[];
 const matrix=variables.map((left,i)=>variables.map((right,j)=>i===j?1:pcioCorrelation(data.map(r=>r[left]),data.map(r=>r[right])).r));
 for(let i=0;i<variables.length;i++)for(let j=i+1;j<variables.length;j++){const result=pcioCorrelation(data.map(r=>r[variables[i]]),data.map(r=>r[variables[j]]));long.push({variable_1:variables[i],variable_2:variables[j],...result,p_fdr_bh:null})}
 pcioBhFdr(long);return{variables,matrix,long};
}
function pcioCorrelationFromMatrix(matrix){
 const columns=pcioTranspose(matrix),means=columns.map(pcioMean),sds=columns.map(pcioSd);
 return columns.map((_,i)=>columns.map((__,j)=>{
  if(i===j)return 1;if(!sds[i]||!sds[j])return 0;
  return matrix.reduce((sum,row)=>sum+(row[i]-means[i])*(row[j]-means[j]),0)/((matrix.length-1)*sds[i]*sds[j]);
 }));
}
function pcioCronbach(itemIds,rows,questionLookup){
 let matrix=rows.map(row=>itemIds.map(id=>score(questionLookup[id],row[id]))),minimum=Math.max(2,Math.ceil(itemIds.length*0.8));
 matrix=matrix.filter(row=>pcioFinite(row).length>=minimum);if(matrix.length<3)return{status:"insufficient",n:matrix.length,items:itemIds.length,alpha:null};
 const means=itemIds.map((_,j)=>pcioMean(matrix.map(row=>row[j])));
 matrix=matrix.map(row=>row.map((v,j)=>typeof v==="number"&&Number.isFinite(v)?v:means[j]));
 const keep=itemIds.map((_,j)=>pcioVariance(matrix.map(row=>row[j]))>0).reduce((a,v,i)=>(v&&a.push(i),a),[]);
 if(keep.length<2)return{status:"zero_variance",n:matrix.length,items:keep.length,alpha:null};
 matrix=matrix.map(row=>keep.map(i=>row[i]));const k=keep.length,itemVariance=pcioTranspose(matrix).reduce((s,col)=>s+pcioVariance(col),0),totals=matrix.map(row=>row.reduce((a,b)=>a+b,0)),totalVariance=pcioVariance(totals);
 return{status:totalVariance>0?"ok":"zero_variance",n:matrix.length,items:k,alpha:totalVariance>0?k/(k-1)*(1-itemVariance/totalVariance):null};
}
function pcioKmoBartlett(anchorIds,rows,questionLookup){
 const matrix=rows.map(row=>anchorIds.map(id=>score(questionLookup[id],row[id]))).filter(row=>row.every(v=>typeof v==="number"&&Number.isFinite(v))),n=matrix.length,p=anchorIds.length;
 if(p<2||n<Math.max(5,p+1))return{status:"insufficient",n,variables:p,kmo_overall:null,bartlett_chi_square:null,bartlett_df:null,bartlett_p:null,sample_to_variable_ratio:p?n/p:null};
 const corr=pcioCorrelationFromMatrix(matrix).map((row,i)=>row.map((v,j)=>v+(i===j?1e-8:0))),inverse=pcioMatrixInverse(corr);
 if(!inverse)return{status:"singular",n,variables:p,kmo_overall:null,bartlett_chi_square:null,bartlett_df:null,bartlett_p:null,sample_to_variable_ratio:n/p};
 let corrSq=0,partialSq=0;
 for(let i=0;i<p;i++)for(let j=0;j<p;j++)if(i!==j){corrSq+=corr[i][j]**2;const partial=-inverse[i][j]/Math.sqrt(Math.abs(inverse[i][i]*inverse[j][j]));partialSq+=partial**2}
 const determinant=pcioDeterminant(corr),chi=determinant>0?-(n-1-(2*p+5)/6)*Math.log(determinant):null,df=p*(p-1)/2;
 return{status:"ok",n,variables:p,kmo_overall:corrSq/(corrSq+partialSq),bartlett_chi_square:chi,bartlett_df:df,bartlett_p:chi===null?null:pcioGammaQ(df/2,chi/2),sample_to_variable_ratio:n/p};
}
function pcioGroupDifferences(data){
 const rows=[],groupVariables=["participated_digital_project","shift","role"],outcomes=[...PCIO_STATIC_LAYERS,"PERF_OVERALL"],minimum=5;
 for(const groupVariable of groupVariables)for(const outcome of outcomes){
  const grouped=new Map();
  for(const row of data){const group=String(row[groupVariable]??"").trim(),value=row[outcome];if(!group||typeof value!=="number"||!Number.isFinite(value))continue;if(!grouped.has(group))grouped.set(group,[]);grouped.get(group).push(value)}
  const groups=[...grouped.entries()].sort((a,b)=>a[0].localeCompare(b[0])).map(([group,values])=>({group,n:values.length,mean:pcioMean(values),std_dev:pcioSd(values),values}));
  const base={group_variable:groupVariable,outcome,n_total:groups.reduce((s,g)=>s+g.n,0),groups:groups.map(({values,...rest})=>rest),minimum_group_n:minimum,p_fdr_bh:null};
  if(groups.length<2||groups.some(g=>g.n<minimum)){rows.push({...base,test:"not_run",status:"insufficient",statistic:null,df1:null,df2:null,p_value:null,effect_size_name:null,effect_size:null});continue}
  if(groups.length===2){
   const [left,right]=groups,m1=left.mean,m2=right.mean,v1=pcioVariance(left.values),v2=pcioVariance(right.values),term1=v1/left.n,term2=v2/right.n;
   if(!(term1+term2>0)){rows.push({...base,test:"welch_t_test",status:"zero_variance",statistic:null,df1:null,df2:null,p_value:null,effect_size_name:"hedges_g",effect_size:null});continue}
   const t=(m1-m2)/Math.sqrt(term1+term2),df=(term1+term2)**2/(term1**2/(left.n-1)+term2**2/(right.n-1)),cdf=pcioTCdf(Math.abs(t),df);
   const pooled=Math.sqrt(((left.n-1)*v1+(right.n-1)*v2)/(left.n+right.n-2)),d=pooled?(m1-m2)/pooled:null,correction=1-3/(4*(left.n+right.n)-9);
   rows.push({...base,test:"welch_t_test",status:"ok",statistic:t,df1:df,df2:null,p_value:cdf===null?null:2*(1-cdf),effect_size_name:"hedges_g",effect_size:d===null?null:d*correction});
  }else{
   const values=groups.flatMap(g=>g.values),grand=pcioMean(values),ssBetween=groups.reduce((s,g)=>s+g.n*(g.mean-grand)**2,0),ssTotal=values.reduce((s,v)=>s+(v-grand)**2,0),df1=groups.length-1,df2=values.length-groups.length,ssWithin=ssTotal-ssBetween,f=(ssBetween/df1)/(ssWithin/df2);
   if(!(ssWithin>0)){rows.push({...base,test:"one_way_anova",status:"zero_variance",statistic:null,df1,df2,p_value:null,effect_size_name:"eta_squared",effect_size:ssTotal>0?ssBetween/ssTotal:null});continue}
   rows.push({...base,test:"one_way_anova",status:"ok",statistic:f,df1,df2,p_value:pcioFSf(f,df1,df2),effect_size_name:"eta_squared",effect_size:ssTotal>0?ssBetween/ssTotal:null});
  }
 }
 return pcioBhFdr(rows);
}
function pcioRegression(data,dependent){
 const complete=data.filter(row=>[dependent,...PCIO_STATIC_LAYERS].every(v=>typeof row[v]==="number"&&Number.isFinite(row[v]))),n=complete.length,p=PCIO_STATIC_LAYERS.length,minimum=Math.max(30,5*p+5);
 if(n<minimum)return{dependent,status:"insufficient",n,minimum_n:minimum,predictors:PCIO_STATIC_LAYERS,model:{},coefficients:[],vif:[]};
 const variables=[dependent,...PCIO_STATIC_LAYERS],means=Object.fromEntries(variables.map(v=>[v,pcioMean(complete.map(r=>r[v]))])),sds=Object.fromEntries(variables.map(v=>[v,pcioSd(complete.map(r=>r[v]))]));
 if(variables.some(v=>!sds[v]))return{dependent,status:"zero_variance",n,minimum_n:minimum,predictors:PCIO_STATIC_LAYERS,model:{},coefficients:[],vif:[]};
 const y=complete.map(r=>(r[dependent]-means[dependent])/sds[dependent]),x=complete.map(r=>[1,...PCIO_STATIC_LAYERS.map(v=>(r[v]-means[v])/sds[v])]),xt=pcioTranspose(x),xtx=pcioMatMul(xt,x),inv=pcioMatrixInverse(xtx);
 if(!inv)return{dependent,status:"singular",n,minimum_n:minimum,predictors:PCIO_STATIC_LAYERS,model:{},coefficients:[],vif:[]};
 const beta=pcioMatVec(inv,pcioMatVec(xt,y)),fitted=pcioMatVec(x,beta),residuals=y.map((v,i)=>v-fitted[i]),sse=residuals.reduce((s,v)=>s+v*v,0),sst=y.reduce((s,v)=>s+v*v,0),dfResidual=n-p-1,r2=1-sse/sst,adjusted=1-(1-r2)*(n-1)/dfResidual,f=(r2/p)/((1-r2)/dfResidual);
 let meat=Array.from({length:p+1},()=>Array(p+1).fill(0));
 for(let i=0;i<n;i++){const xi=x[i],hat=xi.reduce((s,v,j)=>s+v*pcioMatVec(inv,xi)[j],0),weight=(residuals[i]/Math.max(1e-8,1-hat))**2,outer=pcioOuter(xi,xi);meat=meat.map((row,a)=>row.map((value,b)=>value+outer[a][b]*weight))}
 const covariance=pcioMatMul(pcioMatMul(inv,meat),inv),names=["Intercept",...PCIO_STATIC_LAYERS],coefficients=names.map((name,i)=>{const se=Math.sqrt(Math.max(0,covariance[i][i])),t=se?beta[i]/se:null,cdf=t===null?null:pcioTCdf(Math.abs(t),dfResidual);return{dependent,predictor:name,standardised_beta:beta[i],robust_std_error:se,t,p_value:cdf===null?null:2*(1-cdf),p_fdr_bh:null}});
 pcioBhFdr(coefficients.filter(row=>row.predictor!=="Intercept"));
 const predictorMatrix=complete.map(r=>PCIO_STATIC_LAYERS.map(v=>r[v])),predictorCorr=pcioCorrelationFromMatrix(predictorMatrix),predictorInv=pcioMatrixInverse(predictorCorr.map((row,i)=>row.map((v,j)=>v+(i===j?1e-8:0)))),vif=PCIO_STATIC_LAYERS.map((variable,i)=>({variable,vif:predictorInv?predictorInv[i][i]:null}));
 const dw=residuals.slice(1).reduce((s,v,i)=>s+(v-residuals[i])**2,0)/sse;
 return{dependent,status:"ok",n,minimum_n:minimum,predictors:PCIO_STATIC_LAYERS,model:{r_squared:r2,adjusted_r_squared:adjusted,f_statistic:f,f_p_value:pcioFSf(f,p,dfResidual),df_model:p,df_residual:dfResidual,durbin_watson:dw,max_vif:Math.max(...vif.map(v=>v.vif||0)),covariance:"HC3 robust"},coefficients,vif};
}
function pcioStaticStatistics(rows){
 const questionLookup=Object.fromEntries(SCHEMA.questions.map(q=>[q.id,q])),scaleItems=Object.fromEntries(PCIO_STATIC_LAYERS.map(layer=>[layer,SCHEMA.questions.filter(q=>q.type==="likert"&&q.analysis_role==="scale"&&q.pcio_layer===layer).map(q=>q.id)]));
 const data=rows.map(row=>{
  const result={};
  for(const field of SCHEMA.respondent_fields)result[field.id]=row[field.id];
  for(const layer of PCIO_STATIC_LAYERS){const values=scaleItems[layer].map(id=>score(questionLookup[id],row[id]));result[layer]=pcioMean(values)}
  for(const id of PCIO_STATIC_PERFORMANCE)result[id]=score(questionLookup[id],row[id]);
  result.PERF_OVERALL=pcioMean(PCIO_STATIC_PERFORMANCE.map(id=>result[id]));
  result.attention_failures=SCHEMA.questions.filter(q=>q.analysis_role==="attention").reduce((sum,q)=>sum+(Number(row[q.id])===(q.attention_check?.expected||4)?0:1),0);
  return result;
 });
 const variables=[...PCIO_STATIC_LAYERS,...PCIO_STATIC_PERFORMANCE,"PERF_OVERALL"],descriptives=variables.map(variable=>{const values=pcioFinite(data.map(r=>r[variable]));return{variable,n:values.length,missing:data.length-values.length,mean:pcioMean(values),std_dev:pcioSd(values),minimum:values.length?Math.min(...values):null,maximum:values.length?Math.max(...values):null}});
 const reliability=[...PCIO_STATIC_LAYERS.map(scale=>({scale,item_set:"full_305_instrument",...pcioCronbach(scaleItems[scale],rows,questionLookup)})),{scale:"R",item_set:"performance_4_items",...pcioCronbach(PCIO_STATIC_PERFORMANCE,rows,questionLookup)}];
 const anchors=SCHEMA.questions.filter(q=>q.type==="likert"&&q.analysis_role==="scale"&&q.validity_anchor).map(q=>q.id),validity=pcioKmoBartlett(anchors,rows,questionLookup),correlations=pcioCorrelationMatrix(data,variables),group_differences=pcioGroupDifferences(data),regressions=["PERF_OVERALL",...PCIO_STATIC_PERFORMANCE].map(dependent=>pcioRegression(data,dependent));
 const attentionFlagged=data.filter(r=>r.attention_failures>0).length,totalCells=rows.length*SCHEMA.questions.filter(q=>q.type==="likert").length,answeredCells=rows.reduce((sum,row)=>sum+SCHEMA.questions.filter(q=>q.type==="likert").filter(q=>{const value=Number(row[q.id]);return Number.isFinite(value)&&value>=1&&value<=5}).length,0);
 return{engine:"PCIO browser-side SPSS-style engine 1.0",sample_size:rows.length,data_quality:{retained_rows:rows.length,likert_items:SCHEMA.questions.filter(q=>q.type==="likert").length,validity_anchor_items:anchors.length,attention_check_items:SCHEMA.questions.filter(q=>q.analysis_role==="attention").length,attention_flagged_rows:attentionFlagged,attention_pass_rate:rows.length?(rows.length-attentionFlagged)/rows.length:null,missing_cell_rate:totalCells?1-answeredCells/totalCells:null},methods:{reliability:"Cronbach alpha; respondents require at least 80% of scale items, then item-mean imputation",validity:"KMO and Bartlett on 20 pre-specified validity anchors",group_difference:"Welch t-test for two groups; one-way ANOVA for 3+ groups; minimum n=5/group; BH-FDR",correlation:"Two-sided Pearson correlation with BH-FDR",regression:"Standardised OLS with HC3 robust standard errors and BH-FDR; minimum n=30"},tables:{scale_descriptives:descriptives,reliability,kmo_bartlett:validity,correlations,group_differences,regressions}};
}
function pcioRenderStatisticalAnalysis(analysis){
 const zh=lang==="zh",quality=analysis.data_quality,kmo=analysis.tables.kmo_bartlett;
 const label={P:"P",C:"C",I:"I",O:"O",H:"H",PERF_QUALITY:zh?"质量绩效":"Quality performance",PERF_COST:zh?"成本绩效":"Cost performance",PERF_EFF:zh?"效率绩效":"Efficiency performance",PERF_FLEX:zh?"柔性绩效":"Flexibility performance",PERF_OVERALL:zh?"综合生产绩效":"Overall production performance"};
 const descriptiveRows=analysis.tables.scale_descriptives.map(r=>`<tr><td>${label[r.variable]||r.variable}</td><td>${r.n}</td><td>${r.missing}</td><td>${pcioFmt(r.mean)}</td><td>${pcioFmt(r.std_dev)}</td><td>${pcioFmt(r.minimum)}</td><td>${pcioFmt(r.maximum)}</td></tr>`).join("");
 const reliabilityRows=analysis.tables.reliability.map(r=>`<tr><td>${r.scale}</td><td>${r.items}</td><td>${r.n}</td><td>${pcioFmt(r.alpha)}</td><td>${r.status}</td></tr>`).join("");
 const groupRows=analysis.tables.group_differences.map(r=>`<tr><td>${r.group_variable}</td><td>${label[r.outcome]||r.outcome}</td><td>${r.test}</td><td>${r.groups.map(g=>`${esc(g.group)} n=${g.n}, M=${pcioFmt(g.mean)}`).join("<br>")}</td><td>${pcioFmt(r.statistic)}</td><td>${pcioFmt(r.df1,2)}${r.df2===null?"":` / ${pcioFmt(r.df2,2)}`}</td><td>${pcioP(r.p_value)}</td><td>${pcioP(r.p_fdr_bh)}</td><td>${r.effect_size_name||"N/A"} ${pcioFmt(r.effect_size)}</td><td>${r.status}</td></tr>`).join("");
 const correlation=analysis.tables.correlations,correlationRows=correlation.variables.map((variable,i)=>`<tr><td>${label[variable]||variable}</td>${correlation.matrix[i].map(value=>`<td>${pcioFmt(value,3)}</td>`).join("")}</tr>`).join("");
 const correlationFindings=[...correlation.long].filter(r=>r.r!==null).sort((a,b)=>Math.abs(b.r)-Math.abs(a.r)).slice(0,12).map(r=>`<tr><td>${label[r.variable_1]||r.variable_1}</td><td>${label[r.variable_2]||r.variable_2}</td><td>${r.n}</td><td>${pcioFmt(r.r)}</td><td>${pcioP(r.p_value)}</td><td>${pcioP(r.p_fdr_bh)}</td></tr>`).join("");
 const modelRows=analysis.tables.regressions.map(model=>`<tr><td>${label[model.dependent]||model.dependent}</td><td>${model.n}</td><td>${model.status}</td><td>${pcioFmt(model.model.r_squared)}</td><td>${pcioFmt(model.model.adjusted_r_squared)}</td><td>${pcioFmt(model.model.f_statistic)}</td><td>${pcioP(model.model.f_p_value)}</td><td>${pcioFmt(model.model.max_vif)}</td><td>${pcioFmt(model.model.durbin_watson)}</td></tr>`).join("");
 const coefficientRows=analysis.tables.regressions.flatMap(model=>model.coefficients||[]).map(r=>`<tr><td>${label[r.dependent]||r.dependent}</td><td>${r.predictor}</td><td>${pcioFmt(r.standardised_beta)}</td><td>${pcioFmt(r.robust_std_error)}</td><td>${pcioFmt(r.t)}</td><td>${pcioP(r.p_value)}</td><td>${pcioP(r.p_fdr_bh)}</td></tr>`).join("");
 return `<section class="statistical-analysis">
  <div class="analysis-section-title"><span>01</span><div><h3>${zh?"详细分析结果":"Detailed Analysis Results"}</h3><p>${zh?"浏览器端 SPSS 风格统计，完整结果随当前项目数据重新计算":"Browser-side SPSS-style statistics recalculated from the current project data"}</p></div></div>
  <div class="stat-method-note">${zh?`有效样本 n=${quality.retained_rows}；Likert 题 ${quality.likert_items}；注意力检测未通过 ${quality.attention_flagged_rows} 份；单元格缺失率 ${pcioFmt(quality.missing_cell_rate*100,2)}%。推断统计必须结合抽样方式、响应质量和现场证据解释。`:`Valid sample n=${quality.retained_rows}; ${quality.likert_items} Likert items; ${quality.attention_flagged_rows} responses failed at least one attention check; cell missingness ${pcioFmt(quality.missing_cell_rate*100,2)}%. Interpret inference with sampling, response quality, and shop-floor evidence.`}</div>
  <h4>${zh?"描述统计":"Descriptive Statistics"}</h4><div class="scroll"><table><thead><tr><th>${zh?"变量":"Variable"}</th><th>n</th><th>${zh?"缺失":"Missing"}</th><th>Mean</th><th>SD</th><th>Min</th><th>Max</th></tr></thead><tbody>${descriptiveRows}</tbody></table></div>
  <h4>Cronbach's α</h4><div class="scroll"><table><thead><tr><th>${zh?"量表":"Scale"}</th><th>${zh?"题项":"Items"}</th><th>n</th><th>α</th><th>Status</th></tr></thead><tbody>${reliabilityRows}</tbody></table></div>
  <h4>KMO / Bartlett</h4><div class="scroll"><table><thead><tr><th>Status</th><th>n</th><th>${zh?"锚点变量":"Anchor variables"}</th><th>KMO</th><th>Bartlett χ²</th><th>df</th><th>p</th><th>n/p</th></tr></thead><tbody><tr><td>${kmo.status}</td><td>${kmo.n}</td><td>${kmo.variables}</td><td>${pcioFmt(kmo.kmo_overall)}</td><td>${pcioFmt(kmo.bartlett_chi_square)}</td><td>${kmo.bartlett_df??"N/A"}</td><td>${pcioP(kmo.bartlett_p)}</td><td>${pcioFmt(kmo.sample_to_variable_ratio,2)}</td></tr></tbody></table></div>
  <p class="boundary">${zh?"KMO/Bartlett 仅使用预设的 20 道效度锚点；完整 EFA/CFA 需要更大的独立样本。":"KMO/Bartlett uses the 20 pre-specified validity anchors only. Full EFA/CFA requires a larger independent sample."}</p>
  <h4>${zh?"组间差异：Welch t-test / ANOVA、FDR 与效应量":"Group Differences: Welch t-test / ANOVA, FDR, and Effect Size"}</h4><div class="scroll"><table><thead><tr><th>${zh?"分组":"Group"}</th><th>${zh?"结果变量":"Outcome"}</th><th>Test</th><th>${zh?"组描述":"Group descriptives"}</th><th>Statistic</th><th>df</th><th>p</th><th>BH-FDR</th><th>${zh?"效应量":"Effect size"}</th><th>Status</th></tr></thead><tbody>${groupRows}</tbody></table></div>
  <h4>${zh?"Pearson 相关矩阵":"Pearson Correlation Matrix"}</h4><div class="scroll"><table><thead><tr><th>${zh?"变量":"Variable"}</th>${correlation.variables.map(v=>`<th>${label[v]||v}</th>`).join("")}</tr></thead><tbody>${correlationRows}</tbody></table></div>
  <h4>${zh?"最强相关及 FDR":"Strongest Correlations and FDR"}</h4><div class="scroll"><table><thead><tr><th>Variable 1</th><th>Variable 2</th><th>n</th><th>r</th><th>p</th><th>BH-FDR</th></tr></thead><tbody>${correlationFindings}</tbody></table></div>
  <h4>${zh?"多元线性回归模型":"Multiple Linear Regression Models"}</h4><div class="scroll"><table><thead><tr><th>Dependent</th><th>n</th><th>Status</th><th>R²</th><th>Adjusted R²</th><th>F</th><th>Model p</th><th>Max VIF</th><th>Durbin-Watson</th></tr></thead><tbody>${modelRows}</tbody></table></div>
  <h4>${zh?"标准化回归系数、HC3 与 FDR":"Standardised Coefficients, HC3, and FDR"}</h4><div class="scroll"><table><thead><tr><th>Dependent</th><th>Predictor</th><th>β</th><th>HC3 SE</th><th>t</th><th>p</th><th>BH-FDR</th></tr></thead><tbody>${coefficientRows||`<tr><td colspan="7">${zh?"样本量不足，未运行回归。":"Insufficient sample size; regression was not run."}</td></tr>`}</tbody></table></div>
  <p class="boundary">${zh?"相关与回归表示统计关联，不证明因果。静态站结果适合现场筛选；正式归档仍建议使用 Python/Streamlit 引擎生成可复算 Excel。":"Correlation and regression indicate association, not causality. The static results support shop-floor screening; use the Python/Streamlit engine for formally archived, reproducible Excel outputs."}</p>
 </section>`;
}

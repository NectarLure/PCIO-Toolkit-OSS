﻿"""Generate the complete Phase 4 chemical-process example package."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.generate_phase3_example import PROFILE_PATH, RESPONSE_PATH, generate_rows
from scripts.pcio_analysis import (
    analyze_pcio_survey,
    analysis_excel_bytes,
    write_analysis_package,
)
from scripts.pcio_decision_support import (
    complete_package_zip_bytes,
    generate_decision_support,
    write_decision_support_package,
)
from scripts.pcio_report import generate_bilingual_report
from scripts.pcio_survey_core import load_schema


EXAMPLE_DIR = ROOT / "examples" / "phase4" / "chemical-process"
OUTPUT_DIR = EXAMPLE_DIR / "complete_package"


def repository_relative(path: Path) -> str:
    return path.resolve().relative_to(ROOT).as_posix()


def main() -> int:
    schema = load_schema()
    profile = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    responses = pd.DataFrame(generate_rows(n=60, seed=20260610))
    analysis = analyze_pcio_survey(profile, responses, schema)
    report = generate_bilingual_report(profile, analysis, schema)
    roi_inputs = {
        "currency": "CNY",
        "investment": 300000,
        "annual_addressable_value": 2400000,
        "annual_operating_cost": 45000,
        "improvement_low_pct": 7.6,
        "improvement_high_pct": 11.2,
        "horizon_years": 3,
        "source": "chemical_process_example",
        "assumption_note_zh": "仅用于 Phase 4 演示的规划假设，不是企业报价或收益承诺。",
        "assumption_note_en": "Planning assumptions for the Phase 4 demonstration only; not a quote or benefit guarantee.",
    }
    decision = generate_decision_support(profile, analysis, roi_inputs, schema)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    analysis_paths = write_analysis_package(analysis, OUTPUT_DIR)
    report_path = OUTPUT_DIR / "PCIO-Implementation-Case-Report-bilingual.md"
    report_path.write_text(report, encoding="utf-8")
    decision_paths = write_decision_support_package(decision, OUTPUT_DIR)
    zip_path = EXAMPLE_DIR / "PCIO-Complete-Analysis-Package.zip"
    zip_path.write_bytes(
        complete_package_zip_bytes(
            profile,
            analysis,
            report,
            decision,
            analysis_excel_bytes(analysis),
        )
    )
    manifest = {
        "profile": repository_relative(PROFILE_PATH),
        "responses": repository_relative(RESPONSE_PATH),
        "analysis": {
            key: repository_relative(value) for key, value in analysis_paths.items()
        },
        "report": repository_relative(report_path),
        "decision_support": {
            key: repository_relative(value) for key, value in decision_paths.items()
        },
        "complete_zip": repository_relative(zip_path),
        "valid_responses": analysis["data_quality"]["retained_rows"],
        "selected_risks": len(decision["risk"]["risks"]),
        "recommended_kpis": len(decision["kpis"]),
        "payback_range_months": decision["roi"]["payback_range_months"],
    }
    (EXAMPLE_DIR / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


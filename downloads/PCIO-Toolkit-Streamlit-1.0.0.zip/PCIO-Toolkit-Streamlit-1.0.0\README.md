﻿# PCIO Toolkit Streamlit Public Package

This package provides the local/Streamlit edition for public demonstration. It contains the Streamlit app, the 305-item questionnaire templates, SPSS-style analysis modules, report and decision-support modules, public documentation, and synthetic examples.

## Run locally

```powershell
pip install -r requirements.txt
streamlit run app/streamlit_app.py
```

## Boundary

This public package excludes private research drafts, raw enterprise data, original case documents, expert raw evaluation records, and legacy raw-data processing utilities. Use only synthetic examples unless a company has approved local or internal data processing.

ROI outputs are scenario estimates only and are not verified financial returns.

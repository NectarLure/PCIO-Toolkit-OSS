# PCIO Toolkit

> 面向制造业中小企业的中英双语、低成本、模块化智能制造诊断与实施工具包  
> A bilingual, low-cost, modular smart-manufacturing diagnosis and implementation toolkit for manufacturing SMEs

**Version 1.0.0 Website Edition · Maintenance build 1.4.0 · MIT**

[中文](#中文) | [English](#english)

## 中文

### 项目介绍

PCIO Toolkit 把公司画像、生产技术人员问卷和现场改善假设转化为可复核的完整分析包：

- SPSS 风格描述统计、Cronbach's α、KMO/Bartlett、组间差异、Pearson 相关和多元回归。
- 固定七章的“贵公司 PCIO 实施案例分析报告”。
- 技术、组织、人力、外部四类动态风险及 4×4 矩阵。
- 个性化 KPI、PDCA 责任和三情景 ROI。
- JSON、CSV、Markdown、Excel 和完整 ZIP。

内置问卷共305项：13项公司画像、12项匿名个人信息和280道生产技术人员问卷题，预计填写40-50分钟。问卷含270道五点量表题、46道反向题、5道注意力检测、42道情景题和20道效度锚点，并提供多选、排序和开放题。

### 1.0.0 最终整合版主要改进

- 发布正式网站版：增加响应式导航、清晰首屏入口、四步工作台、加载反馈、问卷进度与本机草稿、专业页脚和可下载 Streamlit 完整包。
- 将原有简版问卷升级为稳定的 **305项专业量表**，Excel、HTML、Streamlit、CSV 和统计引擎共用 schema 3.0.0。
- 静态独立站可在浏览器本地运行描述统计、Cronbach's α、KMO/Bartlett、Welch t-test/ANOVA、Pearson 相关、标准化 OLS、HC3、BH-FDR 和效应量。
- 分析页按“详细统计 → 风险/KPI/ROI → 企业改善操作流程 → 核心诊断摘要”组织，完整证据在前，快速排查在后。
- 企业改善流程嵌入 PDCA，P/C/I/O 各含具体现场动作，并固定设置实施后3个月首次完整复测和6个月第二次复盘。
- Chemical-process 与 Discrete-manufacturing 示例已按305项问卷重新生成，并包含新版统计、改善流程和“仅供参考”声明。

PCIO 表示：

| 层级 | 定义 | 实施重点 |
|---|---|---|
| P - Perception | 可靠感知设备、工艺、能源和质量状态 | 测点、校准、数据完整性 |
| C - Connectivity | 安全、稳定、可诊断地传输数据 | 开放协议、边缘网关、断线监控 |
| I - Integration | 建立统一语义并连接生产与业务 | 数据字典、批次/工单、可复算 KPI |
| O - Optimisation | 用统计、规则、模型和控制改善结果 | SPC、报警、预测维护、MPC |

框架坚持基础技术优先、低总拥有成本、模块化试点、PDCA、人机协同和区域适应。

### 两种使用模式

| 模式 | 入口 | 适用场景 | 能力 |
|---|---|---|---|
| 静态独立站 | [`site/index.html`](site/index.html) | GitHub Pages、Vercel、Netlify、培训和浏览器端诊断 | 305项画像/问卷、CSV聚合、SPSS风格统计、风险/KPI/ROI、PDCA改善流程和独立摘要 |
| 完整应用 | [`app/streamlit_app.py`](app/streamlit_app.py) | 本地、企业内网、Docker、正式归档 | 静态站全部能力，加SciPy/statsmodels复算、双语案例报告、Excel和完整ZIP |

静态站结果用于规划和排查，不替代工程安全评估或财务审核。需要正式归档和可复算 Excel 时使用 Streamlit 或命令行。

### 快速上手

#### 1. 静态站

直接打开 [`site/index.html`](site/index.html)，或运行：

```powershell
python -m http.server 8080 --directory site
```

访问 `http://localhost:8080`。在“快速分析”中可载入演示数据。

#### 2. Streamlit

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app/streamlit_app.py
```

访问 `http://localhost:8501`，按“公司画像 → 技术人员问卷 → 聚合与导出 → 分析与决策”操作。

#### 3. Docker

```powershell
docker compose up --build -d
```

访问 `http://localhost:8501`。`data/` 与 `outputs/` 已配置持久化卷。

### 网站部署

正式网站文件位于 `site/`。其中 `index.html` 包含全部调查与分析逻辑，`assets/` 提供网站标识，`downloads/PCIO-Toolkit-Streamlit-1.0.0.zip` 是首页“下载完整 Streamlit 版本”按钮使用的公开安装包。公共网站不得预置真实企业问卷或生产数据。

#### GitHub Pages（推荐，免费）

1. 将仓库推送到 GitHub，默认生产分支设为 `main`。
2. 进入仓库 **Settings → Pages**，把 Source 设为 **GitHub Actions**。
3. 推送一次代码，或在 **Actions → Deploy PCIO static site → Run workflow** 手动执行。
4. 工作流会运行 `scripts/build_phase5_static_site.py`，再发布整个 `site/`。
5. 在 Actions 显示成功后，访问 `https://<用户名>.github.io/<仓库名>/`。

`.github/workflows/deploy-pages.yml` 和 `site/.nojekyll` 已包含在仓库中，无需另建 `gh-pages` 分支。

#### Vercel 一键部署

1. 登录 Vercel，选择 **Add New → Project** 并导入本 GitHub 仓库。
2. Framework Preset 选择 **Other**，Root Directory 保持仓库根目录。
3. Build Command、Output Directory 均留空，点击 **Deploy**。
4. 根目录 `vercel.json` 会把 `/`、`assets/` 和 `downloads/` 映射到 `site/`，后续每次推送自动发布预览和生产版本。

#### 自定义域名

- **GitHub Pages：**先在 Settings → Pages 填写并验证域名，再配置 DNS。`www` 子域使用 CNAME 指向 `<用户名>.github.io`；根域可使用 DNS 服务商的 ALIAS/ANAME，或按 GitHub 当前文档配置 A 记录。DNS 生效后启用 **Enforce HTTPS**。
- **Vercel：**进入项目 Settings → Domains 添加根域和 `www`，严格使用控制台当时显示的 A/CNAME 或 Nameserver 值，不在仓库里硬编码供应商可能调整的 DNS 目标。
- 建议选定一个主域，另一个版本做 301 重定向；启用 HTTPS；保留域名验证 TXT；不要使用不受控的通配符 DNS。

GitHub Pages 与 Vercel 运行的是浏览器端网站版。需要集中保存、正式 Excel/报告和服务器端复算时，应下载 Streamlit 完整版并部署在本地、企业内网或 Docker。

### 完整示例

- [Chemical process 完整示例](examples/complete/chemical-process/)
- [Discrete manufacturing 完整示例](examples/complete/discrete-manufacturing/)

每套示例含画像、305项结构的合成问卷、统计结果、双语报告、风险/KPI/ROI、企业改善操作流程、3/6个月复测计划、Excel 和 ZIP。全部公司、人员及收益数据均为匿名或合成数据，**仅供参考**。

### 证据边界

- 温度控制 `±0.5℃`：案例参考，不是通用目标。
- 三效蒸发蒸汽节省 `15.3%`：案例参考，不是收益承诺。
- 装卸时间减少 `29%`：案例参考，不是收益承诺。
- 既有问卷 `n=52`，`Sensor_Inf=4.5077` 为最高均值：支持“可靠感知与数据质量优先”，不证明安装更多传感器必然产生收益。

详见 [证据登记册](docs/PCIO-Evidence-Register.md)。

### 推荐目录结构

```text
PCIO/
├─ app/                  # Streamlit 完整应用
├─ site/                 # 正式网站、站点资源与 Streamlit 下载包
├─ templates/            # 问卷 schema、Excel、Phase 2 HTML
├─ scripts/              # 问卷、统计、报告、风险、KPI、ROI 和构建脚本
├─ docs/                 # PCIO 框架、证据登记、最终开发与用户指南
├─ examples/complete/    # 化工与离散制造自包含示例
├─ tests/                # 自动回归测试
├─ data/                 # 本地项目数据，默认不提交
├─ Dockerfile
├─ docker-compose.yml
├─ CITATION.cff
└─ requirements.txt
```

### 测试

```powershell
.\.venv\Scripts\python -m unittest discover -s tests -v
.\.venv\Scripts\python scripts/generate_final_examples.py
.\.venv\Scripts\python scripts/build_phase5_static_site.py
```

### 论文与项目引用建议

仓库提供 [`CITATION.cff`](CITATION.cff)。无 DOI 时可使用：

```bibtex
@software{pcio_toolkit_2026,
  author  = {{PCIO Toolkit Contributors}},
  title   = {PCIO Toolkit: Production Survey and Personalised Implementation Toolkit},
  year    = {2026},
  version = {1.0.0},
  note    = {Open-source software, accessed YYYY-MM-DD},
  url     = {REPLACE_WITH_REPOSITORY_URL}
}
```

引用工具包不等于引用案例指标；论文中使用 `±0.5℃`、`15.3%`、`29%` 或 `n=52` 时，应另行引用对应原始材料。

### 数据责任

代码和原创文档采用 MIT License。企业问卷、生产数据和案例材料不会因工具开源而自动公开。公共部署静态站前，不得嵌入真实企业数据；完整应用优先部署在企业本地或受控内网。

完整说明见 [开发与用户指南](docs/PCIO-Toolkit-Development-and-User-Guide.md)。

---

## English

### Overview

PCIO Toolkit converts a company profile, frontline technician surveys, and improvement assumptions into a reviewable package containing:

- SPSS-style descriptives, Cronbach's alpha, KMO/Bartlett, group differences, Pearson correlations, and multiple regression.
- A fixed seven-section bilingual PCIO implementation case report.
- Dynamic technical, organisational, workforce, and external risks in a 4×4 matrix.
- Personalised KPIs, PDCA ownership, and three-scenario ROI.
- JSON, CSV, Markdown, Excel, and a complete ZIP.

The built-in instrument contains 305 items: 13 company-profile fields, 12 anonymous respondent fields, and 280 production-technician questions requiring about 40-50 minutes. It includes 270 five-point items, 46 reverse-scored items, five attention checks, 42 scenarios, 20 validity anchors, plus multi-select, ranking, and open questions.

### Version 1.0.0 Final Integration Highlights

- Releases the formal Website Edition with responsive navigation, direct entry points, a four-step workspace, loading feedback, survey progress and local draft recovery, a professional footer, and a downloadable Streamlit package.
- Replaces the short instrument with a stable **305-item professional survey** shared by Excel, HTML, Streamlit, CSV, and schema 3.0.0 analytics.
- Adds browser-side descriptives, Cronbach's alpha, KMO/Bartlett, Welch t-test/ANOVA, Pearson correlation, standardised OLS, HC3, BH-FDR, and effect sizes to the static site.
- Organises results as detailed statistics, risk/KPI/ROI evidence, the enterprise improvement workflow, and a separate diagnostic summary.
- Embeds actionable P/C/I/O steps in PDCA with a first full retest at month 3 and a second review at month 6.
- Regenerates the Chemical-process and Discrete-manufacturing examples against the 305-item instrument and includes the new improvement workflow.

PCIO means Perception, Connectivity, Integration, and Optimisation. The framework follows foundation-first technology, low total cost, modular pilots, embedded PDCA, human accountability, and regional adaptability.

### Two Modes

| Mode | Entry | Best for | Capability |
|---|---|---|---|
| Static site | [`site/index.html`](site/index.html) | GitHub Pages, Vercel, Netlify, training, browser-side diagnosis | 305-item workflow, CSV aggregation, SPSS-style statistics, risk/KPI/ROI, PDCA workflow, and diagnostic summary |
| Full application | [`app/streamlit_app.py`](app/streamlit_app.py) | Local, intranet, Docker, formal archiving | Static-site functions plus SciPy/statsmodels reproduction, bilingual report, Excel, and complete ZIP |

Static results support planning and troubleshooting and do not replace engineering safety assessment or financial approval. Use Streamlit or the CLI for formally archived, reproducible Excel outputs.

### Quick Start

Static site:

```powershell
python -m http.server 8080 --directory site
```

Streamlit:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app/streamlit_app.py
```

Docker:

```powershell
docker compose up --build -d
```

### Website Deployment

The production website lives in `site/`. `index.html` contains the survey and analysis application, `assets/` contains the site mark, and `downloads/PCIO-Toolkit-Streamlit-1.0.0.zip` powers the full-edition download button. Never publish real company responses inside this directory.

**GitHub Pages**

1. Push the repository to GitHub with `main` as the production branch.
2. Open **Settings → Pages** and select **GitHub Actions** as the source.
3. Push a change or run **Deploy PCIO static site** manually from Actions.
4. The included workflow rebuilds and publishes `site/`.
5. Open `https://<username>.github.io/<repository>/` after the deployment succeeds.

**Vercel**

1. Import the GitHub repository as a new Vercel project.
2. Select framework preset **Other** and keep the repository root as Root Directory.
3. Leave Build Command and Output Directory empty, then deploy.
4. `vercel.json` maps the public routes to `site/`; later pushes receive automatic preview and production deployments.

**Custom domain**

- For GitHub Pages, add and verify the domain in Settings → Pages before changing DNS. Point a `www` CNAME directly to `<username>.github.io`; use the DNS provider's ALIAS/ANAME support or GitHub's current documented A records for an apex domain, then enable HTTPS.
- For Vercel, add the apex and `www` domains under Project Settings → Domains and use the exact DNS values shown by the dashboard.
- Choose one canonical hostname, redirect the alternative, keep domain-verification records, and avoid uncontrolled wildcard DNS.

GitHub Pages and Vercel host the browser-side Website Edition. Use the downloadable Streamlit edition on a local machine, controlled intranet, or Docker host for central storage and formally archived outputs.

### Complete Examples

- [Chemical process](examples/complete/chemical-process/)
- [Discrete manufacturing](examples/complete/discrete-manufacturing/)

Both include 305-item inputs, synthetic responses, analytics, bilingual reports, risk/KPI/ROI outputs, the enterprise improvement workflow, month-3/month-6 retest plans, Excel, and ZIP files. All company, respondent, and benefit data are anonymised or synthetic and **for reference only**.

### Evidence Boundary

`±0.5°C`, `15.3%`, and `29%` are case references, not guarantees. In the legacy `n=52` survey, `Sensor_Inf=4.5077` is the highest mean and supports a sensing-and-data-quality-first rule without proving universal causality.

See the [evidence register](docs/PCIO-Evidence-Register.md) and the [development and user guide](docs/PCIO-Toolkit-Development-and-User-Guide.md).

### Citation

Use [`CITATION.cff`](CITATION.cff) or the BibTeX example in the Chinese section. Replace the repository URL and access date before publication. Cite original source materials separately when using case metrics.

### Licence and Data Responsibility

Original code and documentation are MIT licensed. Company surveys, production data, and source case materials do not become public because the toolkit is open source. Prefer local, intranet, or controlled Docker deployment for real company data.
